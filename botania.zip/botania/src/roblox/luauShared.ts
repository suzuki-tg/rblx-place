import { BOTANIA_BIOMES, getBiomeToxicity } from '../game/biomes';
import { BIOME_SURVIVAL_TIPS } from '../game/progression';

export interface RobloxScriptDef {
  id: string;
  name: string;
  className: 'ModuleScript' | 'Script' | 'LocalScript';
  service: 'ReplicatedStorage' | 'ServerScriptService' | 'StarterPlayerScripts' | 'StarterGui';
  folder: string;
  robloxPath: string;
  summary: string;
  apis: string[];
  code: string;
}

function hexToRgbTuple(hex: string): string {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `${r}, ${g}, ${b}`;
}

const BIOME_SURVIVAL_TIPS_LUAU = BIOME_SURVIVAL_TIPS.map((t) => {
  return `\t{
\t\tId = "${t.id}",
\t\tDirection = "${t.direction}",
\t\tBiomeId = "${t.biomeId}",
\t\tBiomeName = "${t.biomeName}",
\t\tToxicity = ${t.toxicity},
\t\tAccentColor = Color3.fromRGB(${hexToRgbTuple(t.accentColor)}),
\t\tHeadline = "${t.headline}",
\t\tTip = "${t.tip}",
\t\tRecommendedGear = "${t.recommendedGear}",
\t},`;
}).join('\n');

const BIOME_TABLE_LUAU = BOTANIA_BIOMES.map((b) => {
  const tox = getBiomeToxicity(b);
  return `\t{
\t\tId = "${b.id}",
\t\tIndex = ${b.index},
\t\tName = "${b.name}",
\t\tGroundColor = Color3.fromRGB(${hexToRgbTuple(b.groundColor)}),
\t\tAccentColor = Color3.fromRGB(${hexToRgbTuple(b.accentColor)}),
\t\tFloraColor = Color3.fromRGB(${hexToRgbTuple(b.floraColor)}),
\t\tTrunkColor = Color3.fromRGB(${hexToRgbTuple(b.trunkColor)}),
\t\tFloraType = "${b.floraType}",
\t\tFaunaName = "${b.faunaName}",
\t\tFaunaColor = Color3.fromRGB(${hexToRgbTuple(b.faunaColor)}),
\t\tUniqueResourceId = "${b.uniqueResourceId}",
\t\tUniqueResourceName = "${b.uniqueResourceName}",
\t\tSeedId = "seed_${b.id}",
\t\tToxicityLevel = ${tox},
\t\tWeatherBias = "${b.weatherBias}",
\t},`;
}).join('\n');

export const SHARED_LUAU_SCRIPTS: RobloxScriptDef[] = [
  {
    id: 'biome_registry',
    name: 'BiomeRegistry',
    className: 'ModuleScript',
    service: 'ReplicatedStorage',
    folder: 'BotaniaShared',
    robloxPath: 'ReplicatedStorage/BotaniaShared/BiomeRegistry',
    summary: 'Реестр всех 30 ботанических биомов, детерминированный выбор 8 биомов на сервер и вычисление токсичности спор.',
    apis: ['Random', 'Color3'],
    code: `--!strict
-- ReplicatedStorage/BotaniaShared/BiomeRegistry (ModuleScript)
export type FloraArchetype = "oak" | "sakura" | "mushroom" | "bamboo" | "crystal" | "cactus" | "willow" | "fern"

export type BiomeDef = {
	Id: string,
	Index: number,
	Name: string,
	GroundColor: Color3,
	AccentColor: Color3,
	FloraColor: Color3,
	TrunkColor: Color3,
	FloraType: FloraArchetype,
	FaunaName: string,
	FaunaColor: Color3,
	UniqueResourceId: string,
	UniqueResourceName: string,
	SeedId: string,
	ToxicityLevel: number,
	WeatherBias: string,
}

local BiomeRegistry = {}

BiomeRegistry.List = {
${BIOME_TABLE_LUAU}
} :: { BiomeDef }

BiomeRegistry.ById = {} :: { [string]: BiomeDef }
for _, biome in ipairs(BiomeRegistry.List) do
	BiomeRegistry.ById[biome.Id] = biome
end

function BiomeRegistry.SelectServerBiomes(seed: number, count: number?): { BiomeDef }
	local targetCount = math.clamp(count or 8, 1, #BiomeRegistry.List)
	local rng = Random.new(seed)
	local selected: { BiomeDef } = { BiomeRegistry.List[1] } -- Изумрудная Роща всегда на спавне
	local pool: { BiomeDef } = {}
	for i = 2, #BiomeRegistry.List do
		table.insert(pool, BiomeRegistry.List[i])
	end
	for i = #pool, 2, -1 do
		local j = rng:NextInteger(1, i)
		pool[i], pool[j] = pool[j], pool[i]
	end
	for i = 1, targetCount - 1 do
		table.insert(selected, pool[i])
	end
	return selected
end

function BiomeRegistry.GetBiomeCenters(worldBiomes: { BiomeDef }): { { Biome: BiomeDef, X: number, Z: number } }
	local centers = {}
	if #worldBiomes == 0 then return centers end
	table.insert(centers, { Biome = worldBiomes[1], X = 0, Z = 0 })
	local ringCount = #worldBiomes - 1
	local ringRadius = 115
	for i = 1, ringCount do
		local angle = ((i - 1) / ringCount) * math.pi * 2 + 0.35
		table.insert(centers, {
			Biome = worldBiomes[i + 1],
			X = math.cos(angle) * ringRadius,
			Z = math.sin(angle) * ringRadius,
		})
	end
	return centers
end

function BiomeRegistry.GetBiomeAt(x: number, z: number, centers: { { Biome: BiomeDef, X: number, Z: number } }): BiomeDef
	local best = centers[1]
	local bestDist = math.huge
	for i, c in ipairs(centers) do
		local dx = x - c.X
		local dz = z - c.Z
		local weight = if i == 1 then 0.82 else 1.0
		local d = (dx * dx + dz * dz) * weight
		if d < bestDist then
			bestDist = d
			best = c
		end
	end
	return best.Biome
end

return BiomeRegistry`,
  },
  {
    id: 'item_recipe_registry',
    name: 'ItemAndRecipeRegistry',
    className: 'ModuleScript',
    service: 'ReplicatedStorage',
    folder: 'BotaniaShared',
    robloxPath: 'ReplicatedStorage/BotaniaShared/ItemAndRecipeRegistry',
    summary: 'Каталог инструментов, ресурсов 30 биомов, семян, построек, крафта и скрещивания (гибридизации) растений.',
    apis: ['Color3'],
    code: `--!strict
-- ReplicatedStorage/BotaniaShared/ItemAndRecipeRegistry (ModuleScript)
local BiomeRegistry = require(script.Parent.BiomeRegistry)

export type ItemDef = {
	Id: string,
	Name: string,
	Category: "Tool" | "Resource" | "Seed" | "Hybrid" | "Consumable" | "Buildable",
	MaxStack: number,
	Color: Color3,
	PlaceableKind: string?,
}

export type RecipeDef = {
	Id: string,
	OutputId: string,
	OutputCount: number,
	Tier: "Basic" | "Advanced" | "BioTech",
	RequiredSkill: string?,
	Ingredients: { { Id: string, Count: number } },
}

export type CrossbreedDef = {
	Id: string,
	SeedA: string,
	SeedB: string,
	ResultItemId: string,
	ResultName: string,
	GrowthSeconds: number,
}

local Registry = {}

Registry.Items = {
	tool_botanic_axe = { Id = "tool_botanic_axe", Name = "Ботанический топор", Category = "Tool", MaxStack = 1, Color = Color3.fromRGB(46, 204, 113) },
	tool_jade_axe = { Id = "tool_jade_axe", Name = "Нефритовый секатор", Category = "Tool", MaxStack = 1, Color = Color3.fromRGB(0, 210, 211) },
	tool_dew_can = { Id = "tool_dew_can", Name = "Лейка био-росы", Category = "Tool", MaxStack = 1, Color = Color3.fromRGB(112, 232, 255) },
	res_wood = { Id = "res_wood", Name = "Живая древесина", Category = "Resource", MaxStack = 64, Color = Color3.fromRGB(141, 91, 50) },
	res_fiber = { Id = "res_fiber", Name = "Ростовое волокно", Category = "Resource", MaxStack = 64, Color = Color3.fromRGB(88, 185, 71) },
	res_stone = { Id = "res_stone", Name = "Мшистый камень", Category = "Resource", MaxStack = 64, Color = Color3.fromRGB(127, 143, 166) },
	bld_moss_wall = { Id = "bld_moss_wall", Name = "Стена мшистого дуба", Category = "Buildable", MaxStack = 32, Color = Color3.fromRGB(106, 176, 76), PlaceableKind = "MossWall" },
	bld_glass_dome = { Id = "bld_glass_dome", Name = "Стекло теплицы", Category = "Buildable", MaxStack = 32, Color = Color3.fromRGB(112, 232, 255), PlaceableKind = "GlassWall" },
	bld_planter_box = { Id = "bld_planter_box", Name = "Грядка культивации", Category = "Buildable", MaxStack = 16, Color = Color3.fromRGB(118, 84, 56), PlaceableKind = "PlanterBox" },
	bld_flower_lamp = { Id = "bld_flower_lamp", Name = "Цветочный фонарь", Category = "Buildable", MaxStack = 16, Color = Color3.fromRGB(255, 211, 42), PlaceableKind = "FlowerLamp" },
	bld_seed_altar = { Id = "bld_seed_altar", Name = "Алтарь семян (Купол)", Category = "Buildable", MaxStack = 4, Color = Color3.fromRGB(197, 108, 240), PlaceableKind = "SeedAltar" },
	con_spore_filter = { Id = "con_spore_filter", Name = "Хлорофилловый фильтр", Category = "Consumable", MaxStack = 16, Color = Color3.fromRGB(29, 209, 161) },
	hyb_lumen_orchid = { Id = "hyb_lumen_orchid", Name = "Люмен-орхидея (Гибрид)", Category = "Hybrid", MaxStack = 32, Color = Color3.fromRGB(0, 245, 212) },
	hyb_crimson_lotus = { Id = "hyb_crimson_lotus", Name = "Алый лотос (Гибрид)", Category = "Hybrid", MaxStack = 32, Color = Color3.fromRGB(255, 107, 157) },
	hyb_frost_bamboo = { Id = "hyb_frost_bamboo", Name = "Кристальный бамбук (Гибрид)", Category = "Hybrid", MaxStack = 32, Color = Color3.fromRGB(130, 230, 255) },
} :: { [string]: ItemDef }

-- Автоматическая регистрация уникальных ресурсов и семян для всех 30 биомов
for _, biome in ipairs(BiomeRegistry.List) do
	Registry.Items[biome.UniqueResourceId] = {
		Id = biome.UniqueResourceId,
		Name = biome.UniqueResourceName,
		Category = "Resource",
		MaxStack = 64,
		Color = biome.FloraColor,
	}
	Registry.Items[biome.SeedId] = {
		Id = biome.SeedId,
		Name = "Семя: " .. biome.Name,
		Category = "Seed",
		MaxStack = 32,
		Color = biome.AccentColor,
	}
end

Registry.Recipes = {
	{
		Id = "craft_moss_wall",
		OutputId = "bld_moss_wall",
		OutputCount = 2,
		Tier = "Basic",
		Ingredients = { { Id = "res_wood", Count = 2 }, { Id = "res_fiber", Count = 1 } },
	},
	{
		Id = "craft_planter_box",
		OutputId = "bld_planter_box",
		OutputCount = 1,
		Tier = "Basic",
		Ingredients = { { Id = "res_wood", Count = 3 }, { Id = "res_fiber", Count = 2 } },
	},
	{
		Id = "craft_spore_filter",
		OutputId = "con_spore_filter",
		OutputCount = 2,
		Tier = "Basic",
		Ingredients = { { Id = "res_fiber", Count = 3 }, { Id = "res_emerald_sap", Count = 1 } },
	},
	{
		Id = "craft_glass_dome",
		OutputId = "bld_glass_dome",
		OutputCount = 2,
		Tier = "Advanced",
		Ingredients = { { Id = "res_stone", Count = 2 }, { Id = "res_emerald_sap", Count = 2 } },
	},
	{
		Id = "craft_jade_axe",
		OutputId = "tool_jade_axe",
		OutputCount = 1,
		Tier = "Advanced",
		Ingredients = { { Id = "res_wood", Count = 4 }, { Id = "res_stone", Count = 3 }, { Id = "res_emerald_sap", Count = 2 } },
	},
	{
		Id = "craft_seed_altar",
		OutputId = "bld_seed_altar",
		OutputCount = 1,
		Tier = "BioTech",
		RequiredSkill = "arch_blueprint",
		Ingredients = { { Id = "res_stone", Count = 5 }, { Id = "res_wood", Count = 4 }, { Id = "res_emerald_sap", Count = 3 } },
	},
} :: { RecipeDef }

-- Механика скрещивания семян на соседних грядках
Registry.Crossbreeds = {
	{
		Id = "xb_lumen_orchid",
		SeedA = "seed_sakura_terraces",
		SeedB = "seed_neon_fern_hollow",
		ResultItemId = "hyb_lumen_orchid",
		ResultName = "Люмен-орхидея",
		GrowthSeconds = 35,
	},
	{
		Id = "xb_crimson_lotus",
		SeedA = "seed_mycelium_canyon",
		SeedB = "seed_lotus_lagoon",
		ResultItemId = "hyb_crimson_lotus",
		ResultName = "Алый лотос",
		GrowthSeconds = 40,
	},
	{
		Id = "xb_frost_bamboo",
		SeedA = "seed_bamboo_labyrinth",
		SeedB = "seed_crystal_greenhouse",
		ResultItemId = "hyb_frost_bamboo",
		ResultName = "Кристальный бамбук",
		GrowthSeconds = 45,
	},
} :: { CrossbreedDef }

function Registry.FindCrossbreed(seedA: string, seedB: string): CrossbreedDef?
	for _, xb in ipairs(Registry.Crossbreeds) do
		if (xb.SeedA == seedA and xb.SeedB == seedB) or (xb.SeedA == seedB and xb.SeedB == seedA) then
			return xb
		end
	end
	return nil
end

return Registry`,
  },
  {
    id: 'skill_quest_config',
    name: 'SkillAndQuestConfig',
    className: 'ModuleScript',
    service: 'ReplicatedStorage',
    folder: 'BotaniaShared',
    robloxPath: 'ReplicatedStorage/BotaniaShared/SkillAndQuestConfig',
    summary: '3 ветки древа навыков, квесты исследования, достижения, магазин лобби и советы по выживанию в биомах для телепортации.',
    apis: ['Table', 'Color3'],
    code: `--!strict
-- ReplicatedStorage/BotaniaShared/SkillAndQuestConfig (ModuleScript)
local Config = {}

Config.Skills = {
	{ Id = "bot_harvest", Branch = "Ботаник", Name = "Чуткий сборщик", Desc = "+1 бонусный ресурс при рубке флоры", Cost = 1, Prereq = nil },
	{ Id = "bot_hybrid", Branch = "Ботаник", Name = "Селекционер", Desc = "Ускоряет рост грядок и скрещивание на 40%", Cost = 2, Prereq = "bot_harvest" },
	{ Id = "arch_saver", Branch = "Био-Инженер", Name = "Экономный чертёж", Desc = "Скидка 20% ресурсов при крафте и стройке", Cost = 1, Prereq = nil },
	{ Id = "arch_blueprint", Branch = "Био-Инженер", Name = "Архитектор куполов", Desc = "Открывает Алтарь семян (защита от токсичных спор)", Cost = 2, Prereq = "arch_saver" },
	{ Id = "path_sprint", Branch = "Следопыт", Name = "Лёгкий шаг", Desc = "+20% скорость бега и -25% урона от падения", Cost = 1, Prereq = nil },
	{ Id = "path_radar", Branch = "Следопыт", Name = "Био-компас отряда", Desc = "Увеличенный радиус миникарты и поиск союзников", Cost = 2, Prereq = "path_sprint" },
}

Config.LobbyUpgrades = {
	{ Id = "upg_gold_aura", Name = "Корона хлорофилла", CostFlorins = 120, Desc = "+15 к максимальной стамине" },
	{ Id = "upg_fast_axe", Name = "Солнечная гравировка", CostFlorins = 180, Desc = "+20% к скорости взмаха топора" },
	{ Id = "upg_spore_resist", Name = "Адаптивный иммунитет", CostFlorins = 240, Desc = "-40% урона от токсичных биомов" },
}

Config.DeveloperProducts = {
	[900001] = 100,
	[900002] = 350,
	[900003] = 900,
}

Config.BiomeSurvivalTips = {
${BIOME_SURVIVAL_TIPS_LUAU}
}

function Config.GetTipsForTeleport(direction: string, activeBiomeIds: { string }?): { any }
	local prioritized = {}
	local fallback = {}
	local activeLookup: { [string]: boolean } = {}
	if activeBiomeIds then
		for _, id in ipairs(activeBiomeIds) do
			activeLookup[id] = true
		end
	end

	for _, tip in ipairs(Config.BiomeSurvivalTips) do
		if tip.Direction == direction or tip.Direction == "Both" then
			if direction == "ToWorld" and activeLookup[tip.BiomeId] then
				table.insert(prioritized, tip)
			else
				table.insert(fallback, tip)
			end
		end
	end

	for _, item in ipairs(fallback) do
		table.insert(prioritized, item)
	end
	return prioritized
end

return Config`,
  },
];
