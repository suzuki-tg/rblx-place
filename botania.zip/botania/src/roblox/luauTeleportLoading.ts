import { RobloxScriptDef } from './luauShared';

export const TELEPORT_LOADING_SCRIPT: RobloxScriptDef = {
  id: 'teleport_loading_screen',
  name: 'TeleportLoadingScreen',
  className: 'ModuleScript',
  service: 'ReplicatedStorage',
  folder: 'BotaniaShared',
  robloxPath: 'ReplicatedStorage/BotaniaShared/TeleportLoadingScreen',
  summary:
    'Модульный UI-компонент динамического загрузочного экрана телепортации (Мир <-> Лобби) с советами по выживанию в биомах, шкалой ContentProvider и TeleportService:SetTeleportGui.',
  apis: ['TeleportService', 'TweenService', 'ContentProvider', 'RunService'],
  code: `--!strict
-- ReplicatedStorage/BotaniaShared/TeleportLoadingScreen (ModuleScript)
-- Компонент динамического загрузочного экрана при телепортации между Миром и Лобби
local ContentProvider = game:GetService("ContentProvider")
local RunService = game:GetService("RunService")
local TeleportService = game:GetService("TeleportService")
local TweenService = game:GetService("TweenService")

local SkillConfig = require(script.Parent:WaitForChild("SkillAndQuestConfig"))

export type TeleportDirection = "ToWorld" | "ToLobby"

export type BiomeTipEntry = {
	Id: string,
	Direction: string,
	BiomeId: string,
	BiomeName: string,
	Toxicity: number,
	AccentColor: Color3,
	Headline: string,
	Tip: string,
	RecommendedGear: string,
}

export type TeleportPayload = {
	Direction: TeleportDirection?,
	WorldSeed: number?,
	PartySize: number?,
	ActiveBiomeIds: { string }?,
	Tips: { BiomeTipEntry }?,
}

export type LoadingScreenComponent = {
	ScreenGui: ScreenGui,
	RootFrame: Frame,
	IsVisible: boolean,
	SetDestination: (self: LoadingScreenComponent, direction: TeleportDirection, payload: TeleportPayload?) -> (),
	Show: (self: LoadingScreenComponent, payload: TeleportPayload?) -> (),
	UpdateProgress: (self: LoadingScreenComponent, fraction: number, stageText: string) -> (),
	PreloadAssets: (self: LoadingScreenComponent, instances: { Instance }) -> (),
	NextTip: (self: LoadingScreenComponent) -> (),
	Hide: (self: LoadingScreenComponent) -> (),
	Destroy: (self: LoadingScreenComponent) -> (),
}

local TeleportLoadingScreen = {}
TeleportLoadingScreen.__index = TeleportLoadingScreen

local LOADING_STAGES_WORLD = {
	"Синхронизация облачного профиля DataStore...",
	"Выбор 8 уникальных биомов из 30...",
	"Инициализация групп коллизий PhysicsService...",
	"Генерация воксельного рельефа, флоры и фауны...",
}

local LOADING_STAGES_LOBBY = {
	"Сохранение инвентаря и ресурсов в DataStore...",
	"Подключение к комнате отряда (до 4 игроков)...",
	"Обновление баланса Флоринов и древа навыков...",
}

local function makeText(props: {
	Name: string,
	Size: UDim2,
	Position: UDim2?,
	Font: Enum.Font?,
	TextSize: number?,
	TextColor3: Color3?,
	TextXAlignment: Enum.TextXAlignment?,
	TextWrapped: boolean?,
	Text: string?,
	Parent: Instance,
}): TextLabel
	local lbl = Instance.new("TextLabel")
	lbl.Name = props.Name
	lbl.Size = props.Size
	lbl.Position = props.Position or UDim2.new()
	lbl.BackgroundTransparency = 1
	lbl.Font = props.Font or Enum.Font.GothamMedium
	lbl.TextSize = props.TextSize or 15
	lbl.TextColor3 = props.TextColor3 or Color3.fromRGB(238, 242, 245)
	lbl.TextXAlignment = props.TextXAlignment or Enum.TextXAlignment.Left
	lbl.TextWrapped = if props.TextWrapped == nil then true else props.TextWrapped
	lbl.Text = props.Text or ""
	lbl.Parent = props.Parent
	return lbl
end

function TeleportLoadingScreen.new(parentGui: Instance?): LoadingScreenComponent
	local self = setmetatable({}, TeleportLoadingScreen) :: any
	self.IsVisible = false
	self._tips = {} :: { BiomeTipEntry }
	self._tipIndex = 1
	self._cycleToken = 0
	self._connections = {} :: { RBXScriptConnection }

	-- 1. Корневой ScreenGui (сохраняется при TeleportService:SetTeleportGui)
	local gui = Instance.new("ScreenGui")
	gui.Name = "BotaniaTeleportScreen"
	gui.IgnoreGuiInset = true
	gui.ResetOnSpawn = false
	gui.DisplayOrder = 120
	gui.Enabled = false
	if parentGui then
		gui.Parent = parentGui
	end
	self.ScreenGui = gui

	-- 2. Фон с динамическим градиентом под целевой биом
	local backdrop = Instance.new("Frame")
	backdrop.Name = "Backdrop"
	backdrop.Size = UDim2.fromScale(1, 1)
	backdrop.BackgroundColor3 = Color3.fromRGB(11, 18, 20)
	backdrop.BorderSizePixel = 0
	backdrop.Parent = gui
	self.RootFrame = backdrop

	local gradient = Instance.new("UIGradient")
	gradient.Rotation = 135
	gradient.Color = ColorSequence.new(Color3.fromRGB(12, 22, 24), Color3.fromRGB(20, 42, 32))
	gradient.Parent = backdrop
	self._bgGradient = gradient

	local layout = Instance.new("UIListLayout")
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	layout.VerticalAlignment = Enum.VerticalAlignment.Center
	layout.Padding = UDim.new(0, 18)
	layout.Parent = backdrop

	-- 3. Верхний заголовок маршрута (Лобби <-> Мир)
	local topHeader = Instance.new("Frame")
	topHeader.Name = "TopRouteHeader"
	topHeader.Size = UDim2.new(0.9, 0, 0, 46)
	topHeader.BackgroundTransparency = 1
	topHeader.Parent = backdrop

	local headerConstraint = Instance.new("UISizeConstraint")
	headerConstraint.MaxSize = Vector2.new(680, 46)
	headerConstraint.Parent = topHeader

	self._routeLabel = makeText({
		Name = "RouteBadge",
		Size = UDim2.fromScale(0.65, 1),
		Font = Enum.Font.GothamBold,
		TextSize = 18,
		TextColor3 = Color3.fromRGB(34, 197, 94),
		Text = "ЛОББИ -> МИР BOTANIA",
		Parent = topHeader,
	})

	self._metaLabel = makeText({
		Name = "SquadMeta",
		Size = UDim2.fromScale(0.35, 1),
		Position = UDim2.fromScale(0.65, 0),
		Font = Enum.Font.Code,
		TextSize = 13,
		TextColor3 = Color3.fromRGB(159, 176, 186),
		TextXAlignment = Enum.TextXAlignment.Right,
		Text = "Отряд: 1/4 · 8 биомов",
		Parent = topHeader,
	})

	-- 4. Центральная карточка совета по выживанию в биоме
	local card = Instance.new("Frame")
	card.Name = "SurvivalTipCard"
	card.Size = UDim2.new(0.9, 0, 0, 236)
	card.BackgroundColor3 = Color3.fromRGB(20, 27, 31)
	card.BorderSizePixel = 0
	card.Parent = backdrop
	self._card = card

	local cardConstraint = Instance.new("UISizeConstraint")
	cardConstraint.MaxSize = Vector2.new(680, 260)
	cardConstraint.Parent = card

	local cardCorner = Instance.new("UICorner")
	cardCorner.CornerRadius = UDim.new(0, 14)
	cardCorner.Parent = card

	local cardStroke = Instance.new("UIStroke")
	cardStroke.Color = Color3.fromRGB(38, 52, 61)
	cardStroke.Thickness = 1.5
	cardStroke.Parent = card
	self._cardStroke = cardStroke

	local accentBar = Instance.new("Frame")
	accentBar.Name = "BiomeAccentBar"
	accentBar.Size = UDim2.new(0, 6, 1, -24)
	accentBar.Position = UDim2.fromOffset(14, 12)
	accentBar.BackgroundColor3 = Color3.fromRGB(34, 197, 94)
	accentBar.BorderSizePixel = 0
	accentBar.Parent = card
	self._accentBar = accentBar

	local accentCorner = Instance.new("UICorner")
	accentCorner.CornerRadius = UDim.new(0, 3)
	accentCorner.Parent = accentBar

	self._biomeLabel = makeText({
		Name = "BiomeNameLabel",
		Size = UDim2.new(0.6, -34, 0, 24),
		Position = UDim2.fromOffset(34, 16),
		Font = Enum.Font.GothamBold,
		TextSize = 14,
		TextColor3 = Color3.fromRGB(56, 189, 248),
		Text = "Изумрудная Роща",
		Parent = card,
	})

	self._toxicityLabel = makeText({
		Name = "ToxicityMeter",
		Size = UDim2.new(0.4, -20, 0, 24),
		Position = UDim2.new(0.6, 0, 0, 16),
		Font = Enum.Font.Code,
		TextSize = 13,
		TextColor3 = Color3.fromRGB(34, 197, 94),
		TextXAlignment = Enum.TextXAlignment.Right,
		Text = "Токсичность: 0/3",
		Parent = card,
	})

	self._tipHeadline = makeText({
		Name = "SurvivalTipHeadline",
		Size = UDim2.new(1, -54, 0, 32),
		Position = UDim2.fromOffset(34, 48),
		Font = Enum.Font.GothamBold,
		TextSize = 20,
		TextColor3 = Color3.fromRGB(255, 255, 255),
		Text = "Совет по выживанию",
		Parent = card,
	})

	self._tipBody = makeText({
		Name = "SurvivalTipBody",
		Size = UDim2.new(1, -54, 0, 88),
		Position = UDim2.fromOffset(34, 86),
		Font = Enum.Font.Gotham,
		TextSize = 15,
		TextColor3 = Color3.fromRGB(190, 206, 214),
		Text = "",
		Parent = card,
	})

	self._gearLabel = makeText({
		Name = "RecommendedGearLabel",
		Size = UDim2.new(0.68, -34, 0, 28),
		Position = UDim2.new(0, 34, 1, -42),
		Font = Enum.Font.GothamMedium,
		TextSize = 13,
		TextColor3 = Color3.fromRGB(143, 163, 174),
		Text = "Снаряжение: Ботанический топор",
		Parent = card,
	})

	local nextBtn = Instance.new("TextButton")
	nextBtn.Name = "NextTipButton"
	nextBtn.Size = UDim2.fromOffset(146, 30)
	nextBtn.Position = UDim2.new(1, -162, 1, -44)
	nextBtn.BackgroundColor3 = Color3.fromRGB(26, 36, 41)
	nextBtn.BorderSizePixel = 0
	nextBtn.Font = Enum.Font.GothamSemibold
	nextBtn.TextSize = 12
	nextBtn.TextColor3 = Color3.fromRGB(238, 242, 245)
	nextBtn.Text = "Следующий совет"
	nextBtn.Parent = card

	local btnCorner = Instance.new("UICorner")
	btnCorner.CornerRadius = UDim.new(0, 8)
	btnCorner.Parent = nextBtn

	table.insert(self._connections, nextBtn.Activated:Connect(function()
		self:NextTip()
	end))

	-- 5. Нижняя секция прогресса и спиннер
	local footer = Instance.new("Frame")
	footer.Name = "BottomProgressSection"
	footer.Size = UDim2.new(0.9, 0, 0, 56)
	footer.BackgroundTransparency = 1
	footer.Parent = backdrop

	local footerConstraint = Instance.new("UISizeConstraint")
	footerConstraint.MaxSize = Vector2.new(680, 56)
	footerConstraint.Parent = footer

	local spinner = Instance.new("Frame")
	spinner.Name = "SpinnerRing"
	spinner.Size = UDim2.fromOffset(18, 18)
	spinner.Position = UDim2.fromOffset(0, 4)
	spinner.BackgroundColor3 = Color3.fromRGB(34, 197, 94)
	spinner.BorderSizePixel = 0
	spinner.Parent = footer
	self._spinner = spinner

	local spinCorner = Instance.new("UICorner")
	spinCorner.CornerRadius = UDim.new(0, 4)
	spinCorner.Parent = spinner

	self._stageLabel = makeText({
		Name = "StageStatusLabel",
		Size = UDim2.new(1, -30, 0, 24),
		Position = UDim2.fromOffset(28, 0),
		Font = Enum.Font.GothamMedium,
		TextSize = 13,
		TextColor3 = Color3.fromRGB(181, 196, 204),
		Text = LOADING_STAGES_WORLD[1],
		Parent = footer,
	})

	local track = Instance.new("Frame")
	track.Name = "ProgressBarTrack"
	track.Size = UDim2.new(1, 0, 0, 8)
	track.Position = UDim2.fromOffset(0, 34)
	track.BackgroundColor3 = Color3.fromRGB(28, 38, 44)
	track.BorderSizePixel = 0
	track.Parent = footer

	local trackCorner = Instance.new("UICorner")
	trackCorner.CornerRadius = UDim.new(1, 0)
	trackCorner.Parent = track

	local fill = Instance.new("Frame")
	fill.Name = "ProgressBarFill"
	fill.Size = UDim2.fromScale(0.12, 1)
	fill.BackgroundColor3 = Color3.fromRGB(34, 197, 94)
	fill.BorderSizePixel = 0
	fill.Parent = track
	self._progressFill = fill

	local fillCorner = Instance.new("UICorner")
	fillCorner.CornerRadius = UDim.new(1, 0)
	fillCorner.Parent = fill

	return self :: LoadingScreenComponent
end

function TeleportLoadingScreen:_renderTip(tip: BiomeTipEntry)
	self._accentBar.BackgroundColor3 = tip.AccentColor
	self._cardStroke.Color = tip.AccentColor
	self._biomeLabel.Text = tip.BiomeName
	self._biomeLabel.TextColor3 = tip.AccentColor

	local toxText = if tip.Toxicity == 0
		then "Токсичность: 0/3 · Безопасно"
		elseif tip.Toxicity <= 2 then "Токсичность: " .. tostring(tip.Toxicity) .. "/3 · Споры"
		else "Токсичность: 3/3 · Опасно!"
	self._toxicityLabel.Text = toxText
	self._toxicityLabel.TextColor3 = if tip.Toxicity == 0
		then Color3.fromRGB(34, 197, 94)
		elseif tip.Toxicity <= 2 then Color3.fromRGB(245, 158, 11)
		else Color3.fromRGB(239, 68, 68)

	self._tipHeadline.Text = tip.Headline
	self._tipBody.Text = tip.Tip
	self._gearLabel.Text = "Рекомендация: " .. tip.RecommendedGear

	-- Плавная анимация появления текста совета
	self._tipHeadline.TextTransparency = 0.7
	self._tipBody.TextTransparency = 0.7
	TweenService:Create(self._tipHeadline, TweenInfo.new(0.28), { TextTransparency = 0 }):Play()
	TweenService:Create(self._tipBody, TweenInfo.new(0.28), { TextTransparency = 0 }):Play()
end

function TeleportLoadingScreen:SetDestination(direction: TeleportDirection, payload: TeleportPayload?)
	local seedText = if payload and payload.WorldSeed then "Сид #" .. tostring(payload.WorldSeed) else "8 биомов"
	local partyText = "Отряд: " .. tostring(if payload and payload.PartySize then payload.PartySize else 1) .. "/4"

	if direction == "ToLobby" then
		self._routeLabel.Text = "МИР BOTANIA -> ЛОББИ ОТРЯДА"
		self._routeLabel.TextColor3 = Color3.fromRGB(56, 189, 248)
		self._metaLabel.Text = partyText .. " · Облачное сохранение"
		self._bgGradient.Color = ColorSequence.new(Color3.fromRGB(13, 20, 29), Color3.fromRGB(22, 34, 48))
	else
		self._routeLabel.Text = "ЛОББИ -> МИР BOTANIA"
		self._routeLabel.TextColor3 = Color3.fromRGB(34, 197, 94)
		self._metaLabel.Text = partyText .. " · " .. seedText
		self._bgGradient.Color = ColorSequence.new(Color3.fromRGB(12, 22, 24), Color3.fromRGB(20, 42, 32))
	end

	local tipsList = if payload and payload.Tips and #payload.Tips > 0
		then payload.Tips
		else SkillConfig.GetTipsForTeleport(direction, if payload then payload.ActiveBiomeIds else nil)

	self._tips = tipsList
	self._tipIndex = 1
	if #self._tips > 0 then
		self:_renderTip(self._tips[1])
	end
end

function TeleportLoadingScreen:NextTip()
	if #self._tips == 0 then return end
	self._tipIndex = (self._tipIndex % #self._tips) + 1
	self:_renderTip(self._tips[self._tipIndex])
end

function TeleportLoadingScreen:UpdateProgress(fraction: number, stageText: string)
	local clamped = math.clamp(fraction, 0.05, 1)
	self._stageLabel.Text = stageText
	TweenService:Create(
		self._progressFill,
		TweenInfo.new(0.32, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Size = UDim2.fromScale(clamped, 1) }
	):Play()
end

function TeleportLoadingScreen:PreloadAssets(instances: { Instance })
	if #instances == 0 then return end
	local done = 0
	local total = #instances
	pcall(function()
		ContentProvider:PreloadAsync(instances, function()
			done += 1
			local pct = 0.25 + (done / total) * 0.7
			self:UpdateProgress(pct, string.format("Загрузка биомов и 3D-моделей (%d/%d)...", done, total))
		end)
	end)
end

function TeleportLoadingScreen:Show(payload: TeleportPayload?)
	local dir: TeleportDirection = if payload and payload.Direction then payload.Direction else "ToWorld"
	self:SetDestination(dir, payload)

	self.IsVisible = true
	self.ScreenGui.Enabled = true
	self.RootFrame.BackgroundTransparency = 0

	-- Привязываем экран к TeleportService, чтобы он не пропадал при переходе между плейсами
	pcall(function()
		TeleportService:SetTeleportGui(self.ScreenGui)
	end)

	local stages = if dir == "ToLobby" then LOADING_STAGES_LOBBY else LOADING_STAGES_WORLD
	self:UpdateProgress(0.18, stages[1])

	self._cycleToken += 1
	local token = self._cycleToken

	if self._spinConn then
		self._spinConn:Disconnect()
	end
	self._spinConn = RunService.RenderStepped:Connect(function(dt)
		if not self.IsVisible then return end
		self._spinner.Rotation = (self._spinner.Rotation + dt * 180) % 360
	end)

	-- Автоматическая смена советов каждые 3.5 секунды и обновление стадий
	task.spawn(function()
		local stageIdx = 1
		while self.IsVisible and self._cycleToken == token do
			task.wait(3.5)
			if not self.IsVisible or self._cycleToken ~= token then break end
			self:NextTip()
			stageIdx = math.min(stageIdx + 1, #stages)
			self:UpdateProgress(0.2 + (stageIdx / #stages) * 0.72, stages[stageIdx])
		end
	end)
end

function TeleportLoadingScreen:Hide()
	if not game:IsLoaded() then
		game.Loaded:Wait()
	end
	self:UpdateProgress(1, "Готово! Добро пожаловать.")
	task.wait(0.35)
	self.IsVisible = false
	self._cycleToken += 1
	if self._spinConn then
		self._spinConn:Disconnect()
		self._spinConn = nil
	end
	self.ScreenGui.Enabled = false
end

function TeleportLoadingScreen:Destroy()
	self.IsVisible = false
	self._cycleToken += 1
	if self._spinConn then
		self._spinConn:Disconnect()
		self._spinConn = nil
	end
	for _, conn in ipairs(self._connections) do
		conn:Disconnect()
	end
	table.clear(self._connections)
	self.ScreenGui:Destroy()
end

return TeleportLoadingScreen`,
};
