import { RobloxScriptDef } from './luauShared';

export const QUEST_SYSTEM_SCRIPT: RobloxScriptDef = {
  id: 'quest_system',
  name: 'QuestSystem',
  className: 'ModuleScript',
  service: 'ServerScriptService',
  folder: 'BotaniaServer',
  robloxPath: 'ServerScriptService/BotaniaServer/QuestSystem',
  summary:
    'Серверная система процедурных заданий при входе в биом (сбор уникальных кристаллов/ресурсов, постройка базы в токсичном биоме, рубка флоры, культивация), трекинг прогресса и выдача Флоринов.',
  apis: ['Players', 'ReplicatedStorage', 'Random', 'RunService'],
  code: `--!strict
-- ServerScriptService/BotaniaServer/QuestSystem (ModuleScript)
-- Процедурные задания биомов, отслеживание прогресса на сервере и награждение Флоринами
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local BiomeRegistry = require(Shared:WaitForChild("BiomeRegistry"))

local DataStoreManager = require(script.Parent.DataStoreManager)
local AntiCheatEngine = require(script.Parent.AntiCheatEngine)

export type QuestKind =
	| "CollectUniqueResource"
	| "BuildToxicOutpost"
	| "HarvestBiomeFlora"
	| "CultivateBiomeSeed"

export type ActiveBiomeQuest = {
	Id: string,
	Kind: QuestKind,
	BiomeId: string,
	BiomeName: string,
	ToxicityLevel: number,
	Title: string,
	Description: string,
	TargetItemId: string?,
	Progress: number,
	Target: number,
	RewardFlorins: number,
	RewardXP: number,
	Completed: boolean,
}

type PlayerQuestState = {
	ActiveQuests: { ActiveBiomeQuest },
	VisitedWorldBiomes: { [string]: boolean },
	LastBiomeId: string?,
	BiomeQuestCooldownUntil: { [string]: number },
}

local QuestSystem = {}
local MAX_ACTIVE_QUESTS = 3
local BIOME_QUEST_COOLDOWN_SEC = 180

local PlayerStates: { [number]: PlayerQuestState } = {}
local ActiveBiomeCenters: { { Biome: BiomeRegistry.BiomeDef, X: number, Z: number } } = {}
local QuestUpdateRemote: RemoteEvent? = nil
local started = false

local function getOrCreateState(player: Player): PlayerQuestState
	local existing = PlayerStates[player.UserId]
	if existing then
		return existing
	end
	local created: PlayerQuestState = {
		ActiveQuests = {},
		VisitedWorldBiomes = {},
		LastBiomeId = nil,
		BiomeQuestCooldownUntil = {},
	}
	PlayerStates[player.UserId] = created
	return created
end

-- Расчёт уровня по формуле Botania (100 + (level - 1) * 50)
local function applyXpAndLevelUp(profile: DataStoreManager.PlayerProfile, xpGain: number)
	profile.XP += math.max(0, math.floor(xpGain))
	local threshold = 100 + (profile.Level - 1) * 50
	while profile.XP >= threshold and profile.Level < 500 do
		profile.XP -= threshold
		profile.Level += 1
		profile.SkillPoints += 1
		threshold = 100 + (profile.Level - 1) * 50
	end
end

local function emitQuestSync(player: Player, eventName: string, quest: ActiveBiomeQuest?, bonusText: string?)
	if not QuestUpdateRemote then return end
	local state = getOrCreateState(player)
	local profile = DataStoreManager.GetProfile(player)
	QuestUpdateRemote:FireClient(player, {
		Event = eventName,
		Quest = quest,
		ActiveQuests = state.ActiveQuests,
		Florins = if profile then profile.Florins else 0,
		XP = if profile then profile.XP else 0,
		Level = if profile then profile.Level else 1,
		Notice = bonusText,
	})
end

-- Генератор процедурного задания под параметры конкретного биома
function QuestSystem.GenerateProceduralQuest(
	player: Player,
	biome: BiomeRegistry.BiomeDef,
	worldSeed: number
): ActiveBiomeQuest
	local rng = Random.new(worldSeed + (player.UserId % 100000) + biome.Index * 97 + math.floor(os.clock()))
	local tox = biome.ToxicityLevel

	local candidates: { QuestKind } = { "CollectUniqueResource", "HarvestBiomeFlora", "CultivateBiomeSeed" }
	if tox >= 2 then
		-- В токсичных биомах повышаем шанс задания на постройку защищённой базы
		table.insert(candidates, "BuildToxicOutpost")
		table.insert(candidates, "BuildToxicOutpost")
	end

	-- Кристальные биомы приоритетно выдают сбор кристаллов
	local isCrystalBiome = biome.FloraType == "crystal"
		or string.find(string.lower(biome.UniqueResourceName), "кристалл") ~= nil
	if isCrystalBiome then
		table.insert(candidates, "CollectUniqueResource")
		table.insert(candidates, "CollectUniqueResource")
	end

	local kind = candidates[rng:NextInteger(1, #candidates)]
	local questId = string.format("pq_%s_%s_%d", biome.Id, kind, rng:NextInteger(100, 999))

	if kind == "BuildToxicOutpost" then
		local targetBlocks = rng:NextInteger(3, 5)
		local rewardFlorins = 90 + tox * 35 + targetBlocks * 10
		return {
			Id = questId,
			Kind = kind,
			BiomeId = biome.Id,
			BiomeName = biome.Name,
			ToxicityLevel = tox,
			Title = "Форпост в токсичной зоне",
			Description = string.format(
				"Построить базу в биоме с высокой токсичностью «%s» (установите %d блока стены/алтаря)",
				biome.Name,
				targetBlocks
			),
			TargetItemId = nil,
			Progress = 0,
			Target = targetBlocks,
			RewardFlorins = rewardFlorins,
			RewardXP = 110 + tox * 30,
			Completed = false,
		}
	elseif kind == "HarvestBiomeFlora" then
		local targetTrees = rng:NextInteger(3, 6)
		local rewardFlorins = 35 + targetTrees * 8 + tox * 20
		return {
			Id = questId,
			Kind = kind,
			BiomeId = biome.Id,
			BiomeName = biome.Name,
			ToxicityLevel = tox,
			Title = "Расчистка чащи: " .. biome.Name,
			Description = string.format(
				"Срубить %d ед. уникальной флоры в биоме «%s»",
				targetTrees,
				biome.Name
			),
			TargetItemId = nil,
			Progress = 0,
			Target = targetTrees,
			RewardFlorins = rewardFlorins,
			RewardXP = 65 + targetTrees * 12,
			Completed = false,
		}
	elseif kind == "CultivateBiomeSeed" then
		local targetSeeds = rng:NextInteger(2, 3)
		local rewardFlorins = 55 + targetSeeds * 15 + tox * 20
		return {
			Id = questId,
			Kind = kind,
			BiomeId = biome.Id,
			BiomeName = biome.Name,
			ToxicityLevel = tox,
			Title = "Ботаник-селекционер",
			Description = string.format(
				"Посадить на грядки %d семян («Семя: %s»)",
				targetSeeds,
				biome.Name
			),
			TargetItemId = biome.SeedId,
			Progress = 0,
			Target = targetSeeds,
			RewardFlorins = rewardFlorins,
			RewardXP = 80 + targetSeeds * 20,
			Completed = false,
		}
	end

	-- CollectUniqueResource (по умолчанию)
	local targetCount = if isCrystalBiome then 10 else rng:NextInteger(6, 10)
	local desc = if isCrystalBiome
		then string.format("Собрать %d уникальных кристаллов («%s») в биоме «%s»", targetCount, biome.UniqueResourceName, biome.Name)
		else string.format("Собрать %d ед. ресурса «%s» в биоме «%s»", targetCount, biome.UniqueResourceName, biome.Name)

	return {
		Id = questId,
		Kind = "CollectUniqueResource",
		BiomeId = biome.Id,
		BiomeName = biome.Name,
		ToxicityLevel = tox,
		Title = if isCrystalBiome then "Охотник за кристаллами" else "Сборщик: " .. biome.Name,
		Description = desc,
		TargetItemId = biome.UniqueResourceId,
		Progress = 0,
		Target = targetCount,
		RewardFlorins = 45 + targetCount * 5 + tox * 25,
		RewardXP = 70 + targetCount * 6 + tox * 20,
		Completed = false,
	}
end

local function completeQuest(player: Player, state: PlayerQuestState, index: number)
	local quest = state.ActiveQuests[index]
	if not quest or quest.Completed then return end
	quest.Completed = true
	quest.Progress = quest.Target
	state.BiomeQuestCooldownUntil[quest.BiomeId] = os.clock() + BIOME_QUEST_COOLDOWN_SEC

	local profile = DataStoreManager.GetProfile(player)
	if profile then
		-- Обязательно авторизуем награду в AntiCheatEngine, чтобы аудит DataStore не откатил Флорины
		AntiCheatEngine.AuthorizeFlorinGrant(player, quest.RewardFlorins)
		profile.Florins += quest.RewardFlorins
		profile.CompletedQuests = profile.CompletedQuests or {}
		profile.CompletedQuests[quest.Id] = true
		applyXpAndLevelUp(profile, quest.RewardXP)
		DataStoreManager.SaveAsync(player, false)
	end

	table.remove(state.ActiveQuests, index)
	emitQuestSync(
		player,
		"Completed",
		quest,
		string.format("Задание выполнено! +%d Флоринов и +%d XP", quest.RewardFlorins, quest.RewardXP)
	)
end

local function advanceMatchingQuests(player: Player, predicate: (ActiveBiomeQuest) -> boolean, amount: number)
	if amount <= 0 then return end
	local state = getOrCreateState(player)

	for i = #state.ActiveQuests, 1, -1 do
		local q = state.ActiveQuests[i]
		if not q.Completed and predicate(q) then
			q.Progress = math.min(q.Target, q.Progress + amount)
			if q.Progress >= q.Target then
				completeQuest(player, state, i)
			else
				emitQuestSync(player, "Progress", q, nil)
			end
		end
	end
end

-- Хуки событий прогресса (вызываются серверными сервисами после проверок AntiCheatEngine)
function QuestSystem.RecordItemCollected(player: Player, itemId: string, count: number)
	advanceMatchingQuests(player, function(q)
		return q.Kind == "CollectUniqueResource" and q.TargetItemId == itemId
	end, count)
end

function QuestSystem.RecordBlockPlaced(player: Player, kind: string, worldPos: Vector3)
	if #ActiveBiomeCenters == 0 then return end
	local biome = BiomeRegistry.GetBiomeAt(worldPos.X, worldPos.Z, ActiveBiomeCenters)
	local stepBonus = if kind == "SeedAltar" then 2 else 1
	advanceMatchingQuests(player, function(q)
		return q.Kind == "BuildToxicOutpost" and (q.BiomeId == biome.Id or biome.ToxicityLevel >= 2)
	end, stepBonus)
end

function QuestSystem.RecordFloraFelled(player: Player, biomeId: string)
	advanceMatchingQuests(player, function(q)
		return q.Kind == "HarvestBiomeFlora" and q.BiomeId == biomeId
	end, 1)
end

function QuestSystem.RecordSeedPlanted(player: Player, seedId: string)
	advanceMatchingQuests(player, function(q)
		return q.Kind == "CultivateBiomeSeed" and q.TargetItemId == seedId
	end, 1)
end

-- Вызывается автоматически при переходе игрока в новый биом
function QuestSystem.OnPlayerEnteredBiome(player: Player, biome: BiomeRegistry.BiomeDef)
	local state = getOrCreateState(player)
	if state.LastBiomeId == biome.Id then
		return
	end
	state.LastBiomeId = biome.Id

	-- Первое открытие биома даёт исследовательский бонус в DataStore
	local profile = DataStoreManager.GetProfile(player)
	if profile and not profile.DiscoveredBiomes[biome.Id] then
		profile.DiscoveredBiomes[biome.Id] = true
		local discoveryFlorins = 15 + biome.ToxicityLevel * 10
		AntiCheatEngine.AuthorizeFlorinGrant(player, discoveryFlorins)
		profile.Florins += discoveryFlorins
		applyXpAndLevelUp(profile, 35)
		DataStoreManager.SaveAsync(player, false)
		emitQuestSync(
			player,
			"BiomeDiscovered",
			nil,
			string.format("Открыт биом «%s»! +%d Флоринов", biome.Name, discoveryFlorins)
		)
	end

	-- Проверяем, не активно ли уже задание для этого биома и не идёт ли кулдаун
	for _, existing in ipairs(state.ActiveQuests) do
		if existing.BiomeId == biome.Id then
			return
		end
	end
	local cooldownUntil = state.BiomeQuestCooldownUntil[biome.Id] or 0
	if os.clock() < cooldownUntil or #state.ActiveQuests >= MAX_ACTIVE_QUESTS then
		return
	end

	local worldSeed = (ReplicatedStorage:GetAttribute("WorldSeed") :: number?) or 10000
	local quest = QuestSystem.GenerateProceduralQuest(player, biome, worldSeed)
	table.insert(state.ActiveQuests, quest)
	state.VisitedWorldBiomes[biome.Id] = true
	emitQuestSync(player, "Assigned", quest, string.format("Новое задание в биоме «%s»!", biome.Name))
end

function QuestSystem.GetActiveQuests(player: Player): { ActiveBiomeQuest }
	return getOrCreateState(player).ActiveQuests
end

function QuestSystem.Start(biomeCenters: { { Biome: BiomeRegistry.BiomeDef, X: number, Z: number } })
	ActiveBiomeCenters = biomeCenters
	if started then return end
	started = true

	local remotes = ReplicatedStorage:WaitForChild("Remotes")
	QuestUpdateRemote = remotes:WaitForChild("QuestUpdate") :: RemoteEvent

	Players.PlayerAdded:Connect(function(player)
		getOrCreateState(player)
		task.defer(function()
			task.wait(1.5)
			if player.Parent then
				emitQuestSync(player, "Sync", nil, nil)
			end
		end)
	end)
	for _, p in ipairs(Players:GetPlayers()) do
		getOrCreateState(p)
	end
	Players.PlayerRemoving:Connect(function(player)
		PlayerStates[player.UserId] = nil
	end)

	-- Серверный трекер входа в биом каждые 0.5 сек (на стороне сервера, без доверия клиенту)
	task.spawn(function()
		while true do
			task.wait(0.5)
			if #ActiveBiomeCenters > 0 then
				for _, player in ipairs(Players:GetPlayers()) do
					local char = player.Character
					local root = if char then char:FindFirstChild("HumanoidRootPart") :: BasePart? else nil
					if root then
						local currentBiome = BiomeRegistry.GetBiomeAt(root.Position.X, root.Position.Z, ActiveBiomeCenters)
						QuestSystem.OnPlayerEnteredBiome(player, currentBiome)
					end
				end
			end
		end
	end)
end

return QuestSystem`,
};
