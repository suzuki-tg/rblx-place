import { RobloxScriptDef } from './luauShared';

export interface ExternalAssetPack {
  id: string;
  title: string;
  author: string;
  source: 'Roblox DevForum' | 'Quaternius CC0' | 'Kenney CC0' | 'Roblox Creator Store';
  license: string;
  formats: string;
  categories: string[];
  description: string;
  url: string;
  importTip: string;
}

export const EXTERNAL_ASSET_PACKS: ExternalAssetPack[] = [
  {
    id: 'quaternius_stylized_nature',
    title: 'Ultimate Stylized Nature Pack',
    author: 'Quaternius',
    source: 'Quaternius CC0',
    license: 'CC0 1.0 (Бесплатно без ограничений)',
    formats: 'FBX · OBJ · glTF · Blend',
    categories: ['Деревья', 'Трава', 'Цветы', 'Камни'],
    description: '60+ стилизованных моделей природы с готовыми текстурами и картами нормалей.',
    url: 'https://quaternius.com/packs/ultimatestylizednature.html',
    importTip: 'Импортируйте FBX через Asset Manager -> Bulk Import или Mesh Importer в Roblox Studio.',
  },
  {
    id: 'quaternius_nature_megakit',
    title: 'Stylized Nature MegaKit (110+ моделей)',
    author: 'Quaternius',
    source: 'Quaternius CC0',
    license: 'CC0 1.0 (Public Domain)',
    formats: 'FBX · glTF · Unity/Godot',
    categories: ['Сакура', 'Папоротники', 'Кусты', 'Цветы'],
    description: '110+ моделей флоры в яркой палитре: ветвистые деревья, трава, грибы и камни.',
    url: 'https://quaternius.itch.io',
    importTip: 'После импорта FBX установите DoubleSided = true на MeshPart листьев.',
  },
  {
    id: 'quaternius_animated_animals',
    title: 'Ultimate Animated Animal Pack',
    author: 'Quaternius',
    source: 'Quaternius CC0',
    license: 'CC0 1.0 (Public Domain)',
    formats: 'FBX с костями и анимациями (Walk, Run, Idle)',
    categories: ['Олени', 'Лисы', 'Волки', 'Животные'],
    description: '12+ риггированных животных с готовыми анимациями ходьбы, бега и покоя.',
    url: 'https://quaternius.com/packs/ultimateanimatedanimals.html',
    importTip: 'Используйте Import 3D в Roblox Studio с опцией Rig Type = Custom, затем загрузите клипы через Animation Editor.',
  },
  {
    id: 'kenney_nature_kit',
    title: 'Kenney Nature Kit (300+ ассетов)',
    author: 'Kenney.nl',
    source: 'Kenney CC0',
    license: 'CC0 1.0 (Public Domain)',
    formats: 'FBX · OBJ · glTF',
    categories: ['Воксель/Low-Poly', 'Деревья', 'Трава', 'Пни'],
    description: 'Более 300 лёгких low-poly моделей: деревья, кусты, трава, брёвна, камни и скалы.',
    url: 'https://kenney.nl/assets/nature-kit',
    importTip: 'Идеально оптимизированы по полигонам (< 400 треугольников) — отлично подходят для мобильного режима Botania.',
  },
  {
    id: 'devforum_lowpoly_archkr0',
    title: 'Low Poly Nature Pack (.rbxl + Blender)',
    author: 'Archkr0 (Roblox DevForum)',
    source: 'Roblox DevForum',
    license: 'Community Free Resource',
    formats: 'RBXL · Blend',
    categories: ['Деревья', 'Камни', 'Облака'],
    description: 'Готовый файл Roblox Studio .rbxl с настроенными низкополигональными деревьями и камнями.',
    url: 'https://devforum.roblox.com/c/resources/31',
    importTip: 'Откройте .rbxl, скопируйте папку Models и вставьте прямо в ReplicatedStorage/BotaniaAssets.',
  },
  {
    id: 'devforum_souppression',
    title: '20+ Stylized Low Poly Nature Assets',
    author: 'souppression (Roblox DevForum)',
    source: 'Roblox DevForum',
    license: 'Community Free Resource',
    formats: 'RBXM · Toolbox',
    categories: ['Грибы', 'Кусты', 'Деревья', 'Валуны'],
    description: 'Набор мультяшных грибов, деревьев и кустов с лёгкой перекраской под 30 биомов.',
    url: 'https://devforum.roblox.com/c/resources/31',
    importTip: 'Ищите в Toolbox Roblox Studio по запросам: "Low Poly Nature Pack", "Stylised Low-Poly Nature Pack DarkWatery".',
  },
];

export interface StudioModelSpec {
  category: 'Деревья и Флора' | 'Трава и Декор' | 'Животные и Фауна' | 'Инструменты и Предметы';
  name: string;
  partsCount: string;
  jointsAndEffects: string;
  collisionGroup: string;
}

export const STUDIO_MODEL_CATALOG: StudioModelSpec[] = [
  {
    category: 'Деревья и Флора',
    name: '8 многочастных архетипов (Oak, Sakura, Mushroom, Bamboo, Crystal, Cactus, Willow, Fern)',
    partsCount: '14–26 деталей',
    jointsAndEffects: 'Корни WedgePart, изогнутый ствол, 3-ярусная крона, светящиеся плоды, ParticleEmitter лепестков',
    collisionGroup: 'Ствол: FloraTrunks · Крона: FloraCanopy',
  },
  {
    category: 'Трава и Декор',
    name: 'Пучки травы, клевер с цветами, замшелые валуны, полые брёвна',
    partsCount: '5–9 деталей',
    jointsAndEffects: 'WedgePart-травинки с лёгким покачиванием на ветру и граненые CornerWedgePart камни',
    collisionGroup: 'Трава/цветы: FloraCanopy · Валуны: FloraTrunks',
  },
  {
    category: 'Животные и Фауна',
    name: '6 живых существ: Люмен-олень, Кристальная лисица, Моховая черепаха, Споровый жук, Бабочка, Шмель',
    partsCount: '10–18 деталей',
    jointsAndEffects: 'Motor6D-суставы ног, крыльев и хвоста с плавной анимацией бега, взмаха крыльев и поворота головы',
    collisionGroup: 'Fauna (без блокировки игрока)',
  },
  {
    category: 'Инструменты и Предметы',
    name: 'Ботанический топор, Нефритовый секатор, Лейка росы, Анализатор спор + 3D дроп ресурсов',
    partsCount: '7–12 деталей',
    jointsAndEffects: 'Настоящие Roblox Tool с WeldConstraint, гранеными WedgePart-лезвиями, свечением и каплями воды',
    collisionGroup: 'LootPickups (подбор по Touched)',
  },
];

export const MODEL_FACTORY_SCRIPT: RobloxScriptDef = {
  id: 'studio_model_factory',
  name: 'StudioModelFactory',
  className: 'ModuleScript',
  service: 'ReplicatedStorage',
  folder: 'BotaniaShared',
  robloxPath: 'ReplicatedStorage/BotaniaShared/StudioModelFactory',
  summary: 'Студийная фабрика кастомных 3D-моделей: ветвистые деревья (14–26 деталей), трава, цветы, валуны, 6 анимированных животных (Олень, Лисица, Черепаха, Жук, Бабочка, Шмель), Tools и 3D-предметы.',
  apis: ['Instance', 'WedgePart', 'Motor6D', 'WeldConstraint', 'ParticleEmitter', 'CollectionService'],
  code: `--!strict
-- ReplicatedStorage/BotaniaShared/StudioModelFactory (ModuleScript)
-- Студийный генератор многочастных 3D-моделей без единой внешней зависимости rbxassetid
local CollectionService = game:GetService("CollectionService")

local Factory = {}

local function part(props: {
	Class: "Part" | "WedgePart" | "CornerWedgePart"?,
	Name: string?,
	Size: Vector3,
	CFrame: CFrame,
	Color: Color3,
	Material: Enum.Material?,
	Transparency: number?,
	Shape: Enum.PartType?,
	Anchored: boolean?,
	CanCollide: boolean?,
	CollisionGroup: string?,
	Parent: Instance,
}): BasePart
	local cls = props.Class or "Part"
	local p = Instance.new(cls) :: BasePart
	p.Name = props.Name or "MeshPiece"
	p.Size = props.Size
	p.CFrame = props.CFrame
	p.Color = props.Color
	p.Material = props.Material or Enum.Material.SmoothPlastic
	p.Transparency = props.Transparency or 0
	if p:IsA("Part") and props.Shape then
		p.Shape = props.Shape
	end
	p.Anchored = if props.Anchored == nil then true else props.Anchored
	p.CanCollide = if props.CanCollide == nil then true else props.CanCollide
	p.CollisionGroup = props.CollisionGroup or "Default"
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.Parent = props.Parent
	return p
end

local function weld(a: BasePart, b: BasePart)
	local w = Instance.new("WeldConstraint")
	w.Part0 = a
	w.Part1 = b
	w.Parent = a
end

local function shade(color: Color3, factor: number): Color3
	return Color3.new(
		math.clamp(color.R * factor, 0, 1),
		math.clamp(color.G * factor, 0, 1),
		math.clamp(color.B * factor, 0, 1)
	)
end

local function addAmbientParticles(parent: Instance, color: Color3, rate: number, speed: NumberRange, size: NumberSequence, accel: Vector3?): ParticleEmitter
	local emitter = Instance.new("ParticleEmitter")
	emitter.Name = "BotaniaParticle"
	emitter.Color = ColorSequence.new(color)
	emitter.Rate = rate
	emitter.Lifetime = NumberRange.new(1.8, 3.6)
	emitter.Speed = speed
	emitter.Size = size
	emitter.LightEmission = 0.45
	emitter.SpreadAngle = Vector2.new(45, 45)
	emitter.Acceleration = accel or Vector3.new(0, 1.2, 0)
	emitter.Parent = parent
	return emitter
end

-- 1. СТУДИЙНЫЕ ДЕРЕВЬЯ И ФЛОРА (14–26 деталей с корнями, ветвями, многослойной кроной и частицами)
function Factory.BuildStudioFlora(biome: any, pos: Vector3, rng: Random, parent: Instance): Model
	local model = Instance.new("Model")
	model.Name = "StudioFlora_" .. biome.Id
	local yaw = rng:NextNumber(0, math.pi * 2)
	local scale = rng:NextNumber(0.9, 1.18)
	local origin = CFrame.new(pos) * CFrame.Angles(0, yaw, 0)

	local primaryTrunk: BasePart

	if biome.FloraType == "oak" or biome.FloraType == "sakura" or biome.FloraType == "willow" then
		-- 4 клиновидных корня (WedgePart)
		for r = 0, 3 do
			local angle = (r / 4) * math.pi * 2 + 0.3
			part({
				Class = "WedgePart", Name = "Root_" .. r,
				Size = Vector3.new(1.1 * scale, 1.8 * scale, 2.2 * scale),
				CFrame = origin * CFrame.Angles(0, angle, 0) * CFrame.new(0, 0.9 * scale, 1.35 * scale),
				Color = shade(biome.TrunkColor, 0.88), Material = Enum.Material.Wood,
				CollisionGroup = "FloraTrunks", Parent = model,
			})
		end
		-- Двухсегментный слегка наклонённый ствол
		primaryTrunk = part({
			Name = "Trunk", Size = Vector3.new(1.9 * scale, 4.8 * scale, 1.9 * scale),
			CFrame = origin * CFrame.new(0, 2.4 * scale, 0) * CFrame.Angles(0.05, 0, 0.04),
			Color = biome.TrunkColor, Material = Enum.Material.Wood,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		local upperOrigin = origin * CFrame.new(0.2 * scale, 4.7 * scale, 0.2 * scale)
		part({
			Name = "TrunkUpper", Size = Vector3.new(1.4 * scale, 3.6 * scale, 1.4 * scale),
			CFrame = upperOrigin * CFrame.new(0, 1.7 * scale, 0) * CFrame.Angles(-0.07, 0.2, -0.05),
			Color = shade(biome.TrunkColor, 1.05), Material = Enum.Material.Wood,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		-- 3 боковые ветви + 3 яруса пышной кроны разной яркости
		for b = 1, 3 do
			local ba = (b / 3) * math.pi * 2 + 0.4
			local branchPivot = upperOrigin * CFrame.new(0, 1.8 * scale, 0) * CFrame.Angles(0, ba, 0)
			part({
				Name = "Branch_" .. b, Size = Vector3.new(0.65 * scale, 0.65 * scale, 3.4 * scale),
				CFrame = branchPivot * CFrame.Angles(0.45, 0, 0) * CFrame.new(0, 0, 1.6 * scale),
				Color = biome.TrunkColor, Material = Enum.Material.Wood,
				CollisionGroup = "FloraTrunks", Parent = model,
			})
			local tipPos = branchPivot * CFrame.Angles(0.45, 0, 0) * CFrame.new(0, 0.5 * scale, 3.2 * scale)
			part({
				Name = "CanopyCluster_" .. b, Size = Vector3.new(4.6 * scale, 2.6 * scale, 4.6 * scale),
				CFrame = tipPos, Color = if b == 1 then shade(biome.FloraColor, 1.08) else biome.FloraColor,
				CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
			-- Цветущие акценты / плоды на концах ветвей
			part({
				Name = "BlossomPod_" .. b, Size = Vector3.new(1.1 * scale, 0.9 * scale, 1.1 * scale),
				CFrame = tipPos * CFrame.new(0.8 * scale, -1.3 * scale, 0.5 * scale),
				Color = biome.AccentColor, Material = Enum.Material.Neon,
				CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
		end
		-- Главная верхушка кроны + опадающие лепестки/пыльца
		local crownTop = part({
			Name = "CrownApex", Size = Vector3.new(5.8 * scale, 2.8 * scale, 5.8 * scale),
			CFrame = upperOrigin * CFrame.new(0, 4.2 * scale, 0),
			Color = shade(biome.FloraColor, 1.12), CanCollide = false,
			CollisionGroup = "FloraCanopy", Parent = model,
		})
		if biome.FloraType == "sakura" or biome.FloraType == "willow" then
			local emitter = Instance.new("ParticleEmitter")
			emitter.Rate = 2.5
			emitter.Lifetime = NumberRange.new(3, 5)
			emitter.Speed = NumberRange.new(0.5, 1.8)
			emitter.Acceleration = Vector3.new(0.6, -2.5, 0.2)
			emitter.Size = NumberSequence.new(0.35, 0.15)
			emitter.Color = ColorSequence.new(biome.AccentColor)
			emitter.Parent = crownTop
		end
	elseif biome.FloraType == "mushroom" then
		primaryTrunk = part({
			Name = "Trunk", Size = Vector3.new(2.2 * scale, 6.2 * scale, 2.2 * scale),
			CFrame = origin * CFrame.new(0, 3.1 * scale, 0), Color = biome.TrunkColor,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		-- Юбка-кольцо под шляпкой + граненая многоуровневая шляпка + светящиеся жабры
		part({
			Name = "StemCollar", Size = Vector3.new(3.2 * scale, 0.5 * scale, 3.2 * scale),
			CFrame = origin * CFrame.new(0, 4.6 * scale, 0), Color = shade(biome.TrunkColor, 0.9),
			CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
		local gillGlow = part({
			Name = "GillGlow", Size = Vector3.new(6.2 * scale, 0.7 * scale, 6.2 * scale),
			CFrame = origin * CFrame.new(0, 6.1 * scale, 0), Color = biome.AccentColor,
			Material = Enum.Material.Neon, CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
		addAmbientParticles(gillGlow, biome.AccentColor, 3.2, NumberRange.new(0.6, 1.6), NumberSequence.new(0.32, 0.05), Vector3.new(0, 1.4, 0))
		part({
			Name = "CapMain", Size = Vector3.new(7.4 * scale, 1.8 * scale, 7.4 * scale),
			CFrame = origin * CFrame.new(0, 7.0 * scale, 0), Color = biome.FloraColor,
			CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
		part({
			Name = "CapCrown", Size = Vector3.new(4.6 * scale, 1.3 * scale, 4.6 * scale),
			CFrame = origin * CFrame.new(0, 8.3 * scale, 0), Color = shade(biome.FloraColor, 1.1),
			CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
		for s = 1, 5 do
			local sa = (s / 5) * math.pi * 2
			part({
				Name = "CapSpot_" .. s, Size = Vector3.new(1.0 * scale, 0.35 * scale, 1.0 * scale),
				CFrame = origin * CFrame.Angles(0, sa, 0) * CFrame.new(2.2 * scale, 7.95 * scale, 0),
				Color = Color3.fromRGB(248, 250, 252), CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
		end
	elseif biome.FloraType == "crystal" then
		-- Каменный постамент + 5 разнонаправленных кристальных игл + внутренний свет
		for b = 1, 3 do
			part({
				Class = "CornerWedgePart", Name = "RockCluster_" .. b,
				Size = Vector3.new(2.6 * scale, 1.5 * scale, 2.6 * scale),
				CFrame = origin * CFrame.Angles(0, b * 2.1, 0) * CFrame.new(1.0 * scale, 0.75 * scale, 0),
				Color = Color3.fromRGB(72, 82, 92), Material = Enum.Material.Slate,
				CollisionGroup = "FloraTrunks", Parent = model,
			})
		end
		primaryTrunk = part({
			Name = "Trunk", Size = Vector3.new(2.1 * scale, 9.2 * scale, 2.1 * scale),
			CFrame = origin * CFrame.new(0, 4.6 * scale, 0) * CFrame.Angles(0.08, 0.4, 0.08),
			Color = biome.FloraColor, Material = Enum.Material.Glass, Transparency = 0.18,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		for c = 1, 4 do
			local ca = (c / 4) * math.pi * 2
			part({
				Name = "CrystalSpire_" .. c, Size = Vector3.new(1.3 * scale, (4.5 + c * 0.7) * scale, 1.3 * scale),
				CFrame = origin * CFrame.Angles(0, ca, 0) * CFrame.new(1.6 * scale, 2.6 * scale, 0) * CFrame.Angles(0, 0, -0.34),
				Color = biome.AccentColor, Material = Enum.Material.Neon,
				CollisionGroup = "FloraTrunks", Parent = model,
			})
		end
		local light = Instance.new("PointLight")
		light.Color = biome.AccentColor
		light.Range = 16
		light.Brightness = 1.2
		light.Parent = primaryTrunk
		addAmbientParticles(primaryTrunk, biome.AccentColor, 3.0, NumberRange.new(0.4, 1.3), NumberSequence.new(0.28, 0.04), Vector3.new(0, 0.8, 0))
	elseif biome.FloraType == "bamboo" then
		primaryTrunk = part({
			Name = "Trunk", Size = Vector3.new(0.9 * scale, 10.5 * scale, 0.9 * scale),
			CFrame = origin * CFrame.new(0, 5.25 * scale, 0), Color = biome.TrunkColor,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		for stalkIdx = -1, 1 do
			local ox = stalkIdx * 1.45 * scale
			local oz = (stalkIdx % 2) * 0.8 * scale
			local h = (9.0 + stalkIdx * 1.6) * scale
			if stalkIdx ~= 0 then
				part({
					Name = "BambooStalk_" .. stalkIdx, Size = Vector3.new(0.8 * scale, h, 0.8 * scale),
					CFrame = origin * CFrame.new(ox, h / 2, oz), Color = biome.TrunkColor,
					CollisionGroup = "FloraTrunks", Parent = model,
				})
			end
			for ring = 1, 3 do
				part({
					Name = "NodeRing", Size = Vector3.new(1.05 * scale, 0.25 * scale, 1.05 * scale),
					CFrame = origin * CFrame.new(ox, ring * 2.6 * scale, oz),
					Color = shade(biome.TrunkColor, 0.75), CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
				})
			end
			part({
				Name = "BambooLeaf", Size = Vector3.new(3.4 * scale, 1.1 * scale, 3.4 * scale),
				CFrame = origin * CFrame.new(ox, h + 0.4 * scale, oz),
				Color = biome.FloraColor, CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
		end
	elseif biome.FloraType == "cactus" then
		primaryTrunk = part({
			Name = "Trunk", Size = Vector3.new(2.2 * scale, 8.2 * scale, 2.2 * scale),
			CFrame = origin * CFrame.new(0, 4.1 * scale, 0), Color = biome.FloraColor,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		for side = -1, 1, 2 do
			part({
				Name = "ArmH", Size = Vector3.new(2.1 * scale, 1.1 * scale, 1.1 * scale),
				CFrame = origin * CFrame.new(side * 1.8 * scale, (4.2 + side * 0.5) * scale, 0),
				Color = biome.FloraColor, CollisionGroup = "FloraTrunks", Parent = model,
			})
			part({
				Name = "ArmV", Size = Vector3.new(1.1 * scale, 2.8 * scale, 1.1 * scale),
				CFrame = origin * CFrame.new(side * 2.4 * scale, (5.7 + side * 0.5) * scale, 0),
				Color = biome.FloraColor, CollisionGroup = "FloraTrunks", Parent = model,
			})
		end
		part({
			Name = "CactusFlower", Size = Vector3.new(1.6 * scale, 0.9 * scale, 1.6 * scale),
			CFrame = origin * CFrame.new(0, 8.5 * scale, 0), Color = biome.AccentColor,
			Material = Enum.Material.Neon, CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
	else
		-- Гигантский папоротник с розеткой из 6 дугообразных листьев
		primaryTrunk = part({
			Name = "Trunk", Size = Vector3.new(1.6 * scale, 3.2 * scale, 1.6 * scale),
			CFrame = origin * CFrame.new(0, 1.6 * scale, 0), Color = biome.TrunkColor,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		for f = 1, 6 do
			local fa = (f / 6) * math.pi * 2
			local frondCF = origin * CFrame.new(0, 3.0 * scale, 0) * CFrame.Angles(0, fa, 0)
			part({
				Class = "WedgePart", Name = "Frond_" .. f,
				Size = Vector3.new(1.6 * scale, 0.45 * scale, 4.8 * scale),
				CFrame = frondCF * CFrame.Angles(-0.22, 0, 0) * CFrame.new(0, 0.3 * scale, 2.4 * scale),
				Color = if f % 2 == 0 then biome.FloraColor else shade(biome.FloraColor, 1.1),
				CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
		end
		local sporeCore = part({
			Name = "SporeCore", Size = Vector3.new(1.4 * scale, 1.4 * scale, 1.4 * scale),
			CFrame = origin * CFrame.new(0, 3.7 * scale, 0), Color = biome.AccentColor,
			Material = Enum.Material.Neon, CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
		addAmbientParticles(sporeCore, biome.AccentColor, 2.0, NumberRange.new(0.4, 1.1), NumberSequence.new(0.24, 0.04), Vector3.new(0.2, 1.1, 0))
	end

	model.PrimaryPart = primaryTrunk
	model:SetAttribute("BiomeId", biome.Id)
	model:SetAttribute("HP", 3)
	CollectionService:AddTag(model, "BotaniaFlora")
	model.Parent = parent
	return model
end

-- 2. ДЕКОР ЗЕМЛИ: ТРАВА, ЦВЕТЫ И МОХОВЫЕ ВАЛУНЫ
function Factory.BuildUndergrowth(biome: any, pos: Vector3, rng: Random, parent: Instance): Model
	local model = Instance.new("Model")
	local roll = rng:NextNumber()
	local origin = CFrame.new(pos) * CFrame.Angles(0, rng:NextNumber(0, math.pi * 2), 0)

	if roll < 0.55 then
		model.Name = "GrassTuft_" .. biome.Id
		for i = 1, 5 do
			local a = (i / 5) * math.pi * 2
			local blade = part({
				Class = "WedgePart", Name = "Blade_" .. i,
				Size = Vector3.new(0.28, rng:NextNumber(1.3, 2.3), 0.75),
				CFrame = origin * CFrame.Angles(0, a, 0) * CFrame.new(0, 0.9, 0.35) * CFrame.Angles(0.28, 0, 0),
				Color = shade(biome.FloraColor, rng:NextNumber(0.92, 1.12)),
				CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
			if i == 1 then model.PrimaryPart = blade end
		end
		CollectionService:AddTag(model, "BotaniaWindSway")
	elseif roll < 0.82 then
		model.Name = "FlowerPatch_" .. biome.Id
		local stem = part({
			Name = "Stem", Size = Vector3.new(0.25, 1.4, 0.25),
			CFrame = origin * CFrame.new(0, 0.7, 0), Color = Color3.fromRGB(58, 150, 48),
			CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
		model.PrimaryPart = stem
		for p = 1, 4 do
			local pa = (p / 4) * math.pi * 2
			part({
				Name = "Petal_" .. p, Size = Vector3.new(0.7, 0.25, 0.7),
				CFrame = origin * CFrame.Angles(0, pa, 0) * CFrame.new(0.45, 1.45, 0),
				Color = biome.AccentColor, CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
			})
		end
		part({
			Name = "PollenCenter", Size = Vector3.new(0.55, 0.4, 0.55),
			CFrame = origin * CFrame.new(0, 1.55, 0), Color = Color3.fromRGB(255, 211, 42),
			Material = Enum.Material.Neon, CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
	else
		model.Name = "MossBoulder_" .. biome.Id
		local mainRock = part({
			Name = "BoulderMain", Size = Vector3.new(3.4, 2.2, 3.0),
			CFrame = origin * CFrame.new(0, 1.0, 0), Color = Color3.fromRGB(108, 122, 134),
			Material = Enum.Material.Slate, CollisionGroup = "FloraTrunks", Parent = model,
		})
		model.PrimaryPart = mainRock
		part({
			Class = "CornerWedgePart", Name = "RockFacet",
			Size = Vector3.new(2.2, 1.6, 2.2),
			CFrame = origin * CFrame.new(1.2, 0.8, 0.6) * CFrame.Angles(0, 0.8, 0),
			Color = Color3.fromRGB(92, 106, 118), Material = Enum.Material.Slate,
			CollisionGroup = "FloraTrunks", Parent = model,
		})
		part({
			Name = "MossCap", Size = Vector3.new(2.8, 0.45, 2.4),
			CFrame = origin * CFrame.new(0, 2.15, 0), Color = biome.GroundColor,
			CanCollide = false, CollisionGroup = "FloraCanopy", Parent = model,
		})
	end

	model:SetAttribute("OriginCFrame", model:GetPivot())
	model.Parent = parent
	return model
end

-- 3. 6 АРТИКУЛИРОВАННЫХ ЖИВОТНЫХ И ФАУНЫ (Motor6D-суставы для плавной анимации)
function Factory.BuildStudioAnimal(biome: any, pos: Vector3, kindIndex: number, parent: Instance): Model
	local kinds = { "Deer", "Fox", "Turtle", "Beetle", "Butterfly", "Bee" }
	local kind = kinds[(kindIndex % #kinds) + 1]

	local model = Instance.new("Model")
	model.Name = "Animal_" .. kind .. "_" .. biome.Id
	local origin = CFrame.new(pos)

	local body: BasePart
	if kind == "Deer" then
		body = part({
			Name = "Torso", Size = Vector3.new(1.8, 1.6, 3.2),
			CFrame = origin * CFrame.new(0, 2.2, 0), Color = Color3.fromRGB(168, 118, 76),
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local neck = part({
			Name = "Neck", Size = Vector3.new(0.85, 1.7, 0.9),
			CFrame = body.CFrame * CFrame.new(0, 1.1, -1.3) * CFrame.Angles(0.35, 0, 0),
			Color = Color3.fromRGB(168, 118, 76), CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local head = part({
			Name = "Head", Size = Vector3.new(1.0, 0.95, 1.5),
			CFrame = body.CFrame * CFrame.new(0, 2.0, -1.8),
			Color = Color3.fromRGB(185, 134, 90), CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		-- Светящиеся рога лесного духа
		for s = -1, 1, 2 do
			local ant = part({
				Name = "Antler_" .. s, Size = Vector3.new(0.22, 1.3, 0.22),
				CFrame = head.CFrame * CFrame.new(s * 0.45, 0.95, 0.2) * CFrame.Angles(0, 0, -s * 0.28),
				Color = biome.FaunaColor, Material = Enum.Material.Neon,
				CollisionGroup = "Fauna", CanCollide = false, Parent = model,
			})
			weld(body, ant)
		end
		weld(body, neck)
		weld(body, head)
		for lx = -1, 1, 2 do
			for lz = -1, 1, 2 do
				local leg = part({
					Name = "Leg_" .. lx .. "_" .. lz, Size = Vector3.new(0.42, 1.6, 0.42),
					CFrame = body.CFrame * CFrame.new(lx * 0.6, -1.4, lz * 1.1),
					Color = Color3.fromRGB(130, 88, 54), CollisionGroup = "Fauna", CanCollide = false, Parent = model,
				})
				weld(body, leg)
			end
		end
	elseif kind == "Fox" then
		body = part({
			Name = "Torso", Size = Vector3.new(1.2, 1.0, 2.3),
			CFrame = origin * CFrame.new(0, 1.2, 0), Color = Color3.fromRGB(235, 122, 52),
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local head = part({
			Name = "Head", Size = Vector3.new(1.0, 0.9, 1.2),
			CFrame = body.CFrame * CFrame.new(0, 0.55, -1.3), Color = Color3.fromRGB(245, 135, 65),
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local tail = part({
			Name = "Tail", Size = Vector3.new(0.75, 0.75, 1.8),
			CFrame = body.CFrame * CFrame.new(0, 0.35, 1.7) * CFrame.Angles(0.35, 0, 0),
			Color = Color3.fromRGB(255, 245, 235), CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local collar = part({
			Name = "CrystalCollar", Size = Vector3.new(1.3, 0.35, 0.45),
			CFrame = body.CFrame * CFrame.new(0, 0.15, -0.95), Color = biome.FaunaColor,
			Material = Enum.Material.Neon, CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		weld(body, head)
		weld(body, tail)
		weld(body, collar)
	elseif kind == "Turtle" then
		body = part({
			Name = "ShellBase", Size = Vector3.new(2.2, 1.0, 2.6),
			CFrame = origin * CFrame.new(0, 0.75, 0), Color = Color3.fromRGB(76, 145, 68),
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local dome = part({
			Name = "ShellDome", Size = Vector3.new(1.6, 0.65, 1.9),
			CFrame = body.CFrame * CFrame.new(0, 0.65, 0), Color = biome.GroundColor,
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local sprout = part({
			Name = "BackSprout", Size = Vector3.new(0.45, 0.7, 0.45),
			CFrame = body.CFrame * CFrame.new(0, 1.25, 0), Color = biome.AccentColor,
			Material = Enum.Material.Neon, CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		local head = part({
			Name = "Head", Size = Vector3.new(0.75, 0.65, 0.9),
			CFrame = body.CFrame * CFrame.new(0, -0.1, -1.55), Color = Color3.fromRGB(118, 194, 98),
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		weld(body, dome)
		weld(body, sprout)
		weld(body, head)
	else
		-- Butterfly / Bee / Beetle летающая фауна с парой светящихся крыльев
		body = part({
			Name = "Body", Size = Vector3.new(0.65, 0.6, 1.4),
			CFrame = origin * CFrame.new(0, 4.5, 0),
			Color = if kind == "Bee" then Color3.fromRGB(255, 200, 45) else Color3.fromRGB(45, 52, 54),
			CollisionGroup = "Fauna", CanCollide = false, Parent = model,
		})
		for side = -1, 1, 2 do
			local wing = part({
				Name = if side == -1 then "WingL" else "WingR",
				Size = Vector3.new(1.4, 0.12, 1.15),
				CFrame = body.CFrame * CFrame.new(side * 0.95, 0.25, 0),
				Color = biome.FaunaColor, Material = Enum.Material.Neon,
				Transparency = 0.2, CollisionGroup = "Fauna", CanCollide = false, Parent = model,
			})
			weld(body, wing)
		end
	end

	model.PrimaryPart = body
	addAmbientParticles(body, biome.FaunaColor, 2.5, NumberRange.new(0.3, 0.9), NumberSequence.new(0.2, 0.02), Vector3.new(0, 0.5, 0))
	model:SetAttribute("AnimalKind", kind)
	model:SetAttribute("AnchorPos", pos)
	model:SetAttribute("Phase", math.random() * math.pi * 2)
	CollectionService:AddTag(model, "BotaniaFauna")
	model.Parent = parent
	return model
end

-- 4. КАСТОМНЫЕ 3D ИНСТРУМЕНТЫ ROBLOX (Tool в ReplicatedStorage/BotaniaTools)
function Factory.BuildStudioTool(toolId: string): Tool
	local tool = Instance.new("Tool")
	tool.Name = toolId
	tool.RequiresHandle = true

	local handle = part({
		Name = "Handle", Size = Vector3.new(0.32, 2.2, 0.32),
		CFrame = CFrame.new(0, 0, 0), Color = Color3.fromRGB(122, 82, 48),
		Material = Enum.Material.Wood, Anchored = false, CanCollide = false, Parent = tool,
	})

	if toolId == "tool_botanic_axe" or toolId == "tool_jade_axe" then
		local isJade = (toolId == "tool_jade_axe")
		local collar = part({
			Name = "Collar", Size = Vector3.new(0.45, 0.35, 0.45),
			CFrame = CFrame.new(0, 0.7, 0), Color = Color3.fromRGB(212, 175, 55),
			Material = Enum.Material.Metal, Anchored = false, CanCollide = false, Parent = tool,
		})
		local blade = part({
			Class = "WedgePart", Name = "Blade", Size = Vector3.new(0.2, 0.85, 1.15),
			CFrame = CFrame.new(0, 0.85, -0.58),
			Color = if isJade then Color3.fromRGB(0, 210, 211) else Color3.fromRGB(46, 204, 113),
			Material = Enum.Material.Glass, Anchored = false, CanCollide = false, Parent = tool,
		})
		local core = part({
			Name = "SeedGem", Size = Vector3.new(0.38, 0.38, 0.38),
			CFrame = CFrame.new(0, 1.12, 0), Color = Color3.fromRGB(0, 245, 212),
			Material = Enum.Material.Neon, Anchored = false, CanCollide = false, Parent = tool,
		})
		local gemSparkle = addAmbientParticles(core, Color3.fromRGB(0, 245, 212), 4, NumberRange.new(0.5, 1.5), NumberSequence.new(0.18, 0.02))
		tool.Activated:Connect(function()
			gemSparkle:Emit(12)
		end)
		weld(handle, collar)
		weld(handle, blade)
		weld(handle, core)
	elseif toolId == "tool_dew_can" then
		local tank = part({
			Name = "Tank", Size = Vector3.new(0.9, 0.9, 1.1),
			CFrame = CFrame.new(0, 0, -0.45), Color = Color3.fromRGB(75, 207, 250),
			Material = Enum.Material.Metal, Anchored = false, CanCollide = false, Parent = tool,
		})
		local spout = part({
			Name = "Spout", Size = Vector3.new(0.24, 0.24, 0.9),
			CFrame = CFrame.new(0, 0.2, -1.15) * CFrame.Angles(0.35, 0, 0),
			Color = Color3.fromRGB(212, 175, 55), Material = Enum.Material.Metal,
			Anchored = false, CanCollide = false, Parent = tool,
		})
		local waterDrops = addAmbientParticles(spout, Color3.fromRGB(112, 232, 255), 0, NumberRange.new(3, 6), NumberSequence.new(0.22, 0.05), Vector3.new(0, -14, 0))
		waterDrops.Enabled = false
		tool.Activated:Connect(function()
			waterDrops:Emit(14)
		end)
		weld(handle, tank)
		weld(handle, spout)
	end

	return tool
end

-- 5. КАСТОМНЫЕ 3D МОДЕЛИ ВЫПАДАЮЩИХ ПРЕДМЕТОВ (вместо примитивных шариков)
function Factory.BuildItemDropModel(itemId: string, itemColor: Color3, pos: Vector3, parent: Instance): Model
	local drop = Instance.new("Model")
	drop.Name = "Drop_" .. itemId
	local origin = CFrame.new(pos)

	local core = part({
		Name = "DropCore", Size = Vector3.new(1.2, 1.2, 1.2),
		CFrame = origin, Color = itemColor, Material = Enum.Material.SmoothPlastic,
		Anchored = false, CanCollide = true, CollisionGroup = "LootPickups", Parent = drop,
	})

	if string.sub(itemId, 1, 5) == "seed_" then
		core.Size = Vector3.new(0.95, 1.1, 0.95)
		local sprout = part({
			Class = "WedgePart", Name = "TinyLeaf", Size = Vector3.new(0.3, 0.7, 0.7),
			CFrame = origin * CFrame.new(0, 0.75, 0.2), Color = Color3.fromRGB(46, 204, 113),
			Anchored = false, CanCollide = false, CollisionGroup = "LootPickups", Parent = drop,
		})
		weld(core, sprout)
	elseif itemId == "res_wood" then
		core.Size = Vector3.new(0.85, 0.85, 1.9)
		core.Material = Enum.Material.Wood
		local band = part({
			Name = "RopeBand", Size = Vector3.new(0.95, 0.95, 0.35),
			CFrame = origin, Color = Color3.fromRGB(163, 203, 56),
			Anchored = false, CanCollide = false, CollisionGroup = "LootPickups", Parent = drop,
		})
		weld(core, band)
	else
		core.Material = Enum.Material.Neon
		local ring = part({
			Name = "CrystalTrim", Size = Vector3.new(1.5, 0.3, 1.5),
			CFrame = origin * CFrame.Angles(0.3, 0.6, 0), Color = Color3.fromRGB(255, 255, 255),
			Material = Enum.Material.Glass, Anchored = false, CanCollide = false,
			CollisionGroup = "LootPickups", Parent = drop,
		})
		weld(core, ring)
	end

	addAmbientParticles(core, itemColor, 4.5, NumberRange.new(0.6, 1.4), NumberSequence.new(0.24, 0.04), Vector3.new(0, 2.2, 0))
	drop.PrimaryPart = core
	drop.Parent = parent
	return drop
end

return Factory`,
};
