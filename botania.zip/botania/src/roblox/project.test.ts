import test from 'node:test';
import assert from 'node:assert/strict';
import { EXTERNAL_ASSET_PACKS, STUDIO_MODEL_CATALOG } from './luauModels';
import { ALL_ROBLOX_SCRIPTS, generateRbxlxXml } from './rbxlxExporter';

test('all 15 Roblox Luau scripts are strict and free of placeholder asset IDs', () => {
  assert.equal(ALL_ROBLOX_SCRIPTS.length, 15);
  for (const script of ALL_ROBLOX_SCRIPTS) {
    assert.ok(script.code.startsWith('--!strict'), `${script.name} must start with --!strict`);
    assert.ok(!script.code.includes('rbxassetid://100000001'), `${script.name} has placeholder asset ID`);
    assert.ok(!script.code.includes('TODO'), `${script.name} contains TODO`);
  }
});

test('QuestSystem generates procedural biome quests, tracks progress, and awards authorized Florins', () => {
  const qs = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'quest_system');
  const mainServer = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'time_weather_anticheat');
  const dataStore = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'datastore_manager');
  const mechanics = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'botany_mechanics');
  const clientUi = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'client_hud_ui');
  assert.ok(qs && mainServer && dataStore && mechanics && clientUi);

  assert.equal(qs.robloxPath, 'ServerScriptService/BotaniaServer/QuestSystem');
  assert.ok(qs.code.includes('CollectUniqueResource'));
  assert.ok(qs.code.includes('BuildToxicOutpost'));
  assert.ok(qs.code.includes('HarvestBiomeFlora'));
  assert.ok(qs.code.includes('CultivateBiomeSeed'));
  assert.ok(qs.code.includes('GenerateProceduralQuest'));
  assert.ok(qs.code.includes('OnPlayerEnteredBiome'));
  assert.ok(qs.code.includes('RecordItemCollected'));
  assert.ok(qs.code.includes('RecordBlockPlaced'));
  assert.ok(qs.code.includes('AntiCheatEngine.AuthorizeFlorinGrant'));
  assert.ok(qs.code.includes('Собрать %d уникальных кристаллов'));
  assert.ok(qs.code.includes('Построить базу в биоме с высокой токсичностью'));

  assert.ok(dataStore.code.includes('CompletedQuests'));
  assert.ok(mechanics.code.includes('BotanyMechanics.SetEventHooks'));
  assert.ok(mainServer.code.includes('QuestSystem.Start(biomeCenters)'));
  assert.ok(clientUi.code.includes('BiomeQuestTracker'));
  assert.ok(clientUi.code.includes('QuestUpdate'));
});

test('AntiCheatEngine enforces Teleport/Fly/Speed detection, Magnitude checks, and DataStore anti-inject audit', () => {
  const antiCheat = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'anti_cheat_engine');
  const dataStore = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'datastore_manager');
  const mainServer = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'time_weather_anticheat');
  const mechanics = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'botany_mechanics');
  assert.ok(antiCheat && dataStore && mainServer && mechanics);

  assert.equal(antiCheat.robloxPath, 'ServerScriptService/BotaniaServer/AntiCheatEngine');
  assert.ok(antiCheat.code.includes('TELEPORT_INSTANT_LIMIT'));
  assert.ok(antiCheat.code.includes('MAX_AIR_HOVER_SECONDS'));
  assert.ok(antiCheat.code.includes('FORBIDDEN_CLIENT_MOVERS'));
  assert.ok(antiCheat.code.includes('ValidateHarvestAction'));
  assert.ok(antiCheat.code.includes('ValidateBuildAction'));
  assert.ok(antiCheat.code.includes('ValidateAndExecuteCraft'));
  assert.ok(antiCheat.code.includes('ValidateSlotSwap'));
  assert.ok(antiCheat.code.includes('ValidateAndUnlockSkill'));
  assert.ok(antiCheat.code.includes('ValidatePlantSeed'));
  assert.ok(antiCheat.code.includes('AuditAndSanitizeProfile'));
  assert.ok(antiCheat.code.includes('ComputeProfileSignature'));
  assert.ok(antiCheat.code.includes('Magnitude'));

  assert.ok(dataStore.code.includes('SetPreSaveAudit'));
  assert.ok(mainServer.code.includes('AntiCheatEngine.Start()'));
  assert.ok(mainServer.code.includes('AntiCheatEngine.AuthorizeFlorinGrant'));
  assert.ok(mechanics.code.includes('.Magnitude <= 14'));
});

test('ProceduralAnimator animates all 15 R15 body joints and character particles', () => {
  const anim = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'procedural_animator');
  const fp = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'first_person_anims');
  assert.ok(anim && fp);
  const expectedJoints = [
    'Root',
    'Waist',
    'Neck',
    'RightShoulder',
    'RightElbow',
    'RightWrist',
    'LeftShoulder',
    'LeftElbow',
    'LeftWrist',
    'RightHip',
    'RightKnee',
    'RightAnkle',
    'LeftHip',
    'LeftKnee',
    'LeftAnkle',
  ];
  for (const j of expectedJoints) {
    assert.ok(anim.code.includes(`"${j}"`), `Missing joint ${j}`);
  }
  assert.ok(anim.code.includes('BotaniaFootDust'));
  assert.ok(anim.code.includes('BotaniaSprintLeaves'));
  assert.ok(anim.code.includes('BotaniaHitSparks'));
  assert.ok(fp.code.includes('ProceduralAnimator.Attach'));
});

test('TeleportLoadingScreen component and BiomeSurvivalTips handle World <-> Lobby transitions', () => {
  const loading = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'teleport_loading_screen');
  const config = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'skill_quest_config');
  const clientUi = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'client_hud_ui');
  const server = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'time_weather_anticheat');
  assert.ok(loading && config && clientUi && server);
  assert.ok(loading.code.includes('function TeleportLoadingScreen.new'));
  assert.ok(loading.code.includes('function TeleportLoadingScreen:Show'));
  assert.ok(loading.code.includes('TeleportService:SetTeleportGui'));
  assert.ok(loading.code.includes('ContentProvider:PreloadAsync'));
  assert.ok(config.code.includes('Config.BiomeSurvivalTips'));
  assert.ok(config.code.includes('Config.GetTipsForTeleport'));
  assert.ok(clientUi.code.includes('TeleportLoadingScreen.new'));
  assert.ok(server.code.includes('ReturnToLobby'));
});

test('StudioModelFactory provides custom flora, undergrowth, 6 animals, tools, and 3D item drops', () => {
  const factory = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'studio_model_factory');
  assert.ok(factory);
  assert.ok(factory.code.includes('function Factory.BuildStudioFlora'));
  assert.ok(factory.code.includes('function Factory.BuildUndergrowth'));
  assert.ok(factory.code.includes('function Factory.BuildStudioAnimal'));
  assert.ok(factory.code.includes('function Factory.BuildStudioTool'));
  assert.ok(factory.code.includes('function Factory.BuildItemDropModel'));
  assert.ok(factory.code.includes('addAmbientParticles'));
  assert.ok(EXTERNAL_ASSET_PACKS.length >= 6);
  assert.ok(STUDIO_MODEL_CATALOG.length === 4);
});

test('collision and physics systems implement PhysicsService groups, overlap checks, and 3D loot', () => {
  const physics = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'physics_collision');
  const mechanics = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'botany_mechanics');
  assert.ok(physics && mechanics);
  assert.ok(physics.code.includes('RegisterCollisionGroup'));
  assert.ok(physics.code.includes('FloraTrunks'));
  assert.ok(physics.code.includes('FloraCanopy'));
  assert.ok(mechanics.code.includes('GetPartBoundsInBox'));
  assert.ok(mechanics.code.includes('ApplyImpulse'));
  assert.ok(mechanics.code.includes('FindCrossbreed'));
  assert.ok(mechanics.code.includes('StudioModelFactory.BuildItemDropModel'));
});

test('WorldGenerator integrates StudioModelFactory for flora, undergrowth, animals, and tools', () => {
  const worldGen = ALL_ROBLOX_SCRIPTS.find((s) => s.id === 'world_generator');
  assert.ok(worldGen);
  assert.ok(worldGen.code.includes('StudioModelFactory.BuildStudioFlora'));
  assert.ok(worldGen.code.includes('StudioModelFactory.BuildUndergrowth'));
  assert.ok(worldGen.code.includes('StudioModelFactory.BuildStudioAnimal'));
  assert.ok(worldGen.code.includes('StudioModelFactory.BuildStudioTool'));
});

test('generateRbxlxXml emits valid XML with all services, remotes, and scripts', () => {
  const xml = generateRbxlxXml();
  assert.ok(xml.startsWith('<roblox '));
  assert.ok(xml.endsWith('</roblox>'));
  assert.ok(xml.includes('BotaniaShared'));
  assert.ok(xml.includes('StudioModelFactory'));
  assert.ok(xml.includes('TeleportLoadingScreen'));
  assert.ok(xml.includes('ProceduralAnimator'));
  assert.ok(xml.includes('AntiCheatEngine'));
  assert.ok(xml.includes('QuestSystem'));
  assert.ok(xml.includes('QuestUpdate'));
  assert.ok(xml.includes('TeleportState'));
  assert.ok(xml.includes('BotaniaServer'));
  assert.ok(xml.includes('BotaniaHUD'));
  assert.ok(xml.includes('StarterPlayerScripts'));
  assert.ok(xml.includes('<Item class="RemoteEvent"'));
  assert.ok(xml.includes('PhysicsAndCollisionSetup'));
  assert.ok(xml.includes('BotaniaClientUI'));
  assert.ok(xml.includes('CameraMode">1</token>'));
});
