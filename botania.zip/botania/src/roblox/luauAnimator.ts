import { RobloxScriptDef } from './luauShared';

export const PROCEDURAL_ANIMATOR_SCRIPT: RobloxScriptDef = {
  id: 'procedural_animator',
  name: 'ProceduralAnimator',
  className: 'ModuleScript',
  service: 'ReplicatedStorage',
  folder: 'BotaniaShared',
  robloxPath: 'ReplicatedStorage/BotaniaShared/ProceduralAnimator',
  summary:
    'Полнотельный процедурный аниматор (15 суставов R15 + R6 фолбэк): движение головы, шеи, талии, таза, плеч, локтей, кистей, бёдер, коленей и стоп + частицы шагов, спринта, приземления и урона.',
  apis: ['RunService', 'TweenService', 'ParticleEmitter', 'Motor6D'],
  code: `--!strict
-- ReplicatedStorage/BotaniaShared/ProceduralAnimator (ModuleScript)
-- Полнотельная процедурная анимация каждого элемента тела (R15: 15 суставов + R6) и система частиц персонажа
local RunService = game:GetService("RunService")

export type AnimatorState = {
	IsSprinting: boolean,
	SwingTimer: number,
	SwingDuration: number,
	HurtTimer: number,
	LandTimer: number,
	PotatoMode: boolean,
	TriggerSwing: (self: AnimatorState) -> (),
	EmitBiomeHit: (self: AnimatorState, worldPos: Vector3, color: Color3) -> (),
	SetPotatoMode: (self: AnimatorState, enabled: boolean) -> (),
	Destroy: (self: AnimatorState) -> (),
}

local ProceduralAnimator = {}

local R15_JOINT_NAMES = {
	"Root", "Waist", "Neck",
	"RightShoulder", "RightElbow", "RightWrist",
	"LeftShoulder", "LeftElbow", "LeftWrist",
	"RightHip", "RightKnee", "RightAnkle",
	"LeftHip", "LeftKnee", "LeftAnkle",
}

local R6_JOINT_NAMES = {
	"RootJoint", "Neck",
	"Right Shoulder", "Left Shoulder",
	"Right Hip", "Left Hip",
}

local function makeParticle(props: {
	Name: string,
	Color: ColorSequence,
	Size: NumberSequence,
	Lifetime: NumberRange,
	Speed: NumberRange,
	SpreadAngle: Vector2?,
	Acceleration: Vector3?,
	Rate: number?,
	Parent: Instance,
}): ParticleEmitter
	local emitter = Instance.new("ParticleEmitter")
	emitter.Name = props.Name
	emitter.Color = props.Color
	emitter.Size = props.Size
	emitter.Lifetime = props.Lifetime
	emitter.Speed = props.Speed
	emitter.SpreadAngle = props.SpreadAngle or Vector2.new(35, 35)
	emitter.Acceleration = props.Acceleration or Vector3.new(0, -6, 0)
	emitter.Rate = props.Rate or 0
	emitter.Enabled = (props.Rate or 0) > 0
	emitter.LightEmission = 0.25
	emitter.Parent = props.Parent
	return emitter
end

local function createFootAttachment(part: BasePart?, name: string): (Attachment?, ParticleEmitter?)
	if not part then return nil, nil end
	local att = Instance.new("Attachment")
	att.Name = name
	att.Position = Vector3.new(0, -part.Size.Y * 0.45, 0)
	att.Parent = part

	local dust = makeParticle({
		Name = "BotaniaFootDust",
		Color = ColorSequence.new(Color3.fromRGB(163, 203, 56), Color3.fromRGB(88, 185, 71)),
		Size = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.35),
			NumberSequenceKeypoint.new(1, 0.05),
		}),
		Lifetime = NumberRange.new(0.35, 0.65),
		Speed = NumberRange.new(2, 5.5),
		SpreadAngle = Vector2.new(65, 65),
		Acceleration = Vector3.new(0, -8, 0),
		Rate = 0,
		Parent = att,
	})
	return att, dust
end

function ProceduralAnimator.Attach(character: Model, isLocalPlayer: boolean): AnimatorState
	local humanoid = character:WaitForChild("Humanoid") :: Humanoid
	local rootPart = character:WaitForChild("HumanoidRootPart") :: BasePart

	-- Отключаем стандартный скрипт Animate, чтобы наши суставы двигались без конфликтов
	local defaultAnimate = character:FindFirstChild("Animate")
	if defaultAnimate and defaultAnimate:IsA("LocalScript") then
		defaultAnimate.Disabled = true
	end
	local animator = humanoid:FindFirstChildOfClass("Animator")
	if animator then
		for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
			track:Stop(0)
		end
	end

	-- Кэшируем все Motor6D и их базовые C0 (и R15, и R6)
	local joints: { [string]: Motor6D } = {}
	local baseC0: { [string]: CFrame } = {}

	local function cacheJoints()
		for _, desc in ipairs(character:GetDescendants()) do
			if desc:IsA("Motor6D") then
				if table.find(R15_JOINT_NAMES, desc.Name) or table.find(R6_JOINT_NAMES, desc.Name) then
					if not joints[desc.Name] then
						joints[desc.Name] = desc
						baseC0[desc.Name] = desc.C0
					end
				end
			end
		end
	end
	cacheJoints()

	local function setJoint(name: string, offset: CFrame, alpha: number)
		local j = joints[name]
		local base = baseC0[name]
		if j and base then
			local target = base * offset
			j.C0 = j.C0:Lerp(target, alpha)
		end
	end

	-- Создаём частицы персонажа: шаги (левая/правая нога), шлейф спринта, вспышка урона
	local leftFoot = (character:FindFirstChild("LeftFoot") or character:FindFirstChild("Left Leg")) :: BasePart?
	local rightFoot = (character:FindFirstChild("RightFoot") or character:FindFirstChild("Right Leg")) :: BasePart?
	local torsoPart = (character:FindFirstChild("UpperTorso") or character:FindFirstChild("Torso") or rootPart) :: BasePart

	local attL, dustL = createFootAttachment(leftFoot, "BotaniaStepL")
	local attR, dustR = createFootAttachment(rightFoot, "BotaniaStepR")

	local sprintAtt = Instance.new("Attachment")
	sprintAtt.Name = "BotaniaSprintAttach"
	sprintAtt.Parent = rootPart

	local sprintTrail = makeParticle({
		Name = "BotaniaSprintLeaves",
		Color = ColorSequence.new(Color3.fromRGB(46, 204, 113), Color3.fromRGB(0, 245, 212)),
		Size = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.28),
			NumberSequenceKeypoint.new(1, 0.04),
		}),
		Lifetime = NumberRange.new(0.45, 0.8),
		Speed = NumberRange.new(1.5, 4),
		SpreadAngle = Vector2.new(45, 45),
		Acceleration = Vector3.new(0, 1.5, 0),
		Rate = 18,
		Parent = sprintAtt,
	})
	sprintTrail.Enabled = false

	local hurtBurst = makeParticle({
		Name = "BotaniaHurtBurst",
		Color = ColorSequence.new(Color3.fromRGB(255, 107, 129), Color3.fromRGB(197, 108, 240)),
		Size = NumberSequence.new(0.42, 0.08),
		Lifetime = NumberRange.new(0.35, 0.6),
		Speed = NumberRange.new(5, 11),
		SpreadAngle = Vector2.new(180, 180),
		Rate = 0,
		Parent = torsoPart,
	})

	local state: AnimatorState = {
		IsSprinting = false,
		SwingTimer = 0,
		SwingDuration = 0.36,
		HurtTimer = 0,
		LandTimer = 0,
		PotatoMode = false,
		TriggerSwing = function(self: AnimatorState)
			self.SwingTimer = self.SwingDuration
		end,
		EmitBiomeHit = function(self: AnimatorState, worldPos: Vector3, color: Color3)
			if self.PotatoMode then return end
			local p = Instance.new("Part")
			p.Name = "HitBurstAnchor"
			p.Size = Vector3.new(0.4, 0.4, 0.4)
			p.Position = worldPos
			p.Anchored = true
			p.CanCollide = false
			p.Transparency = 1
			p.Parent = workspace

			local burst = makeParticle({
				Name = "BotaniaHitSparks",
				Color = ColorSequence.new(color, Color3.fromRGB(255, 255, 255)),
				Size = NumberSequence.new(0.45, 0.05),
				Lifetime = NumberRange.new(0.35, 0.7),
				Speed = NumberRange.new(6, 14),
				SpreadAngle = Vector2.new(120, 120),
				Acceleration = Vector3.new(0, -18, 0),
				Rate = 0,
				Parent = p,
			})
			burst:Emit(16)
			task.delay(0.85, function()
				p:Destroy()
			end)
		end,
		SetPotatoMode = function(self: AnimatorState, enabled: boolean)
			self.PotatoMode = enabled
			if enabled then
				sprintTrail.Enabled = false
			end
		end,
		Destroy = function() end,
	}

	local lastHp = humanoid.Health
	local walkPhase = 0
	local idlePhase = 0
	local lastStepSide = 0

	local conns: { RBXScriptConnection } = {}

	table.insert(conns, humanoid.HealthChanged:Connect(function(hp)
		if hp < lastHp then
			state.HurtTimer = 0.3
			if not state.PotatoMode then
				hurtBurst:Emit(14)
			end
		end
		lastHp = hp
	end))

	table.insert(conns, humanoid.StateChanged:Connect(function(_old, newState)
		if newState == Enum.HumanoidStateType.Landed then
			state.LandTimer = 0.24
			if not state.PotatoMode then
				if dustL then dustL:Emit(10) end
				if dustR then dustR:Emit(10) end
			end
		end
	end))

	table.insert(conns, RunService.RenderStepped:Connect(function(dt)
		if not character.Parent or humanoid.Health <= 0 then return end
		local alpha = math.clamp(dt * 16, 0.1, 1)

		local moveDir = humanoid.MoveDirection
		local moveMag = moveDir.Magnitude
		local humState = humanoid:GetState()
		local inAir = (humState == Enum.HumanoidStateType.Freefall or humState == Enum.HumanoidStateType.Jumping)

		-- Локальная скорость в системе координат персонажа (для наклона вбок при стрейфе)
		local localVel = rootPart.CFrame:VectorToObjectSpace(rootPart.AssemblyLinearVelocity)
		local strafeTilt = math.clamp(-localVel.X / 24, -0.18, 0.18)

		idlePhase += dt * 2.2
		if moveMag > 0.08 and not inAir then
			local freq = if state.IsSprinting then 13.5 else 8.6
			walkPhase += dt * freq
		end

		if state.SwingTimer > 0 then
			state.SwingTimer = math.max(0, state.SwingTimer - dt)
		end
		if state.HurtTimer > 0 then
			state.HurtTimer = math.max(0, state.HurtTimer - dt)
		end
		if state.LandTimer > 0 then
			state.LandTimer = math.max(0, state.LandTimer - dt)
		end

		-- Частицы шагов на каждом касании земли + шлейф листьев при спринте
		local movingOnGround = moveMag > 0.12 and not inAir
		sprintTrail.Enabled = movingOnGround and state.IsSprinting and not state.PotatoMode
		if movingOnGround and not state.PotatoMode then
			local stepSign = if math.sin(walkPhase) >= 0 then 1 else -1
			if stepSign ~= lastStepSide then
				lastStepSide = stepSign
				if stepSign > 0 and dustL then
					dustL:Emit(if state.IsSprinting then 7 else 4)
				elseif stepSign < 0 and dustR then
					dustR:Emit(if state.IsSprinting then 7 else 4)
				end
			end
		end

		-- Вычисляем параметры каждого элемента тела
		local breath = math.sin(idlePhase)
		local landSquash = math.sin((state.LandTimer / 0.24) * math.pi)
		local hurtRecoil = math.sin((state.HurtTimer / 0.3) * math.pi)

		-- 3-фазный взмах инструментом (Замах -> Удар -> Возврат)
		local swingP = if state.SwingTimer > 0 then 1 - (state.SwingTimer / state.SwingDuration) else 0
		local swingPitch = 0
		local swingTorsoTwist = 0
		local swingElbowFlex = 0
		local swingWristSnap = 0
		if swingP > 0 then
			if swingP < 0.32 then
				local w = swingP / 0.32
				swingPitch = 0.9 * w
				swingTorsoTwist = -0.35 * w
				swingElbowFlex = 0.85 * w
				swingWristSnap = 0.4 * w
			elseif swingP < 0.65 then
				local s = (swingP - 0.32) / 0.33
				swingPitch = 0.9 - 2.35 * s
				swingTorsoTwist = -0.35 + 0.78 * s
				swingElbowFlex = 0.85 - 0.7 * s
				swingWristSnap = 0.4 - 0.95 * s
			else
				local r = (swingP - 0.65) / 0.35
				swingPitch = -1.45 * (1 - r)
				swingTorsoTwist = 0.43 * (1 - r)
				swingElbowFlex = 0.15 * (1 - r)
				swingWristSnap = -0.55 * (1 - r)
			end
		end

		local s = math.sin(walkPhase)
		local c = math.cos(walkPhase)
		local strideAmp = if not movingOnGround then 0 elseif state.IsSprinting then 0.85 else 0.56
		local hipLift = if not movingOnGround then 0 else math.abs(s) * (if state.IsSprinting then 0.24 else 0.12)
		local sprintLean = if movingOnGround and state.IsSprinting then -0.18 else 0

		-- 1. ТАЗ (Root / LowerTorso): вертикальный отскок, присед при приземлении, наклон стрейфа
		local rootY = hipLift - landSquash * 0.55 + breath * 0.03
		local rootPitch = sprintLean - landSquash * 0.2 + hurtRecoil * 0.22
		local rootYaw = if movingOnGround then s * 0.12 else 0
		setJoint("Root", CFrame.new(0, rootY, 0) * CFrame.Angles(rootPitch, rootYaw, strafeTilt), alpha)
		setJoint("RootJoint", CFrame.new(0, rootY, 0) * CFrame.Angles(rootPitch, rootYaw, strafeTilt), alpha)

		-- 2. ГРУДЬ И ТАЛИЯ (Waist / UpperTorso): контр-скручивание относительно таза + замах топором + дыхание
		local waistYaw = (if movingOnGround then -s * 0.18 else 0) + swingTorsoTwist
		local waistPitch = breath * 0.035 + sprintLean * 0.5 - landSquash * 0.15 + hurtRecoil * 0.18
		setJoint("Waist", CFrame.Angles(waistPitch, waistYaw, -strafeTilt * 0.5), alpha)

		-- 3. ШЕЯ И ГОЛОВА (Neck / Head): стабилизация взгляда, поворот в сторону движения, отдача урона
		local headPitch = -breath * 0.025 + hurtRecoil * 0.35 + (if inAir then 0.12 else 0)
		local headYaw = if movingOnGround then s * 0.07 - swingTorsoTwist * 0.4 else math.sin(idlePhase * 0.5) * 0.06
		setJoint("Neck", CFrame.Angles(headPitch, headYaw, -strafeTilt * 0.35), alpha)

		-- В первом лице делаем кисти/предплечья правой руки видимыми во время взмаха
		if isLocalPlayer then
			for _, limbName in ipairs({ "RightUpperArm", "RightLowerArm", "RightHand" }) do
				local limb = character:FindFirstChild(limbName)
				if limb and limb:IsA("BasePart") then
					limb.LocalTransparencyModifier = if state.SwingTimer > 0 then 0 else 1
				end
			end
		end

		-- 4. РУКИ: ПЛЕЧИ + ЛОКТИ + КИСТИ
		if inAir then
			-- Прыжок: руки приподняты, локти согнуты для баланса
			setJoint("RightShoulder", CFrame.Angles(0.55 + swingPitch, 0, 0.28 + hurtRecoil * 0.3), alpha)
			setJoint("LeftShoulder", CFrame.Angles(0.75, 0, -0.32 - hurtRecoil * 0.3), alpha)
			setJoint("RightElbow", CFrame.Angles(0.85 + swingElbowFlex, 0, 0), alpha)
			setJoint("LeftElbow", CFrame.Angles(0.95, 0, 0), alpha)
			setJoint("RightWrist", CFrame.Angles(swingWristSnap, 0, 0), alpha)
			setJoint("LeftWrist", CFrame.Angles(0.15, 0, 0), alpha)
		else
			local armSwing = if movingOnGround then s * strideAmp * 0.85 else breath * 0.04
			local elbowBase = if state.IsSprinting and movingOnGround then 1.15 elseif movingOnGround then 0.45 else 0.22
			local rElbow = elbowBase + math.max(0, -armSwing) * 0.45 + swingElbowFlex
			local lElbow = elbowBase + math.max(0, armSwing) * 0.45

			setJoint("RightShoulder", CFrame.Angles(-armSwing + swingPitch + hurtRecoil * 0.25, 0, 0.08 + hurtRecoil * 0.25), alpha)
			setJoint("LeftShoulder", CFrame.Angles(armSwing + hurtRecoil * 0.25, 0, -0.08 - hurtRecoil * 0.25), alpha)
			setJoint("RightElbow", CFrame.Angles(rElbow, 0, 0), alpha)
			setJoint("LeftElbow", CFrame.Angles(lElbow, 0, 0), alpha)
			setJoint("RightWrist", CFrame.Angles(-armSwing * 0.2 + swingWristSnap, 0, 0), alpha)
			setJoint("LeftWrist", CFrame.Angles(armSwing * 0.2, 0, 0), alpha)

			-- R6 фолбэк плеч
			setJoint("Right Shoulder", CFrame.Angles(0, 0, -armSwing + swingPitch), alpha)
			setJoint("Left Shoulder", CFrame.Angles(0, 0, -armSwing), alpha)
		end

		-- 5. НОГИ: БЁДРА + КОЛЕНИ + СТОПЫ
		if inAir then
			-- Асимметричная поза прыжка: левое колено подтянуто, правая нога отведена
			setJoint("LeftHip", CFrame.Angles(0.85, 0, 0), alpha)
			setJoint("LeftKnee", CFrame.Angles(-1.15, 0, 0), alpha)
			setJoint("LeftAnkle", CFrame.Angles(-0.35, 0, 0), alpha)

			setJoint("RightHip", CFrame.Angles(-0.35, 0, 0), alpha)
			setJoint("RightKnee", CFrame.Angles(-0.55, 0, 0), alpha)
			setJoint("RightAnkle", CFrame.Angles(-0.4, 0, 0), alpha)
		else
			local rHip = s * strideAmp + landSquash * 0.45
			local lHip = -s * strideAmp + landSquash * 0.45
			local rKnee = -math.max(0, -c) * (strideAmp * 1.35) - landSquash * 0.85
			local lKnee = -math.max(0, c) * (strideAmp * 1.35) - landSquash * 0.85
			local rAnkle = (if movingOnGround then c * 0.25 else 0) + landSquash * 0.35
			local lAnkle = (if movingOnGround then -c * 0.25 else 0) + landSquash * 0.35

			setJoint("RightHip", CFrame.Angles(rHip, 0, 0), alpha)
			setJoint("LeftHip", CFrame.Angles(lHip, 0, 0), alpha)
			setJoint("RightKnee", CFrame.Angles(rKnee, 0, 0), alpha)
			setJoint("LeftKnee", CFrame.Angles(lKnee, 0, 0), alpha)
			setJoint("RightAnkle", CFrame.Angles(rAnkle, 0, 0), alpha)
			setJoint("LeftAnkle", CFrame.Angles(lAnkle, 0, 0), alpha)

			-- R6 фолбэк бёдер
			setJoint("Right Hip", CFrame.Angles(0, 0, rHip), alpha)
			setJoint("Left Hip", CFrame.Angles(0, 0, lHip), alpha)
		end
	end))

	state.Destroy = function()
		for _, conn in ipairs(conns) do
			conn:Disconnect()
		end
		table.clear(conns)
		if attL then attL:Destroy() end
		if attR then attR:Destroy() end
		sprintAtt:Destroy()
		hurtBurst:Destroy()
	end

	return state
end

return ProceduralAnimator`,
};
