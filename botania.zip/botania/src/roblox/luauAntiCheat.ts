import { RobloxScriptDef } from './luauShared';

export const ANTI_CHEAT_SCRIPT: RobloxScriptDef = {
  id: 'anti_cheat_engine',
  name: 'AntiCheatEngine',
  className: 'ModuleScript',
  service: 'ServerScriptService',
  folder: 'BotaniaServer',
  robloxPath: 'ServerScriptService/BotaniaServer/AntiCheatEngine',
  summary:
    'Серверный движок анти-чита: детекция Speed/Teleport/Fly хаков через Raycast и Velocity, валидация крафта/сбора/стройки по дистанции Magnitude и защита DataStore от инжектов и подмены данных.',
  apis: ['Players', 'RunService', 'CollectionService', 'Workspace', 'HttpService'],
  code: `--!strict
-- ServerScriptService/BotaniaServer/AntiCheatEngine (ModuleScript)
-- Серверная защита от Teleport/Fly/Speed хаков, проверка дистанции Magnitude и целостность DataStore
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local ItemRegistry = require(Shared:WaitForChild("ItemAndRecipeRegistry"))
local SkillConfig = require(Shared:WaitForChild("SkillAndQuestConfig"))

local DataStoreManager = require(script.Parent.DataStoreManager)

export type PlayerMonitorRecord = {
	SafeCFrame: CFrame,
	LastPos: Vector3,
	LastTime: number,
	AirHoverSeconds: number,
	SpeedStrikes: number,
	FlyStrikes: number,
	TeleportGraceUntil: number,
	LastHarvestAt: number,
	RateCount: number,
	RateResetAt: number,
	AuthorizedFlorinDelta: number,
	LastAuditedFlorins: number,
}

local AntiCheatEngine = {}

local MAX_WALK_SPEED = 24
local SPEED_TOLERANCE = 1.45
local TELEPORT_INSTANT_LIMIT = 40
local MAX_AIR_HOVER_SECONDS = 3.4
local MAX_HARVEST_STUDS = 18
local MAX_BUILD_STUDS = 22
local MAX_PICKUP_STUDS = 14
local MAX_CRAFT_STATION_STUDS = 24
local MAX_REMOTES_PER_SEC = 12
local KICK_STRIKE_LIMIT = 6

-- Серверный секрет сессии (никогда не реплицируется клиенту) для подписи снимков профиля
local SESSION_SALT = math.random(100000, 999999)
local Records: { [number]: PlayerMonitorRecord } = {}
local started = false

local FORBIDDEN_CLIENT_MOVERS = {
	BodyVelocity = true,
	BodyPosition = true,
	BodyGyro = true,
	LinearVelocity = true,
	AlignPosition = true,
	VectorForce = true,
}

local function isFiniteNumber(n: any): boolean
	return type(n) == "number" and n == n and math.abs(n) < math.huge
end

local function isFiniteVector3(v: any): boolean
	return typeof(v) == "Vector3"
		and isFiniteNumber(v.X)
		and isFiniteNumber(v.Y)
		and isFiniteNumber(v.Z)
		and v.Magnitude < 2500
end

local function getRoot(player: Player): BasePart?
	local char = player.Character
	if not char then return nil end
	return char:FindFirstChild("HumanoidRootPart") :: BasePart?
end

local function getRecord(player: Player): PlayerMonitorRecord?
	return Records[player.UserId]
end

-- Простой детерминированный FNV-хеш целостности данных профиля с серверной солью
function AntiCheatEngine.ComputeProfileSignature(userId: number, profile: DataStoreManager.PlayerProfile): number
	local hash = (userId % 65521) * 31 + SESSION_SALT
	hash = (hash * 33 + math.floor(profile.Florins)) % 2147483647
	hash = (hash * 33 + math.floor(profile.XP)) % 2147483647
	hash = (hash * 33 + math.floor(profile.Level)) % 2147483647
	hash = (hash * 33 + math.floor(profile.SkillPoints)) % 2147483647
	for i = 1, 6 do
		local slot = profile.Inventory.Hotbar[i]
		if slot then
			hash = (hash * 31 + #slot.Id + slot.Count * 17) % 2147483647
		end
	end
	return hash
end

-- Ограничитель частоты RemoteEvent (защита от спама и флуд-инжектов)
function AntiCheatEngine.CheckRateLimit(player: Player): boolean
	local rec = getRecord(player)
	if not rec then return false end
	local now = os.clock()
	if now >= rec.RateResetAt then
		rec.RateCount = 1
		rec.RateResetAt = now + 1.0
		return true
	end
	rec.RateCount += 1
	return rec.RateCount <= MAX_REMOTES_PER_SEC
end

-- Разрешает легитимную серверную телепортацию (например, возврат к Шпилю Семян)
function AntiCheatEngine.WhitelistTeleport(player: Player, targetCFrame: CFrame)
	local rec = getRecord(player)
	if rec then
		rec.TeleportGraceUntil = os.clock() + 1.5
		rec.SafeCFrame = targetCFrame
		rec.LastPos = targetCFrame.Position
		rec.AirHoverSeconds = 0
	end
	local root = getRoot(player)
	if root then
		root.CFrame = targetCFrame
	end
end

-- Авторизация серверных начислений валюты (квесты, донат) для выявления подмены памяти
function AntiCheatEngine.AuthorizeFlorinGrant(player: Player, amount: number)
	if not isFiniteNumber(amount) or amount <= 0 then return end
	local rec = getRecord(player)
	if rec then
		rec.AuthorizedFlorinDelta += math.floor(amount)
	end
end

-- 1. ПРОВЕРКА ДИСТАНЦИИ (Magnitude) ДЛЯ СБОРА, ПОСТРОЙКИ И ПОДБОРА ЛУТА
function AntiCheatEngine.ValidateHarvestAction(player: Player, floraModel: any): (boolean, string?)
	if not AntiCheatEngine.CheckRateLimit(player) then
		return false, "Слишком частые запросы"
	end
	if typeof(floraModel) ~= "Instance" or not floraModel:IsA("Model") or not floraModel.PrimaryPart then
		return false, "Некорректный объект флоры"
	end
	if not CollectionService:HasTag(floraModel, "BotaniaFlora") then
		return false, "Объект не является растением"
	end

	local rec = getRecord(player)
	local now = os.clock()
	if rec and now - rec.LastHarvestAt < 0.22 then
		return false, "Превышение скорости ударов"
	end

	local root = getRoot(player)
	if not root then
		return false, "Персонаж не найден"
	end

	local dist = (root.Position - floraModel.PrimaryPart.Position).Magnitude
	if dist > MAX_HARVEST_STUDS then
		return false, string.format("Дистанция сбора %.1f > %d studs", dist, MAX_HARVEST_STUDS)
	end

	if rec then
		rec.LastHarvestAt = now
	end
	return true, nil
end

function AntiCheatEngine.ValidateBuildAction(player: Player, kind: any, worldPos: any): (boolean, string?)
	if not AntiCheatEngine.CheckRateLimit(player) then
		return false, "Слишком частые запросы"
	end
	if type(kind) ~= "string" or not isFiniteVector3(worldPos) then
		return false, "Инжект некорректных координат или типа блока"
	end

	local root = getRoot(player)
	if not root then
		return false, "Персонаж не найден"
	end

	local dist = (root.Position - worldPos).Magnitude
	if dist > MAX_BUILD_STUDS then
		return false, string.format("Дистанция стройки %.1f > %d studs", dist, MAX_BUILD_STUDS)
	end

	return true, nil
end

function AntiCheatEngine.ValidatePickupDistance(player: Player, dropPos: Vector3): boolean
	local root = getRoot(player)
	if not root or not isFiniteVector3(dropPos) then return false end
	return (root.Position - dropPos).Magnitude <= MAX_PICKUP_STUDS
end

-- 2. СЕРВЕРНАЯ ВАЛИДАЦИЯ КРАФТА, НАВЫКОВ И ОПЕРАЦИЙ С ИНВЕНТАРЁМ (без доверия клиенту)
function AntiCheatEngine.ValidateAndExecuteCraft(player: Player, recipeId: any, stationPos: any): (boolean, string, number?)
	if not AntiCheatEngine.CheckRateLimit(player) then
		return false, "Превышен лимит запросов крафта", nil
	end
	if type(recipeId) ~= "string" then
		return false, "Некорректный ID рецепта", nil
	end

	local profile = DataStoreManager.GetProfile(player)
	if not profile then
		return false, "Профиль не загружен", nil
	end

	-- Ищем рецепт строго в серверном реестре (клиент не может передать цену или результат)
	local targetRecipe: ItemRegistry.RecipeDef? = nil
	for _, r in ipairs(ItemRegistry.Recipes) do
		if r.Id == recipeId then
			targetRecipe = r
			break
		end
	end
	if not targetRecipe then
		return false, "Рецепт не существует", nil
	end

	-- Продвинутый крафт требует близости к Алтарю/Станции (Magnitude <= 24)
	if targetRecipe.Tier ~= "Basic" and typeof(stationPos) == "Vector3" and isFiniteVector3(stationPos) then
		local root = getRoot(player)
		if not root or (root.Position - stationPos).Magnitude > MAX_CRAFT_STATION_STUDS then
			return false, "Подойдите ближе к верстаку / Шпилю Семян", nil
		end
	end

	if targetRecipe.RequiredSkill and not table.find(profile.UnlockedSkills, targetRecipe.RequiredSkill) then
		return false, "Требуется навык: " .. targetRecipe.RequiredSkill, nil
	end

	-- Проверяем наличие всех ингредиентов в серверном профиле
	local function countItem(itemId: string): number
		local total = 0
		for _, s in pairs(profile.Inventory.Hotbar) do
			if s and s.Id == itemId and isFiniteNumber(s.Count) and s.Count > 0 then
				total += math.floor(s.Count)
			end
		end
		for _, s in pairs(profile.Inventory.Backpack) do
			if s and s.Id == itemId and isFiniteNumber(s.Count) and s.Count > 0 then
				total += math.floor(s.Count)
			end
		end
		return total
	end

	for _, ing in ipairs(targetRecipe.Ingredients) do
		if countItem(ing.Id) < ing.Count then
			return false, "Недостаточно ресурсов для крафта", nil
		end
	end

	-- Атомарно списываем ингредиенты
	for _, ing in ipairs(targetRecipe.Ingredients) do
		local need = ing.Count
		for _, container in ipairs({ profile.Inventory.Backpack, profile.Inventory.Hotbar }) do
			for idx, slot in pairs(container) do
				if need <= 0 then break end
				if slot and slot.Id == ing.Id then
					local take = math.min(need, slot.Count)
					slot.Count -= take
					need -= take
					if slot.Count <= 0 then
						container[idx] = nil
					end
				end
			end
		end
	end

	return true, targetRecipe.OutputId, targetRecipe.OutputCount
end

function AntiCheatEngine.ValidateAndUnlockSkill(player: Player, skillId: any): (boolean, string)
	if not AntiCheatEngine.CheckRateLimit(player) then
		return false, "Превышен лимит запросов навыков"
	end
	if type(skillId) ~= "string" then
		return false, "Некорректный ID навыка"
	end
	local profile = DataStoreManager.GetProfile(player)
	if not profile then
		return false, "Профиль не загружен"
	end
	if table.find(profile.UnlockedSkills, skillId) then
		return false, "Навык уже изучен"
	end

	local targetSkill: any = nil
	for _, s in ipairs(SkillConfig.Skills) do
		if s.Id == skillId then
			targetSkill = s
			break
		end
	end
	if not targetSkill then
		return false, "Навык не найден"
	end
	if targetSkill.Prereq and not table.find(profile.UnlockedSkills, targetSkill.Prereq) then
		return false, "Не изучен предыдущий навык"
	end
	if profile.SkillPoints < targetSkill.Cost then
		return false, "Недостаточно очков навыков"
	end

	profile.SkillPoints -= targetSkill.Cost
	table.insert(profile.UnlockedSkills, skillId)
	return true, skillId
end

function AntiCheatEngine.ValidatePlantSeed(player: Player, planterModel: any, seedId: any): (boolean, string?)
	if not AntiCheatEngine.CheckRateLimit(player) then
		return false, "Слишком частые запросы"
	end
	if typeof(planterModel) ~= "Instance" or not planterModel:IsA("Model") or not planterModel.PrimaryPart then
		return false, "Некорректная грядка"
	end
	if type(seedId) ~= "string" then
		return false, "Некорректный ID семени"
	end
	local def = ItemRegistry.Items[seedId]
	if not def or def.Category ~= "Seed" then
		return false, "Предмет не является семенем"
	end

	local root = getRoot(player)
	if not root or (root.Position - planterModel.PrimaryPart.Position).Magnitude > MAX_BUILD_STUDS then
		return false, "Грядка слишком далеко"
	end

	local profile = DataStoreManager.GetProfile(player)
	if not profile then
		return false, "Профиль не загружен"
	end

	-- Списываем 1 семя с сервера, чтобы исключить бесконечную посадку инжектом
	for _, container in ipairs({ profile.Inventory.Hotbar, profile.Inventory.Backpack }) do
		for idx, slot in pairs(container) do
			if slot and slot.Id == seedId and slot.Count > 0 then
				slot.Count -= 1
				if slot.Count <= 0 then
					container[idx] = nil
				end
				return true, nil
			end
		end
	end
	return false, "Нет подходящего семени в инвентаре"
end

function AntiCheatEngine.ValidateSlotSwap(player: Player, fromSection: any, fromIdx: any, toSection: any, toIdx: any): boolean
	if not AntiCheatEngine.CheckRateLimit(player) then return false end
	if fromSection ~= "Hotbar" and fromSection ~= "Backpack" then return false end
	if toSection ~= "Hotbar" and toSection ~= "Backpack" then return false end
	if not isFiniteNumber(fromIdx) or not isFiniteNumber(toIdx) then return false end

	local fi, ti = math.floor(fromIdx), math.floor(toIdx)
	local maxFrom = if fromSection == "Hotbar" then 6 else 18
	local maxTo = if toSection == "Hotbar" then 6 else 18
	if fi < 1 or fi > maxFrom or ti < 1 or ti > maxTo then return false end

	local profile = DataStoreManager.GetProfile(player)
	if not profile then return false end

	local srcArr = if fromSection == "Hotbar" then profile.Inventory.Hotbar else profile.Inventory.Backpack
	local dstArr = if toSection == "Hotbar" then profile.Inventory.Hotbar else profile.Inventory.Backpack
	local temp = srcArr[fi]
	srcArr[fi] = dstArr[ti]
	dstArr[ti] = temp
	return true
end

-- Синхронизирует базовый баланс игрока сразу после успешной загрузки профиля из DataStore
function AntiCheatEngine.SyncLoadedProfile(player: Player, profile: DataStoreManager.PlayerProfile)
	AntiCheatEngine.AuditAndSanitizeProfile(player, profile)
	local rec = getRecord(player)
	if rec then
		rec.LastAuditedFlorins = profile.Florins
		rec.AuthorizedFlorinDelta = 0
	end
end

-- 3. ЗАЩИТА DATASTORE ОТ ПОДМЕНЫ ДАННЫХ И ИНЖЕКТОВ (санитизация и аудит перед сохранением)
function AntiCheatEngine.AuditAndSanitizeProfile(player: Player, profile: DataStoreManager.PlayerProfile): boolean
	local suspicious = false

	if not isFiniteNumber(profile.Florins) or profile.Florins < 0 or profile.Florins > 10_000_000 then
		profile.Florins = 0
		suspicious = true
	end
	profile.Florins = math.floor(profile.Florins)

	local rec = getRecord(player)
	if rec then
		local unauthDelta = profile.Florins - rec.LastAuditedFlorins - rec.AuthorizedFlorinDelta
		if unauthDelta > 0 then
			-- Откатываем неавторизованный прирост валюты!
			profile.Florins = rec.LastAuditedFlorins + rec.AuthorizedFlorinDelta
			suspicious = true
		end
		rec.LastAuditedFlorins = profile.Florins
		rec.AuthorizedFlorinDelta = 0
	end

	if not isFiniteNumber(profile.XP) or profile.XP < 0 then
		profile.XP = 0
		suspicious = true
	end
	if not isFiniteNumber(profile.Level) or profile.Level < 1 or profile.Level > 500 then
		profile.Level = 1
		suspicious = true
	end
	if not isFiniteNumber(profile.SkillPoints) or profile.SkillPoints < 0 or profile.SkillPoints > 500 then
		profile.SkillPoints = 0
		suspicious = true
	end

	-- Проверка каждого слота на существование ID и отсутствие дюпа сверх MaxStack
	local function sanitizeContainer(arr: { [number]: DataStoreManager.SlotItem? }, limit: number)
		for k, slot in pairs(arr) do
			if type(k) ~= "number" or k < 1 or k > limit or math.floor(k) ~= k then
				arr[k] = nil
				suspicious = true
			elseif type(slot) ~= "table" or type(slot.Id) ~= "string" then
				arr[k] = nil
				suspicious = true
			else
				local def = ItemRegistry.Items[slot.Id]
				if not def or not isFiniteNumber(slot.Count) or slot.Count <= 0 then
					arr[k] = nil
					suspicious = true
				else
					slot.Count = math.min(math.floor(slot.Count), def.MaxStack)
				end
			end
		end
	end

	sanitizeContainer(profile.Inventory.Hotbar, 6)
	sanitizeContainer(profile.Inventory.Backpack, 18)

	-- Проверка дерева навыков на поддельные ID
	local validSkills: { [string]: boolean } = {}
	for _, s in ipairs(SkillConfig.Skills) do
		validSkills[s.Id] = true
	end
	for i = #profile.UnlockedSkills, 1, -1 do
		if not validSkills[profile.UnlockedSkills[i]] then
			table.remove(profile.UnlockedSkills, i)
			suspicious = true
		end
	end

	return not suspicious
end

-- 4. НЕПРЕРЫВНЫЙ МОНИТОРИНГ СКОРОСТИ, TELEPORT HACK И FLY HACK
local function stripForbiddenMovers(character: Model): boolean
	local stripped = false
	for _, desc in ipairs(character:GetDescendants()) do
		if FORBIDDEN_CLIENT_MOVERS[desc.ClassName] and not desc:GetAttribute("ServerApproved") then
			desc:Destroy()
			stripped = true
		end
	end
	return stripped
end

local function trackPlayer(player: Player)
	local profile = DataStoreManager.GetProfile(player)
	Records[player.UserId] = {
		SafeCFrame = CFrame.new(0, 5, 0),
		LastPos = Vector3.new(0, 5, 0),
		LastTime = os.clock(),
		AirHoverSeconds = 0,
		SpeedStrikes = 0,
		FlyStrikes = 0,
		TeleportGraceUntil = os.clock() + 3.0,
		LastHarvestAt = 0,
		RateCount = 0,
		RateResetAt = os.clock() + 1,
		AuthorizedFlorinDelta = 0,
		LastAuditedFlorins = if profile then profile.Florins else 150,
	}

	player.CharacterAdded:Connect(function(char)
		local root = char:WaitForChild("HumanoidRootPart", 5) :: BasePart?
		local rec = getRecord(player)
		if root and rec then
			rec.SafeCFrame = root.CFrame
			rec.LastPos = root.Position
			rec.LastTime = os.clock()
			rec.AirHoverSeconds = 0
			rec.TeleportGraceUntil = os.clock() + 2.5
		end
	end)
end

function AntiCheatEngine.Start()
	if started then return end
	started = true

	-- Любая запись в DataStore автоматически проходит санитизацию и аудит AntiCheatEngine
	DataStoreManager.SetPreSaveAudit(function(player, profile)
		return AntiCheatEngine.AuditAndSanitizeProfile(player, profile)
	end)

	Players.PlayerAdded:Connect(trackPlayer)
	for _, p in ipairs(Players:GetPlayers()) do
		trackPlayer(p)
	end
	Players.PlayerRemoving:Connect(function(player)
		local profile = DataStoreManager.GetProfile(player)
		if profile then
			AntiCheatEngine.AuditAndSanitizeProfile(player, profile)
		end
		Records[player.UserId] = nil
	end)

	RunService.Heartbeat:Connect(function()
		local now = os.clock()
		for _, player in ipairs(Players:GetPlayers()) do
			local rec = getRecord(player)
			local char = player.Character
			local root = if char then char:FindFirstChild("HumanoidRootPart") :: BasePart? else nil
			local hum = if char then char:FindFirstChildOfClass("Humanoid") else nil

			if rec and char and root and hum and hum.Health > 0 then
				-- Удаляем несанкционированные клиентские Fly/Velocity-объекты
				if stripForbiddenMovers(char) then
					rec.FlyStrikes += 2
				end

				local stepDt = math.max(now - rec.LastTime, 0.03)
				local pos = root.Position
				local horizDist = (Vector3.new(pos.X, 0, pos.Z) - Vector3.new(rec.LastPos.X, 0, rec.LastPos.Z)).Magnitude

				if now > rec.TeleportGraceUntil then
					-- Проверка Teleport Hack / Speed Hack
					local maxAllowedStep = (MAX_WALK_SPEED * SPEED_TOLERANCE) * stepDt
					if horizDist > TELEPORT_INSTANT_LIMIT or horizDist > math.max(maxAllowedStep, 3.2) then
						rec.SpeedStrikes += 1
						root.CFrame = rec.SafeCFrame
						root.AssemblyLinearVelocity = Vector3.zero
					else
						rec.SpeedStrikes = math.max(0, rec.SpeedStrikes - 0.08)
					end

					-- Проверка Fly Hack (зависание или подъём в воздухе без опоры Raycast)
					local rayParams = RaycastParams.new()
					rayParams.FilterType = Enum.RaycastFilterType.Exclude
					rayParams.FilterDescendantsInstances = { char }
					local groundHit = workspace:Raycast(pos, Vector3.new(0, -8.5, 0), rayParams)

					if hum.FloorMaterial == Enum.Material.Air and not groundHit then
						local vy = root.AssemblyLinearVelocity.Y
						if vy > -3.5 then
							rec.AirHoverSeconds += stepDt
							if rec.AirHoverSeconds > MAX_AIR_HOVER_SECONDS then
								rec.FlyStrikes += 1
								root.CFrame = rec.SafeCFrame
								root.AssemblyLinearVelocity = Vector3.zero
								rec.AirHoverSeconds = 0
							end
						end
					else
						rec.AirHoverSeconds = 0
						rec.FlyStrikes = math.max(0, rec.FlyStrikes - 0.05)
						if rec.SpeedStrikes < 1 then
							rec.SafeCFrame = root.CFrame
						end
					end

					if rec.SpeedStrikes >= KICK_STRIKE_LIMIT or rec.FlyStrikes >= KICK_STRIKE_LIMIT then
						player:Kick("Анти-чит Botania: обнаружен Speed/Teleport/Fly хак.")
					end
				else
					rec.SafeCFrame = root.CFrame
				end

				rec.LastPos = root.Position
				rec.LastTime = now
			end
		end
	end)
end

return AntiCheatEngine`,
};
