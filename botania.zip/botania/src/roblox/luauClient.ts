import { RobloxScriptDef } from './luauShared';

export const CLIENT_LUAU_SCRIPTS: RobloxScriptDef[] = [
  {
    id: 'first_person_anims',
    name: 'FirstPersonAndAnimations',
    className: 'LocalScript',
    service: 'StarterPlayerScripts',
    folder: '',
    robloxPath: 'StarterPlayer/StarterPlayerScripts/FirstPersonAndAnimations',
    summary: 'Вид от первого лица, полнотельная 15-суставная анимация (ProceduralAnimator) для всех игроков, частицы шагов/спринта/ударов, FOV и картофельная графика.',
    apis: ['UserInputService', 'ContextActionService', 'RunService', 'Lighting', 'Workspace'],
    code: `--!strict
-- StarterPlayerScripts/FirstPersonAndAnimations (LocalScript)
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ContextActionService = game:GetService("ContextActionService")
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local BiomeRegistry = require(Shared:WaitForChild("BiomeRegistry"))
local ProceduralAnimator = require(Shared:WaitForChild("ProceduralAnimator"))

local player = Players.LocalPlayer
player.CameraMode = Enum.CameraMode.LockFirstPerson

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local HitFloraRemote = Remotes:WaitForChild("HitFlora") :: RemoteEvent
local PlaceBlockRemote = Remotes:WaitForChild("PlaceBlock") :: RemoteEvent

local isPotatoMode = false
local isSprinting = false
local selectedPlaceKind: string? = nil
local localAnimState: ProceduralAnimator.AnimatorState? = nil
local remoteAnimStates: { [Model]: ProceduralAnimator.AnimatorState } = {}

-- Картофельная графика для слабых мобильных устройств
local function applyPotatoGraphics(enabled: boolean)
	isPotatoMode = enabled
	Lighting.GlobalShadows = not enabled
	local terrain = workspace:FindFirstChildOfClass("Terrain")
	if terrain then
		terrain.Decoration = not enabled
	end
	if localAnimState then
		localAnimState:SetPotatoMode(enabled)
	end
	for _, state in pairs(remoteAnimStates) do
		state:SetPotatoMode(enabled)
	end
	for _, desc in ipairs(workspace:GetDescendants()) do
		if desc:IsA("ParticleEmitter") or desc:IsA("PointLight") then
			desc.Enabled = not enabled
		elseif desc:IsA("BasePart") then
			desc.CastShadow = not enabled
		end
	end
end

local function performPrimaryAction()
	local char = player.Character
	local cam = workspace.CurrentCamera
	if not char or not cam then return end

	if localAnimState then
		localAnimState:TriggerSwing()
	end

	local rayParams = RaycastParams.new()
	rayParams.FilterType = Enum.RaycastFilterType.Exclude
	rayParams.FilterDescendantsInstances = { char }

	local result = workspace:Raycast(cam.CFrame.Position, cam.CFrame.LookVector * 16, rayParams)
	if not result then return end

	if selectedPlaceKind then
		PlaceBlockRemote:FireServer(selectedPlaceKind, result.Position + result.Normal * 2)
		return
	end

	local model = result.Instance:FindFirstAncestorOfClass("Model")
	local biomeId = if model then model:GetAttribute("BiomeId") :: string? else nil
	if model and biomeId then
		local biome = BiomeRegistry.ById[biomeId]
		if localAnimState then
			local burstColor = if biome then biome.AccentColor else Color3.fromRGB(46, 204, 113)
			localAnimState:EmitBiomeHit(result.Position, burstColor)
		end
		HitFloraRemote:FireServer(model, cam.CFrame.LookVector)
	end
end

-- Кроссплатформенный ввод (ПК + Мобильные кнопки ContextActionService)
ContextActionService:BindAction("BotaniaSwing", function(_name, state)
	if state == Enum.UserInputState.Begin then
		performPrimaryAction()
	end
end, true, Enum.UserInputType.MouseButton1, Enum.KeyCode.E)
ContextActionService:SetTitle("BotaniaSwing", "Рубить")
ContextActionService:SetPosition("BotaniaSwing", UDim2.new(1, -110, 1, -140))

ContextActionService:BindAction("BotaniaSprint", function(_name, state)
	isSprinting = (state == Enum.UserInputState.Begin)
	if localAnimState then
		localAnimState.IsSprinting = isSprinting
	end
end, true, Enum.KeyCode.LeftShift)
ContextActionService:SetTitle("BotaniaSprint", "Бег")
ContextActionService:SetPosition("BotaniaSprint", UDim2.new(1, -180, 1, -100))

ContextActionService:BindAction("BotaniaPotato", function(_name, state)
	if state == Enum.UserInputState.Begin then
		applyPotatoGraphics(not isPotatoMode)
	end
end, false, Enum.KeyCode.F8)

local function attachCharacterAnimator(targetPlayer: Player, char: Model)
	local isLocal = (targetPlayer == player)
	local animState = ProceduralAnimator.Attach(char, isLocal)
	animState:SetPotatoMode(isPotatoMode)

	if isLocal then
		localAnimState = animState
		animState.IsSprinting = isSprinting
		local humanoid = char:WaitForChild("Humanoid") :: Humanoid
		local phase = 0
		local camConn: RBXScriptConnection
		camConn = RunService.RenderStepped:Connect(function(dt)
			if not char.Parent then
				camConn:Disconnect()
				return
			end
			humanoid.WalkSpeed = if isSprinting then 23 else 16
			local cam = workspace.CurrentCamera
			local moveMag = humanoid.MoveDirection.Magnitude
			if moveMag > 0.08 then
				phase += dt * (if isSprinting then 13.5 else 8.6)
				humanoid.CameraOffset = Vector3.new(math.cos(phase) * 0.06, math.sin(phase * 2) * 0.12, 0)
			else
				humanoid.CameraOffset = humanoid.CameraOffset:Lerp(Vector3.zero, math.min(1, dt * 10))
			end
			if cam then
				local targetFov = if isSprinting and moveMag > 0.1 then 78 else 70
				cam.FieldOfView += (targetFov - cam.FieldOfView) * math.min(1, dt * 8)
			end
		end)
	else
		remoteAnimStates[char] = animState
	end

	char.AncestryChanged:Connect(function(_child, parent)
		if not parent then
			animState:Destroy()
			remoteAnimStates[char] = nil
			if isLocal and localAnimState == animState then
				localAnimState = nil
			end
		end
	end)
end

local function watchPlayer(targetPlayer: Player)
	targetPlayer.CharacterAdded:Connect(function(char)
		attachCharacterAnimator(targetPlayer, char)
	end)
	if targetPlayer.Character then
		attachCharacterAnimator(targetPlayer, targetPlayer.Character)
	end
end

Players.PlayerAdded:Connect(watchPlayer)
for _, p in ipairs(Players:GetPlayers()) do
	watchPlayer(p)
end`,
  },
  {
    id: 'client_hud_ui',
    name: 'BotaniaClientUI',
    className: 'LocalScript',
    service: 'StarterGui',
    folder: 'BotaniaHUD',
    robloxPath: 'StarterGui/BotaniaHUD/BotaniaClientUI',
    summary: 'Клиентский интерфейс: миникарта биомов и друзей в реальном времени, хотбар/рюкзак с UIDragDetector, кнопка перехода в лобби и компонент TeleportLoadingScreen.',
    apis: ['Players', 'TeleportService', 'RunService', 'UserInputService'],
    code: `--!strict
-- StarterGui/BotaniaHUD/BotaniaClientUI (LocalScript)
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TeleportService = game:GetService("TeleportService")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local BiomeRegistry = require(Shared:WaitForChild("BiomeRegistry"))
local TeleportLoadingScreen = require(Shared:WaitForChild("TeleportLoadingScreen"))

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local SwapSlotRemote = Remotes:WaitForChild("SwapSlot") :: RemoteEvent
local LobbyRemote = Remotes:WaitForChild("LobbyAction") :: RemoteEvent
local TeleportStateRemote = Remotes:WaitForChild("TeleportState") :: RemoteEvent
local QuestUpdateRemote = Remotes:WaitForChild("QuestUpdate") :: RemoteEvent

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local gui = Instance.new("ScreenGui")
gui.Name = "BotaniaScreenGui"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.Parent = playerGui

-- 1. Компонент динамического загрузочного экрана телепортации (Мир <-> Лобби)
local teleportOverlay = TeleportLoadingScreen.new(playerGui)

TeleportStateRemote.OnClientEvent:Connect(function(payload: any)
	if type(payload) == "table" then
		teleportOverlay:Show(payload)
	end
end)

TeleportService.LocalPlayerArrivedFromTeleport:Connect(function(customGui, data)
	if customGui and customGui:IsA("ScreenGui") and customGui ~= teleportOverlay.ScreenGui then
		customGui:Destroy()
	end
	local payload = if type(data) == "table" then data else nil
	teleportOverlay:Show(payload)

	local worldFolder = workspace:WaitForChild("BotaniaWorld", 4)
	local toolsFolder = ReplicatedStorage:FindFirstChild("BotaniaTools")
	local preloadList: { Instance } = {}
	if worldFolder then table.insert(preloadList, worldFolder) end
	if toolsFolder then table.insert(preloadList, toolsFolder) end
	teleportOverlay:PreloadAssets(preloadList)
	teleportOverlay:Hide()
end)

-- 2. Миникарта в реальном времени (правый верхний угол) и кнопка возврата в лобби
local minimapFrame = Instance.new("Frame")
minimapFrame.Name = "Minimap"
minimapFrame.Size = UDim2.fromOffset(148, 148)
minimapFrame.Position = UDim2.new(1, -168, 0, 20)
minimapFrame.BackgroundColor3 = Color3.fromRGB(15, 33, 25)
minimapFrame.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 14)
corner.Parent = minimapFrame

local playerDot = Instance.new("Frame")
playerDot.Size = UDim2.fromOffset(8, 8)
playerDot.AnchorPoint = Vector2.new(0.5, 0.5)
playerDot.Position = UDim2.fromScale(0.5, 0.5)
playerDot.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
playerDot.Parent = minimapFrame

local lobbyBtn = Instance.new("TextButton")
lobbyBtn.Name = "ReturnToLobbyButton"
lobbyBtn.Size = UDim2.fromOffset(124, 32)
lobbyBtn.Position = UDim2.fromOffset(20, 60)
lobbyBtn.BackgroundColor3 = Color3.fromRGB(20, 42, 32)
lobbyBtn.TextColor3 = Color3.fromRGB(234, 246, 238)
lobbyBtn.Font = Enum.Font.GothamBold
lobbyBtn.TextSize = 13
lobbyBtn.Text = "В Лобби"
lobbyBtn.Parent = gui
lobbyBtn.Activated:Connect(function()
	teleportOverlay:Show({ Direction = "ToLobby" })
	LobbyRemote:FireServer("ReturnToLobby")
end)

-- 2б. Трекер процедурных заданий биомов и счётчик Флоринов
local questPanel = Instance.new("Frame")
questPanel.Name = "BiomeQuestTracker"
questPanel.Size = UDim2.fromOffset(276, 144)
questPanel.Position = UDim2.fromOffset(20, 102)
questPanel.BackgroundColor3 = Color3.fromRGB(11, 23, 18)
questPanel.BackgroundTransparency = 0.15
questPanel.Parent = gui

local qpCorner = Instance.new("UICorner")
qpCorner.CornerRadius = UDim.new(0, 10)
qpCorner.Parent = questPanel

local questHeader = Instance.new("TextLabel")
questHeader.Size = UDim2.new(1, -16, 0, 24)
questHeader.Position = UDim2.fromOffset(8, 6)
questHeader.BackgroundTransparency = 1
questHeader.TextXAlignment = Enum.TextXAlignment.Left
questHeader.Font = Enum.Font.GothamBold
questHeader.TextSize = 12
questHeader.TextColor3 = Color3.fromRGB(250, 204, 21)
questHeader.Text = "Задания биомов · Флорины: 150"
questHeader.Parent = questPanel

local questBody = Instance.new("TextLabel")
questBody.Size = UDim2.new(1, -16, 1, -36)
questBody.Position = UDim2.fromOffset(8, 30)
questBody.BackgroundTransparency = 1
questBody.TextXAlignment = Enum.TextXAlignment.Left
questBody.TextYAlignment = Enum.TextYAlignment.Top
questBody.TextWrapped = true
questBody.Font = Enum.Font.Gotham
questBody.TextSize = 11
questBody.TextColor3 = Color3.fromRGB(220, 235, 226)
questBody.Text = "Войдите в любой биом, чтобы получить процедурное задание."
questBody.Parent = questPanel

QuestUpdateRemote.OnClientEvent:Connect(function(data: any)
	if type(data) ~= "table" then return end
	local florins = data.Florins or 0
	local level = data.Level or 1
	questHeader.Text = string.format("Ур.%d · Флорины: %d", level, florins)

	local lines: { string } = {}
	if type(data.Notice) == "string" and #data.Notice > 0 then
		table.insert(lines, "★ " .. data.Notice)
	end
	if type(data.ActiveQuests) == "table" then
		for _, q in ipairs(data.ActiveQuests) do
			table.insert(
				lines,
				string.format("• %s (%d/%d) [+%d Фл.]", q.Description, q.Progress, q.Target, q.RewardFlorins)
			)
		end
	end
	if #lines == 0 then
		questBody.Text = "Исследуйте соседние биомы для получения новых заданий."
	else
		questBody.Text = table.concat(lines, "\\n")
	end
end)

-- 3. Уникальный Хотбар 1-6 с перетаскиванием (UIDragDetector)
local hotbar = Instance.new("Frame")
hotbar.Size = UDim2.fromOffset(390, 58)
hotbar.AnchorPoint = Vector2.new(0.5, 1)
hotbar.Position = UDim2.new(0.5, 0, 1, -20)
hotbar.BackgroundColor3 = Color3.fromRGB(11, 23, 18)
hotbar.Parent = gui

local list = Instance.new("UIListLayout")
list.FillDirection = Enum.FillDirection.Horizontal
list.Padding = UDim.new(0, 6)
list.HorizontalAlignment = Enum.HorizontalAlignment.Center
list.VerticalAlignment = Enum.VerticalAlignment.Center
list.Parent = hotbar

local slots: { TextButton } = {}

for i = 1, 6 do
	local slot = Instance.new("TextButton")
	slot.Size = UDim2.fromOffset(56, 48)
	slot.BackgroundColor3 = Color3.fromRGB(20, 42, 32)
	slot.TextColor3 = Color3.fromRGB(234, 246, 238)
	slot.Text = tostring(i)
	slot:SetAttribute("SlotIndex", i)
	slot.Parent = hotbar
	table.insert(slots, slot)

	local drag = Instance.new("UIDragDetector")
	drag.Parent = slot
	drag.DragEnd:Connect(function(pos: Vector2)
		for _, target in ipairs(slots) do
			local p, s = target.AbsolutePosition, target.AbsoluteSize
			if pos.X >= p.X and pos.X <= p.X + s.X and pos.Y >= p.Y and pos.Y <= p.Y + s.Y then
				SwapSlotRemote:FireServer("Hotbar", i, "Hotbar", target:GetAttribute("SlotIndex"))
				break
			end
		end
	end)
end

-- Обновление маркеров игроков и названия текущего биома на миникарте
local biomeLabel = Instance.new("TextLabel")
biomeLabel.Size = UDim2.fromOffset(220, 32)
biomeLabel.Position = UDim2.fromOffset(20, 20)
biomeLabel.BackgroundColor3 = Color3.fromRGB(11, 23, 18)
biomeLabel.TextColor3 = Color3.fromRGB(234, 246, 238)
biomeLabel.Text = "Изумрудная Роща"
biomeLabel.Parent = gui

RunService.Heartbeat:Connect(function()
	local seed = (ReplicatedStorage:GetAttribute("WorldSeed") :: number?) or 10000
	local biomes = BiomeRegistry.SelectServerBiomes(seed, 8)
	local centers = BiomeRegistry.GetBiomeCenters(biomes)
	local char = player.Character
	local root = if char then char:FindFirstChild("HumanoidRootPart") :: BasePart? else nil
	if root then
		local current = BiomeRegistry.GetBiomeAt(root.Position.X, root.Position.Z, centers)
		biomeLabel.Text = current.Name .. " (Токсичность: " .. tostring(current.ToxicityLevel) .. ")"
		local nx = math.clamp(0.5 + root.Position.X / 400, 0.08, 0.92)
		local nz = math.clamp(0.5 + root.Position.Z / 400, 0.08, 0.92)
		playerDot.Position = UDim2.fromScale(nx, nz)
	end
end)`,
  },
];
