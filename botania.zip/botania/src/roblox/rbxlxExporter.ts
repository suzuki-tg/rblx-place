import { PROCEDURAL_ANIMATOR_SCRIPT } from './luauAnimator';
import { ANTI_CHEAT_SCRIPT } from './luauAntiCheat';
import { CLIENT_LUAU_SCRIPTS } from './luauClient';
import { MODEL_FACTORY_SCRIPT } from './luauModels';
import { QUEST_SYSTEM_SCRIPT } from './luauQuestSystem';
import { SERVER_LUAU_SCRIPTS } from './luauServer';
import { RobloxScriptDef, SHARED_LUAU_SCRIPTS } from './luauShared';
import { TELEPORT_LOADING_SCRIPT } from './luauTeleportLoading';

const ALL_SHARED_SCRIPTS: RobloxScriptDef[] = [
  ...SHARED_LUAU_SCRIPTS,
  MODEL_FACTORY_SCRIPT,
  TELEPORT_LOADING_SCRIPT,
  PROCEDURAL_ANIMATOR_SCRIPT,
];

const ALL_SERVER_SCRIPTS: RobloxScriptDef[] = [
  ...SERVER_LUAU_SCRIPTS,
  ANTI_CHEAT_SCRIPT,
  QUEST_SYSTEM_SCRIPT,
];

export const ALL_ROBLOX_SCRIPTS: RobloxScriptDef[] = [
  ...ALL_SHARED_SCRIPTS,
  ...ALL_SERVER_SCRIPTS,
  ...CLIENT_LUAU_SCRIPTS,
];

function escapeXmlCdata(str: string): string {
  return str.replace(/]]>/g, ']]]]><![CDATA[>');
}

function renderScriptItemXml(script: RobloxScriptDef, referentId: string): string {
  return `      <Item class="${script.className}" referent="${referentId}">
        <Properties>
          <string name="Name">${script.name}</string>
          <ProtectedString name="Source"><![CDATA[${escapeXmlCdata(script.code)}]]></ProtectedString>
        </Properties>
      </Item>`;
}

const REMOTE_EVENTS = [
  'HitFlora',
  'PlaceBlock',
  'LobbyAction',
  'TeleportState',
  'SwapSlot',
  'CraftItem',
  'UnlockSkill',
  'PlantSeed',
  'QuestUpdate',
];

/**
 * Builds a complete, valid Roblox Studio XML Place file (.rbxlx) containing
 * Lighting (Atmosphere + Sky), SpawnLocation, ReplicatedStorage (BotaniaShared + Remotes),
 * ServerScriptService (BotaniaServer), StarterPlayerScripts, and StarterGui (BotaniaHUD).
 */
export function generateRbxlxXml(): string {
  let refCounter = 1;
  const nextRef = () => `RBX${String(refCounter++).padStart(8, '0')}`;

  const sharedXml = ALL_SHARED_SCRIPTS.map((s) => renderScriptItemXml(s, nextRef())).join('\n');
  const serverXml = ALL_SERVER_SCRIPTS.map((s) => renderScriptItemXml(s, nextRef())).join('\n');
  const playerScriptsXml = CLIENT_LUAU_SCRIPTS.filter(
    (s) => s.service === 'StarterPlayerScripts'
  )
    .map((s) => renderScriptItemXml(s, nextRef()))
    .join('\n');
  const starterGuiXml = CLIENT_LUAU_SCRIPTS.filter((s) => s.service === 'StarterGui')
    .map((s) => renderScriptItemXml(s, nextRef()))
    .join('\n');

  const remotesXml = REMOTE_EVENTS.map(
    (name) => `      <Item class="RemoteEvent" referent="${nextRef()}">
        <Properties>
          <string name="Name">${name}</string>
        </Properties>
      </Item>`
  ).join('\n');

  return `<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
  <External>null</External>
  <External>nil</External>
  <Item class="Workspace" referent="${nextRef()}">
    <Properties>
      <string name="Name">Workspace</string>
      <bool name="StreamingEnabled">true</bool>
    </Properties>
    <Item class="SpawnLocation" referent="${nextRef()}">
      <Properties>
        <string name="Name">BotaniaSpawn</string>
        <bool name="Anchored">true</bool>
        <bool name="CanCollide">true</bool>
        <CoordinateFrame name="CFrame">
          <X>0</X><Y>1</Y><Z>0</Z>
          <R00>1</R00><R01>0</R01><R02>0</R02>
          <R10>0</R10><R11>1</R11><R12>0</R12>
          <R20>0</R20><R21>0</R21><R22>1</R22>
        </CoordinateFrame>
        <Vector3 name="size">
          <X>12</X><Y>1</Y><Z>12</Z>
        </Vector3>
      </Properties>
    </Item>
  </Item>
  <Item class="Lighting" referent="${nextRef()}">
    <Properties>
      <string name="Name">Lighting</string>
      <float name="ClockTime">10</float>
      <bool name="GlobalShadows">true</bool>
    </Properties>
    <Item class="Atmosphere" referent="${nextRef()}">
      <Properties>
        <string name="Name">BotaniaAtmosphere</string>
        <float name="Density">0.25</float>
      </Properties>
    </Item>
    <Item class="Sky" referent="${nextRef()}">
      <Properties>
        <string name="Name">BotaniaSky</string>
      </Properties>
    </Item>
  </Item>
  <Item class="ReplicatedStorage" referent="${nextRef()}">
    <Properties>
      <string name="Name">ReplicatedStorage</string>
    </Properties>
    <Item class="Folder" referent="${nextRef()}">
      <Properties>
        <string name="Name">BotaniaShared</string>
      </Properties>
${sharedXml}
    </Item>
    <Item class="Folder" referent="${nextRef()}">
      <Properties>
        <string name="Name">Remotes</string>
      </Properties>
${remotesXml}
    </Item>
  </Item>
  <Item class="ServerScriptService" referent="${nextRef()}">
    <Properties>
      <string name="Name">ServerScriptService</string>
    </Properties>
    <Item class="Folder" referent="${nextRef()}">
      <Properties>
        <string name="Name">BotaniaServer</string>
      </Properties>
${serverXml}
    </Item>
  </Item>
  <Item class="StarterGui" referent="${nextRef()}">
    <Properties>
      <string name="Name">StarterGui</string>
    </Properties>
    <Item class="Folder" referent="${nextRef()}">
      <Properties>
        <string name="Name">BotaniaHUD</string>
      </Properties>
${starterGuiXml}
    </Item>
  </Item>
  <Item class="StarterPlayer" referent="${nextRef()}">
    <Properties>
      <string name="Name">StarterPlayer</string>
      <token name="CameraMode">1</token>
    </Properties>
    <Item class="StarterPlayerScripts" referent="${nextRef()}">
      <Properties>
        <string name="Name">StarterPlayerScripts</string>
      </Properties>
${playerScriptsXml}
    </Item>
  </Item>
</roblox>`;
}
