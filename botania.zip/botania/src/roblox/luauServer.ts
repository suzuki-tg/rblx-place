import { RobloxScriptDef } from './luauShared';

export const SERVER_LUAU_SCRIPTS: RobloxScriptDef[] = [
  {
    id: 'physics_collision',
    name: 'PhysicsAndCollisionSetup',
    className: 'Script',
    service: 'ServerScriptService',
    folder: 'BotaniaServer',
    robloxPath: 'ServerScriptService/BotaniaServer/PhysicsAndCollisionSetup',
    summary: 'Настройка CollisionGroups (PhysicsService): твёрдые стволы и стены, проходимые кроны, коллизии лута и серверный урон от падения.',
    apis: ['PhysicsService', 'Players', 'CollectionService'],
    code: `--!strict
-- ServerScriptService/BotaniaServer/PhysicsAndCollisionSetup (Script)
local PhysicsService = game:GetService("PhysicsService")
local Players = game:GetService("Players")

local GROUPS = {
	"Players",
	"Terrain",
	"FloraTrunks",
	"FloraCanopy",
	"PlayerBuilt",
	"LootPickups",
	"Fauna",
}

for _, groupName in ipairs(GROUPS) do
	pcall(function()
		PhysicsService:RegisterCollisionGroup(groupName)
	end)
end

-- Игроки сталкиваются с землёй, стволами и постройками, но свободно проходят сквозь листву, фауну и лут
PhysicsService:CollisionGroupSetCollidable("Players", "Terrain", true)
PhysicsService:CollisionGroupSetCollidable("Players", "FloraTrunks", true)
PhysicsService:CollisionGroupSetCollidable("Players", "PlayerBuilt", true)
PhysicsService:CollisionGroupSetCollidable("Players", "FloraCanopy", false)
PhysicsService:CollisionGroupSetCollidable("Players", "LootPickups", false)
PhysicsService:CollisionGroupSetCollidable("Players", "Fauna", false)

-- Физические ресурсы (сферы лута) падают на землю и постройки, не застревая в кронах
PhysicsService:CollisionGroupSetCollidable("LootPickups", "Terrain", true)
PhysicsService:CollisionGroupSetCollidable("LootPickups", "PlayerBuilt", true)
PhysicsService:CollisionGroupSetCollidable("LootPickups", "FloraTrunks", true)
PhysicsService:CollisionGroupSetCollidable("LootPickups", "FloraCanopy", false)
PhysicsService:CollisionGroupSetCollidable("LootPickups", "LootPickups", false)

-- Присваиваем группу Players всем частям персонажа и отслеживаем урон от падения
local function bindCharacterPhysics(character: Model)
	for _, desc in ipairs(character:GetDescendants()) do
		if desc:IsA("BasePart") then
			desc.CollisionGroup = "Players"
		end
	end
	character.DescendantAdded:Connect(function(desc)
		if desc:IsA("BasePart") then
			desc.CollisionGroup = "Players"
		end
	end)

	local humanoid = character:WaitForChild("Humanoid") :: Humanoid
	local root = character:WaitForChild("HumanoidRootPart") :: BasePart
	local fallStartY: number? = nil

	humanoid.StateChanged:Connect(function(_oldState, newState)
		if newState == Enum.HumanoidStateType.Freefall then
			fallStartY = root.Position.Y
		elseif newState == Enum.HumanoidStateType.Landed and fallStartY then
			local drop = fallStartY - root.Position.Y
			fallStartY = nil
			if drop > 26 then
				local damage = math.floor((drop - 26) * 2.2)
				if damage > 0 then
					humanoid:TakeDamage(damage)
				end
			end
		end
	end)
end

Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(bindCharacterPhysics)
	if player.Character then
		bindCharacterPhysics(player.Character)
	end
end)`,
  },
  {
    id: 'datastore_manager',
    name: 'DataStoreManager',
    className: 'ModuleScript',
    service: 'ServerScriptService',
    folder: 'BotaniaServer',
    robloxPath: 'ServerScriptService/BotaniaServer/DataStoreManager',
    summary: 'Облачное сохранение профилей (DataStoreService v2): блокировка сессии, инвентарь, навыки, Флорины, биомы и настройки.',
    apis: ['DataStoreService', 'Players', 'RunService'],
    code: `--!strict
-- ServerScriptService/BotaniaServer/DataStoreManager (ModuleScript)
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local BotaniaStore = DataStoreService:GetDataStore("Botania_CloudProfile_v2")

export type SlotItem = { Id: string, Count: number }
export type PlayerProfile = {
	SchemaVersion: number,
	Florins: number,
	XP: number,
	Level: number,
	SkillPoints: number,
	UnlockedSkills: { string },
	DiscoveredBiomes: { [string]: boolean },
	CompletedQuests: { [string]: boolean },
	Achievements: { [string]: boolean },
	Upgrades: { [string]: boolean },
	Inventory: {
		Hotbar: { [number]: SlotItem? },
		Backpack: { [number]: SlotItem? },
	},
	Settings: {
		PotatoGraphics: boolean,
		CameraSensitivity: number,
		Muted: boolean,
	},
	SessionLockId: string?,
}

local DEFAULT_PROFILE: PlayerProfile = {
	SchemaVersion = 2,
	Florins = 150,
	XP = 0,
	Level = 1,
	SkillPoints = 2,
	UnlockedSkills = {},
	DiscoveredBiomes = { emerald_grove = true },
	CompletedQuests = {},
	Achievements = {},
	Upgrades = {},
	Inventory = {
		Hotbar = {
			[1] = { Id = "tool_botanic_axe", Count = 1 },
			[2] = { Id = "tool_dew_can", Count = 1 },
			[3] = { Id = "bld_moss_wall", Count = 4 },
			[4] = { Id = "bld_planter_box", Count = 2 },
			[5] = { Id = "con_spore_filter", Count = 2 },
		},
		Backpack = {
			[1] = { Id = "res_wood", Count = 6 },
			[2] = { Id = "res_fiber", Count = 5 },
			[3] = { Id = "res_stone", Count = 4 },
			[4] = { Id = "seed_emerald_grove", Count = 3 },
		},
	},
	Settings = {
		PotatoGraphics = false,
		CameraSensitivity = 0.5,
		Muted = false,
	},
	SessionLockId = nil,
}

local DataStoreManager = {}
local LoadedProfiles: { [number]: PlayerProfile } = {}
local PreSaveAuditHook: ((Player, PlayerProfile) -> boolean)? = nil

function DataStoreManager.SetPreSaveAudit(hook: (Player, PlayerProfile) -> boolean)
	PreSaveAuditHook = hook
end

local function clampFinite(n: any, minVal: number, maxVal: number, fallback: number): number
	if type(n) ~= "number" or n ~= n or math.abs(n) == math.huge then
		return fallback
	end
	return math.clamp(math.floor(n), minVal, maxVal)
end

local function deepCopy<T>(tbl: T): T
	if type(tbl) ~= "table" then return tbl end
	local copy = {}
	for k, v in pairs(tbl :: any) do
		copy[k] = deepCopy(v)
	end
	return copy :: any
end

local function reconcile(raw: any): PlayerProfile
	local merged = deepCopy(DEFAULT_PROFILE)
	if type(raw) == "table" then
		for k, v in pairs(raw) do
			if merged[k] ~= nil then
				merged[k] = v
			end
		end
	end
	merged.Florins = clampFinite(merged.Florins, 0, 10_000_000, DEFAULT_PROFILE.Florins)
	merged.XP = clampFinite(merged.XP, 0, 100_000_000, 0)
	merged.Level = clampFinite(merged.Level, 1, 500, 1)
	merged.SkillPoints = clampFinite(merged.SkillPoints, 0, 500, DEFAULT_PROFILE.SkillPoints)
	return merged
end

function DataStoreManager.LoadAsync(player: Player): PlayerProfile?
	local key = "Botania_" .. tostring(player.UserId)
	local jobId = if game.JobId ~= "" then game.JobId else "StudioSession"
	local ok, result = false, nil

	for attempt = 1, 3 do
		ok, result = pcall(function()
			return BotaniaStore:UpdateAsync(key, function(old)
				local profile = reconcile(old)
				profile.SessionLockId = jobId
				return profile
			end)
		end)
		if ok then break end
		task.wait(attempt * 1.1)
	end

	-- В офлайн-тесте Studio без API Services возвращаем локальную копию, чтобы тест не падал
	if not ok or not result then
		if RunService:IsStudio() then
			local studioFallback = deepCopy(DEFAULT_PROFILE)
			LoadedProfiles[player.UserId] = studioFallback
			return studioFallback
		end
		player:Kick("Ошибка загрузки профиля Botania из DataStore.")
		return nil
	end

	LoadedProfiles[player.UserId] = result
	return result
end

function DataStoreManager.SaveAsync(player: Player, releaseLock: boolean): boolean
	local profile = LoadedProfiles[player.UserId]
	if not profile then return false end

	if PreSaveAuditHook then
		PreSaveAuditHook(player, profile)
	end

	profile.Florins = clampFinite(profile.Florins, 0, 10_000_000, 0)
	profile.XP = clampFinite(profile.XP, 0, 100_000_000, 0)
	profile.Level = clampFinite(profile.Level, 1, 500, 1)
	profile.SkillPoints = clampFinite(profile.SkillPoints, 0, 500, 0)

	local snapshot = deepCopy(profile)
	if releaseLock then
		snapshot.SessionLockId = nil
	end
	local ok = pcall(function()
		BotaniaStore:SetAsync("Botania_" .. tostring(player.UserId), snapshot)
	end)
	return ok
end

function DataStoreManager.GetProfile(player: Player): PlayerProfile?
	return LoadedProfiles[player.UserId]
end

Players.PlayerRemoving:Connect(function(player)
	DataStoreManager.SaveAsync(player, true)
	LoadedProfiles[player.UserId] = nil
end)

game:BindToClose(function()
	for _, p in ipairs(Players:GetPlayers()) do
		task.spawn(DataStoreManager.SaveAsync, p, true)
	end
	if not RunService:IsStudio() then
		task.wait(2.5)
	end
end)

return DataStoreManager`,
  },
  {
    id: 'world_generator',
    name: 'WorldGenerator',
    className: 'ModuleScript',
    service: 'ServerScriptService',
    folder: 'BotaniaServer',
    robloxPath: 'ServerScriptService/BotaniaServer/WorldGenerator',
    summary: 'Полный процедурный генератор: 8 из 30 биомов, воксельный ландшафт с коллизией, Шпиль Семян, многочастные модели флоры и патрулирующая фауна.',
    apis: ['Workspace', 'CollectionService', 'TweenService', 'Random'],
    code: `--!strict
-- ServerScriptService/BotaniaServer/WorldGenerator (ModuleScript)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local BiomeRegistry = require(Shared:WaitForChild("BiomeRegistry"))
local StudioModelFactory = require(Shared:WaitForChild("StudioModelFactory"))

local WorldGenerator = {}
local WORLD_RADIUS = 192
local VOXEL_STEP = 6
local SEED_SPIRE_POS = Vector3.new(0, 0, -48)

function WorldGenerator.GetGroundHeight(x: number, z: number, seed: number): number
	local dist = math.sqrt(x * x + z * z)
	if dist < 24 then return 0 end
	local blend = math.clamp((dist - 24) / 36, 0, 1)
	local raw = math.noise(x * 0.015, z * 0.015, seed * 0.007) * 14
	local cliff = if dist > 165 then ((dist - 165) / 26) * 14 else 0
	return math.round((raw * blend + cliff) / 2) * 2
end

local function makePart(props: {
	Size: Vector3,
	CFrame: CFrame,
	Color: Color3,
	Material: Enum.Material?,
	Anchored: boolean?,
	CanCollide: boolean?,
	CollisionGroup: string?,
	Name: string?,
	Parent: Instance,
}): Part
	local p = Instance.new("Part")
	p.Name = props.Name or "VoxelPart"
	p.Size = props.Size
	p.CFrame = props.CFrame
	p.Color = props.Color
	p.Material = props.Material or Enum.Material.SmoothPlastic
	p.Anchored = if props.Anchored == nil then true else props.Anchored
	p.CanCollide = if props.CanCollide == nil then true else props.CanCollide
	p.CollisionGroup = props.CollisionGroup or "Default"
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.Parent = props.Parent
	return p
end

-- Студийная многочастная флора (14–26 деталей) с разделением твёрдого ствола и проходимой кроны
function WorldGenerator.BuildFloraModel(biome: BiomeRegistry.BiomeDef, pos: Vector3, parent: Instance, rng: Random): Model
	local model = StudioModelFactory.BuildStudioFlora(biome, pos, rng, parent)
	model:SetAttribute("MaxHP", 3)
	model:SetAttribute("OriginPos", pos)
	return model
end

-- Студийная анимированная фауна: Олень, Лисица, Черепаха, Жук, Бабочка, Шмель
function WorldGenerator.SpawnFaunaCritter(biome: BiomeRegistry.BiomeDef, pos: Vector3, parent: Instance, kindIndex: number?): Model
	return StudioModelFactory.BuildStudioAnimal(biome, pos, kindIndex or 0, parent)
end

-- Регистрация 3D-инструментов (Botanic Axe, Jade Axe, Dew Can) в ReplicatedStorage/BotaniaTools
function WorldGenerator.BuildToolCatalog()
	local existing = ReplicatedStorage:FindFirstChild("BotaniaTools")
	if existing then existing:Destroy() end
	local toolsFolder = Instance.new("Folder")
	toolsFolder.Name = "BotaniaTools"
	toolsFolder.Parent = ReplicatedStorage

	for _, toolId in ipairs({ "tool_botanic_axe", "tool_jade_axe", "tool_dew_can" }) do
		local tool = StudioModelFactory.BuildStudioTool(toolId)
		tool.Parent = toolsFolder
	end
end

function WorldGenerator.BuildSeedSpire(parent: Instance, seed: number)
	local baseY = WorldGenerator.GetGroundHeight(SEED_SPIRE_POS.X, SEED_SPIRE_POS.Z, seed)
	local spire = Instance.new("Model")
	spire.Name = "WorldSeedSpire"
	local origin = CFrame.new(SEED_SPIRE_POS.X, baseY, SEED_SPIRE_POS.Z)

	makePart({ Size = Vector3.new(16, 2, 16), CFrame = origin * CFrame.new(0, 1, 0), Color = Color3.fromRGB(99, 110, 114), Material = Enum.Material.Slate, CollisionGroup = "Terrain", Parent = spire })
	makePart({ Size = Vector3.new(11, 2, 11), CFrame = origin * CFrame.new(0, 3, 0), Color = Color3.fromRGB(46, 204, 113), CollisionGroup = "Terrain", Parent = spire })
	makePart({ Size = Vector3.new(5, 18, 5), CFrame = origin * CFrame.new(0, 13, 0), Color = Color3.fromRGB(115, 128, 138), Material = Enum.Material.Slate, CollisionGroup = "Terrain", Parent = spire })
	makePart({ Size = Vector3.new(4, 6, 4), CFrame = origin * CFrame.new(0, 26, 0) * CFrame.Angles(0, math.pi / 4, 0), Color = Color3.fromRGB(0, 245, 212), Material = Enum.Material.Neon, CollisionGroup = "Terrain", Parent = spire })

	spire.Parent = parent
end

function WorldGenerator.GenerateWorld(seed: number)
	local existing = workspace:FindFirstChild("BotaniaWorld")
	if existing then existing:Destroy() end

	local worldFolder = Instance.new("Folder")
	worldFolder.Name = "BotaniaWorld"
	worldFolder.Parent = workspace

	local activeBiomes = BiomeRegistry.SelectServerBiomes(seed, 8)
	local centers = BiomeRegistry.GetBiomeCenters(activeBiomes)
	local rng = Random.new(seed + 101)
	local animalCounter = 0

	WorldGenerator.BuildToolCatalog()

	for x = -WORLD_RADIUS, WORLD_RADIUS, VOXEL_STEP do
		for z = -WORLD_RADIUS, WORLD_RADIUS, VOXEL_STEP do
			if x * x + z * z <= WORLD_RADIUS * WORLD_RADIUS then
				local biome = BiomeRegistry.GetBiomeAt(x, z, centers)
				local y = WorldGenerator.GetGroundHeight(x, z, seed)
				makePart({
					Name = "TerrainVoxel",
					Size = Vector3.new(VOXEL_STEP, 10, VOXEL_STEP),
					CFrame = CFrame.new(x, y - 5, z),
					Color = biome.GroundColor,
					CollisionGroup = "Terrain",
					Parent = worldFolder,
				}):SetAttribute("BiomeId", biome.Id)

				local nearSpawn = math.abs(x) < 20 and math.abs(z) < 20
				local nearSpire = (Vector2.new(x, z) - Vector2.new(SEED_SPIRE_POS.X, SEED_SPIRE_POS.Z)).Magnitude < 16
				if not nearSpawn and not nearSpire then
					local roll = rng:NextNumber()
					if roll < 0.055 then
						WorldGenerator.BuildFloraModel(biome, Vector3.new(x, y, z), worldFolder, rng)
					elseif roll < 0.068 then
						WorldGenerator.SpawnFaunaCritter(biome, Vector3.new(x, y, z), worldFolder, animalCounter)
						animalCounter += 1
					elseif roll < 0.165 then
						StudioModelFactory.BuildUndergrowth(biome, Vector3.new(x, y, z), rng, worldFolder)
					end
				end
			end
		end
		if x % 36 == 0 then task.wait() end
	end

	WorldGenerator.BuildSeedSpire(worldFolder, seed)
	ReplicatedStorage:SetAttribute("WorldSeed", seed)

	-- Живая анимация 6 видов фауны (наземная и летающая) и покачивание травы на ветру
	task.spawn(function()
		while worldFolder.Parent do
			local now = os.clock()
			for _, critter in ipairs(CollectionService:GetTagged("BotaniaFauna")) do
				if critter:IsDescendantOf(worldFolder) and critter:IsA("Model") and critter.PrimaryPart then
					local anchor = critter:GetAttribute("AnchorPos") :: Vector3
					local phase = critter:GetAttribute("Phase") :: number
					local kind = (critter:GetAttribute("AnimalKind") :: string?) or "Butterfly"
					local isFlyer = (kind == "Butterfly" or kind == "Bee" or kind == "Beetle")
					local speed = if isFlyer then 0.9 else 0.45
					local radius = if isFlyer then 8 else 6
					local t = now * speed + phase
					local nx = anchor.X + math.cos(t) * radius
					local nz = anchor.Z + math.sin(t * 1.3) * radius
					local groundY = WorldGenerator.GetGroundHeight(nx, nz, seed)
					local ny = if isFlyer
						then groundY + 4.4 + math.sin(t * 2.8) * 1.1
						else groundY + 1.0 + math.abs(math.sin(t * 6)) * 0.25
					local nextPos = Vector3.new(nx, ny, nz)
					local lookDir = Vector3.new(-math.sin(t), 0, math.cos(t) * 1.3)
					critter:PivotTo(CFrame.lookAt(nextPos, nextPos + lookDir))
				end
			end

			for _, tuft in ipairs(CollectionService:GetTagged("BotaniaWindSway")) do
				if tuft:IsDescendantOf(worldFolder) and tuft:IsA("Model") then
					local baseCF = tuft:GetAttribute("OriginCFrame") :: CFrame?
					if baseCF then
						local sway = math.sin(now * 2.1 + baseCF.Position.X * 0.15) * 0.08
						tuft:PivotTo(baseCF * CFrame.Angles(sway, 0, sway * 0.6))
					end
				end
			end
			task.wait(0.05)
		end
	end)

	return activeBiomes, centers
end

return WorldGenerator`,
  },
  {
    id: 'botany_mechanics',
    name: 'BotanyMechanicsService',
    className: 'ModuleScript',
    service: 'ServerScriptService',
    folder: 'BotaniaServer',
    robloxPath: 'ServerScriptService/BotaniaServer/BotanyMechanicsService',
    summary: 'Серверные механики: физическое падение деревьев, сфера лута с Touched-коллизией, грядки, скрещивание семян, проверка перекрытий при стройке и купол от токсичности.',
    apis: ['Workspace', 'CollectionService', 'Debris', 'Players'],
    code: `--!strict
-- ServerScriptService/BotaniaServer/BotanyMechanicsService (ModuleScript)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local BiomeRegistry = require(Shared:WaitForChild("BiomeRegistry"))
local ItemRegistry = require(Shared:WaitForChild("ItemAndRecipeRegistry"))
local StudioModelFactory = require(Shared:WaitForChild("StudioModelFactory"))
local DataStoreManager = require(script.Parent.DataStoreManager)

local BotanyMechanics = {}
local GRID_SIZE = 4
local ActivePlanters: { { Model: Model, Pos: Vector3, SeedId: string?, PlantedAt: number, Watered: boolean, Ready: boolean } } = {}

export type EventHooks = {
	OnItemCollected: ((Player, string, number) -> ())?,
	OnFloraFelled: ((Player, string) -> ())?,
	OnBlockPlaced: ((Player, string, Vector3) -> ())?,
}
local Hooks: EventHooks = {}

function BotanyMechanics.SetEventHooks(hooks: EventHooks)
	Hooks = hooks
end

function BotanyMechanics.GiveItem(player: Player, itemId: string, count: number): boolean
	local profile = DataStoreManager.GetProfile(player)
	local def = ItemRegistry.Items[itemId]
	if not profile or not def or count <= 0 then return false end

	local remaining = count
	local function fill(arr: { [number]: DataStoreManager.SlotItem? }, maxSlots: number)
		for i = 1, maxSlots do
			if remaining <= 0 then break end
			local slot = arr[i]
			if slot and slot.Id == itemId and slot.Count < def.MaxStack then
				local add = math.min(remaining, def.MaxStack - slot.Count)
				slot.Count += add
				remaining -= add
			end
		end
		for i = 1, maxSlots do
			if remaining <= 0 then break end
			if not arr[i] then
				local add = math.min(remaining, def.MaxStack)
				arr[i] = { Id = itemId, Count = add }
				remaining -= add
			end
		end
	end

	fill(profile.Inventory.Hotbar, 6)
	fill(profile.Inventory.Backpack, 18)
	return remaining < count
end

-- Физический 3D-дроп ресурсов с кастомной геометрией и подбором при касании (Touched)
function BotanyMechanics.SpawnPhysicalLoot(pos: Vector3, itemId: string, count: number)
	local def = ItemRegistry.Items[itemId]
	if not def then return end

	local spawnPos = pos + Vector3.new(math.random(-2, 2), 3, math.random(-2, 2))
	local dropModel = StudioModelFactory.BuildItemDropModel(itemId, def.Color, spawnPos, workspace)
	local core = dropModel.PrimaryPart
	if not core then
		dropModel:Destroy()
		return
	end

	core:ApplyImpulse(Vector3.new(math.random(-12, 12), 28, math.random(-12, 12)))

	local collected = false
	core.Touched:Connect(function(hit)
		if collected then return end
		local char = hit.Parent
		local player = if char then Players:GetPlayerFromCharacter(char) else nil
		local root = if char then char:FindFirstChild("HumanoidRootPart") :: BasePart? else nil
		if player and root and (root.Position - core.Position).Magnitude <= 14 then
			if BotanyMechanics.GiveItem(player, itemId, count) then
				collected = true
				dropModel:Destroy()
				if Hooks.OnItemCollected then
					Hooks.OnItemCollected(player, itemId, count)
				end
			end
		end
	end)

	Debris:AddItem(dropModel, 45)
end

-- Рубка флоры с физическим падением ствола на землю перед дропом ресурсов
function BotanyMechanics.HitFlora(player: Player, floraModel: Model, hitDirection: Vector3)
	if not CollectionService:HasTag(floraModel, "BotaniaFlora") then return end
	local hp = (floraModel:GetAttribute("HP") :: number?) or 0
	if hp <= 0 then return end

	hp -= 1
	floraModel:SetAttribute("HP", hp)
	if hp > 0 then return end

	local biomeId = floraModel:GetAttribute("BiomeId") :: string
	local biome = BiomeRegistry.ById[biomeId]
	local primary = floraModel.PrimaryPart
	local dropPos = if primary then primary.Position else Vector3.zero

	-- Снимаем якорь, чтобы срубленное дерево физически рухнуло с коллизией!
	for _, part in ipairs(floraModel:GetDescendants()) do
		if part:IsA("BasePart") then
			part.Anchored = false
		end
	end
	if primary then
		local fallDir = Vector3.new(hitDirection.X, 0.25, hitDirection.Z).Unit
		primary:ApplyImpulse(fallDir * primary:GetMass() * 24)
	end
	if biomeId and Hooks.OnFloraFelled then
		Hooks.OnFloraFelled(player, biomeId)
	end

	task.delay(1.35, function()
		if biome then
			BotanyMechanics.SpawnPhysicalLoot(dropPos, biome.UniqueResourceId, 2)
			BotanyMechanics.SpawnPhysicalLoot(dropPos, biome.SeedId, 1)
			BotanyMechanics.SpawnPhysicalLoot(dropPos, "res_wood", 2)
		end
		floraModel:Destroy()
	end)
end

-- Строительство по сетке с проверкой коллизий OverlapParams (нельзя ставить внутри игрока или другого блока)
function BotanyMechanics.TryPlaceBlock(player: Player, kind: string, worldPos: Vector3): (boolean, string)
	local snapped = Vector3.new(
		math.round(worldPos.X / GRID_SIZE) * GRID_SIZE,
		math.round(worldPos.Y / GRID_SIZE) * GRID_SIZE + 2,
		math.round(worldPos.Z / GRID_SIZE) * GRID_SIZE
	)

	local overlapParams = OverlapParams.new()
	overlapParams.FilterType = Enum.RaycastFilterType.Exclude
	local blockers = workspace:GetPartBoundsInBox(CFrame.new(snapped), Vector3.new(3.6, 3.6, 3.6), overlapParams)
	for _, part in ipairs(blockers) do
		if part.CollisionGroup == "PlayerBuilt" or part.CollisionGroup == "Players" or part.CollisionGroup == "FloraTrunks" then
			return false, "Место занято коллизией другого объекта"
		end
	end

	local model = Instance.new("Model")
	model.Name = "Built_" .. kind
	local part = Instance.new("Part")
	part.Size = Vector3.new(4, 4, 4)
	part.CFrame = CFrame.new(snapped)
	part.Anchored = true
	part.CanCollide = true
	part.CollisionGroup = "PlayerBuilt"

	if kind == "GlassWall" then
		part.Color = Color3.fromRGB(112, 232, 255)
		part.Material = Enum.Material.Glass
		part.Transparency = 0.45
	elseif kind == "PlanterBox" then
		part.Size = Vector3.new(4, 1.5, 4)
		part.CFrame = CFrame.new(snapped - Vector3.new(0, 1.25, 0))
		part.Color = Color3.fromRGB(118, 84, 56)
		part.Material = Enum.Material.Wood
		table.insert(ActivePlanters, { Model = model, Pos = snapped, SeedId = nil, PlantedAt = 0, Watered = false, Ready = false })
	elseif kind == "SeedAltar" then
		part.Color = Color3.fromRGB(197, 108, 240)
		part.Material = Enum.Material.Neon
		CollectionService:AddTag(model, "BotaniaSafeDome")
	else
		part.Color = Color3.fromRGB(106, 176, 76)
		part.Material = Enum.Material.WoodPlanks
	end

	part.Parent = model
	model.PrimaryPart = part
	model.Parent = workspace
	if Hooks.OnBlockPlaced then
		Hooks.OnBlockPlaced(player, kind, snapped)
	end
	return true, "Блок установлен"
end

-- Проверка защитного купола теплицы (Алтарь семян в радиусе 22 studs блокирует урон токсичными спорами)
function BotanyMechanics.IsProtectedByDome(pos: Vector3): boolean
	for _, dome in ipairs(CollectionService:GetTagged("BotaniaSafeDome")) do
		if dome:IsA("Model") and dome.PrimaryPart then
			if (dome.PrimaryPart.Position - pos).Magnitude <= 22 then
				return true
			end
		end
	end
	return false
end

-- Механика культивации и скрещивания (гибридизации) семян на соседних грядках
function BotanyMechanics.PlantSeed(planterModel: Model, seedId: string): boolean
	for _, p in ipairs(ActivePlanters) do
		if p.Model == planterModel and not p.SeedId then
			p.SeedId = seedId
			p.PlantedAt = os.clock()
			p.Ready = false
			local sprout = Instance.new("Part")
			sprout.Name = "Sprout"
			sprout.Size = Vector3.new(1.2, 1.2, 1.2)
			sprout.CFrame = CFrame.new(p.Pos)
			sprout.Anchored = true
			sprout.CanCollide = false
			sprout.Color = Color3.fromRGB(46, 204, 113)
			sprout.Parent = planterModel
			return true
		end
	end
	return false
end

function BotanyMechanics.UpdatePlanters(activeWeather: string)
	local now = os.clock()
	for _, p in ipairs(ActivePlanters) do
		if p.SeedId and not p.Ready then
			if activeWeather == "Sunshower" then
				p.Watered = true
			end
			local growTime = if p.Watered then 20 else 36
			if now - p.PlantedAt >= growTime then
				p.Ready = true
				-- Ищем соседа в радиусе 6 studs для кросс-опыления!
				local hybridResult: string? = nil
				for _, other in ipairs(ActivePlanters) do
					if other ~= p and other.SeedId and (other.Pos - p.Pos).Magnitude <= 6.5 then
						local xb = ItemRegistry.FindCrossbreed(p.SeedId, other.SeedId)
						if xb then
							hybridResult = xb.ResultItemId
							break
						end
					end
				end
				BotanyMechanics.SpawnPhysicalLoot(p.Pos + Vector3.new(0, 1.5, 0), hybridResult or p.SeedId, 1)
				p.SeedId = nil
				p.Watered = false
				local sprout = p.Model:FindFirstChild("Sprout")
				if sprout then sprout:Destroy() end
			end
		end
	end
end

return BotanyMechanics`,
  },
  {
    id: 'time_weather_anticheat',
    name: 'TimeWeatherAndAntiCheat',
    className: 'Script',
    service: 'ServerScriptService',
    folder: 'BotaniaServer',
    robloxPath: 'ServerScriptService/BotaniaServer/TimeWeatherAndAntiCheat',
    summary: 'Главный серверный оркестратор: смена дня/ночи и погоды, урон спорами, серверный анти-чит, 4-игроковое лобби TeleportService и донат Флоринов.',
    apis: ['Lighting', 'TweenService', 'TeleportService', 'MarketplaceService', 'RunService'],
    code: `--!strict
-- ServerScriptService/BotaniaServer/TimeWeatherAndAntiCheat (Script)
local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local TeleportService = game:GetService("TeleportService")
local MarketplaceService = game:GetService("MarketplaceService")

local Shared = ReplicatedStorage:WaitForChild("BotaniaShared")
local BiomeRegistry = require(Shared:WaitForChild("BiomeRegistry"))
local SkillConfig = require(Shared:WaitForChild("SkillAndQuestConfig"))

local DataStoreManager = require(script.Parent.DataStoreManager)
local WorldGenerator = require(script.Parent.WorldGenerator)
local BotanyMechanics = require(script.Parent.BotanyMechanicsService)
local AntiCheatEngine = require(script.Parent.AntiCheatEngine)
local QuestSystem = require(script.Parent.QuestSystem)

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local HitFloraRemote = Remotes:WaitForChild("HitFlora") :: RemoteEvent
local PlaceBlockRemote = Remotes:WaitForChild("PlaceBlock") :: RemoteEvent
local LobbyRemote = Remotes:WaitForChild("LobbyAction") :: RemoteEvent
local TeleportStateRemote = Remotes:WaitForChild("TeleportState") :: RemoteEvent
local SwapSlotRemote = Remotes:WaitForChild("SwapSlot") :: RemoteEvent
local CraftItemRemote = Remotes:WaitForChild("CraftItem") :: RemoteEvent
local UnlockSkillRemote = Remotes:WaitForChild("UnlockSkill") :: RemoteEvent
local PlantSeedRemote = Remotes:WaitForChild("PlantSeed") :: RemoteEvent

-- Запускаем непрерывный серверный анти-чит и аудит DataStore
AntiCheatEngine.Start()

local worldSeed = math.random(10000, 99999)
local activeBiomes, biomeCenters = WorldGenerator.GenerateWorld(worldSeed)
local activeBiomeIds: { string } = {}
for _, b in ipairs(activeBiomes) do
	table.insert(activeBiomeIds, b.Id)
end

-- Запускаем процедурную систему квестов биомов и подключаем серверные хуки прогресса
QuestSystem.Start(biomeCenters)
BotanyMechanics.SetEventHooks({
	OnItemCollected = QuestSystem.RecordItemCollected,
	OnFloraFelled = QuestSystem.RecordFloraFelled,
	OnBlockPlaced = QuestSystem.RecordBlockPlaced,
})

HitFloraRemote.OnServerEvent:Connect(function(player, floraModel: any, hitDir: any)
	local ok = AntiCheatEngine.ValidateHarvestAction(player, floraModel)
	if not ok then return end
	local char = player.Character
	local root = if char then char:FindFirstChild("HumanoidRootPart") :: BasePart? else nil
	local dir = if typeof(hitDir) == "Vector3" then hitDir elseif root then root.CFrame.LookVector else Vector3.new(0, 0, -1)
	BotanyMechanics.HitFlora(player, floraModel, dir)
end)

PlaceBlockRemote.OnServerEvent:Connect(function(player, kind: any, worldPos: any)
	local ok = AntiCheatEngine.ValidateBuildAction(player, kind, worldPos)
	if not ok then return end
	BotanyMechanics.TryPlaceBlock(player, kind, worldPos)
end)

CraftItemRemote.OnServerEvent:Connect(function(player, recipeId: any, stationPos: any)
	local ok, outputId, outCount = AntiCheatEngine.ValidateAndExecuteCraft(player, recipeId, stationPos)
	if ok then
		BotanyMechanics.GiveItem(player, outputId, outCount or 1)
	end
end)

SwapSlotRemote.OnServerEvent:Connect(function(player, fromSection: any, fromIdx: any, toSection: any, toIdx: any)
	AntiCheatEngine.ValidateSlotSwap(player, fromSection, fromIdx, toSection, toIdx)
end)

UnlockSkillRemote.OnServerEvent:Connect(function(player, skillId: any)
	AntiCheatEngine.ValidateAndUnlockSkill(player, skillId)
end)

PlantSeedRemote.OnServerEvent:Connect(function(player, planterModel: any, seedId: any)
	local ok = AntiCheatEngine.ValidatePlantSeed(player, planterModel, seedId)
	if ok then
		if BotanyMechanics.PlantSeed(planterModel, seedId) then
			QuestSystem.RecordSeedPlanted(player, seedId)
		end
	end
end)

-- Лобби комнаты до 4 человек и двунаправленная телепортация (Мир <-> Лобби)
local Rooms: { [string]: { Host: Player, Privacy: string, Members: { Player } } } = {}
LobbyRemote.OnServerEvent:Connect(function(player, action: string, arg: any)
	if not AntiCheatEngine.CheckRateLimit(player) then return end
	if action == "CreateRoom" then
		Rooms["Room_" .. player.UserId] = { Host = player, Privacy = tostring(arg or "Friends"), Members = { player } }
	elseif action == "LaunchWorld" then
		local room = Rooms["Room_" .. player.UserId]
		if room and #room.Members <= 4 then
			local nextSeed = math.random(10000, 99999)
			local targetBiomes = BiomeRegistry.SelectServerBiomes(nextSeed, 8)
			local targetIds = {}
			for _, b in ipairs(targetBiomes) do table.insert(targetIds, b.Id) end

			local payload = {
				Direction = "ToWorld",
				WorldSeed = nextSeed,
				PartySize = #room.Members,
				ActiveBiomeIds = targetIds,
				Tips = SkillConfig.GetTipsForTeleport("ToWorld", targetIds),
			}
			for _, member in ipairs(room.Members) do
				TeleportStateRemote:FireClient(member, payload)
			end

			local options = Instance.new("TeleportOptions")
			options:SetTeleportData(payload)
			pcall(function()
				TeleportService:TeleportAsync(game.PlaceId, room.Members, options)
			end)
		end
	elseif action == "ReturnToLobby" then
		DataStoreManager.SaveAsync(player, false)
		local payload = {
			Direction = "ToLobby",
			PartySize = 1,
			ActiveBiomeIds = activeBiomeIds,
			Tips = SkillConfig.GetTipsForTeleport("ToLobby", activeBiomeIds),
		}
		TeleportStateRemote:FireClient(player, payload)
		local options = Instance.new("TeleportOptions")
		options:SetTeleportData(payload)
		pcall(function()
			TeleportService:TeleportAsync(game.PlaceId, { player }, options)
		end)
	end
end)

-- Донат валюты Флоринов через MarketplaceService с авторизацией в AntiCheatEngine
MarketplaceService.ProcessReceipt = function(receipt)
	local player = Players:GetPlayerByUserId(receipt.PlayerId)
	if not player then return Enum.ProductPurchaseDecision.NotProcessedYet end
	local profile = DataStoreManager.GetProfile(player)
	local grant = SkillConfig.DeveloperProducts[receipt.ProductId]
	if profile and grant then
		AntiCheatEngine.AuthorizeFlorinGrant(player, grant)
		profile.Florins += grant
		DataStoreManager.SaveAsync(player, false)
		return Enum.ProductPurchaseDecision.PurchaseGranted
	end
	return Enum.ProductPurchaseDecision.NotProcessedYet
end

Players.PlayerAdded:Connect(function(player)
	local loadedProfile = DataStoreManager.LoadAsync(player)
	if loadedProfile then
		AntiCheatEngine.SyncLoadedProfile(player, loadedProfile)
	end
	local toolsFolder = ReplicatedStorage:FindFirstChild("BotaniaTools")
	if toolsFolder then
		local backpack = player:WaitForChild("Backpack", 5)
		local starterGear = player:WaitForChild("StarterGear", 5)
		for _, starterId in ipairs({ "tool_botanic_axe", "tool_dew_can" }) do
			local tpl = toolsFolder:FindFirstChild(starterId)
			if tpl then
				if backpack then tpl:Clone().Parent = backpack end
				if starterGear then tpl:Clone().Parent = starterGear end
			end
		end
	end
end)

-- Динамический цикл дня/ночи, погоды и токсичности биомов (мониторинг движения вынесен в AntiCheatEngine)
local clockTime = 10.0
local activeWeather = "Clear"
local weatherTick = 0
local toxicityTick = 0

RunService.Heartbeat:Connect(function(dt)
	clockTime = (clockTime + dt * 0.06) % 24
	Lighting.ClockTime = clockTime

	weatherTick += dt
	if weatherTick >= 60 then
		weatherTick = 0
		local list = { "Clear", "Pollen", "Sunshower", "Mist" }
		activeWeather = list[(table.find(list, activeWeather) or 1) % #list + 1]
		ReplicatedStorage:SetAttribute("ActiveWeather", activeWeather)
		local atmo = Lighting:FindFirstChildOfClass("Atmosphere")
		if atmo then
			TweenService:Create(atmo, TweenInfo.new(6), {
				Density = if activeWeather == "Mist" then 0.52 elseif activeWeather == "Pollen" then 0.4 else 0.25,
			}):Play()
		end
	end

	BotanyMechanics.UpdatePlanters(activeWeather)

	toxicityTick += dt
	if toxicityTick >= 2.0 then
		toxicityTick = 0
		for _, player in ipairs(Players:GetPlayers()) do
			local char = player.Character
			local root = if char then char:FindFirstChild("HumanoidRootPart") :: BasePart? else nil
			local hum = if char then char:FindFirstChildOfClass("Humanoid") else nil
			if root and hum and hum.Health > 0 then
				-- Выживание: токсичность редких биомов без Алтаря семян (купола)
				local biome = BiomeRegistry.GetBiomeAt(root.Position.X, root.Position.Z, biomeCenters)
				if biome.ToxicityLevel >= 2 and not BotanyMechanics.IsProtectedByDome(root.Position) then
					hum:TakeDamage(biome.ToxicityLevel * 2)
				end
			end
		end
	end
end)`,
  },
];
