import React, { useMemo, useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  FolderOpen,
  RefreshCw,
  Search,
} from 'lucide-react';
import {
  BOTANIA_BIOMES,
  getBiomeToxicity,
  selectServerBiomes,
} from './game/biomes';
import {
  selectSurvivalTipsForTeleport,
  TeleportDirection,
} from './game/progression';
import { EXTERNAL_ASSET_PACKS, STUDIO_MODEL_CATALOG } from './roblox/luauModels';
import { ALL_ROBLOX_SCRIPTS, generateRbxlxXml } from './roblox/rbxlxExporter';

type WorkspaceTab = 'scripts' | 'assets' | 'mechanics' | 'biomes' | 'guide';

interface CollisionRow {
  groupA: string;
  groupB: string;
  collides: boolean;
  purpose: string;
}

const COLLISION_MATRIX: CollisionRow[] = [
  {
    groupA: 'Players',
    groupB: 'Terrain',
    collides: true,
    purpose: 'Опора на воксельном ландшафте и холмах границ острова',
  },
  {
    groupA: 'Players',
    groupB: 'FloraTrunks',
    collides: true,
    purpose: 'Твёрдые стволы деревьев, кактусов и кристаллов',
  },
  {
    groupA: 'Players',
    groupB: 'FloraCanopy',
    collides: false,
    purpose: 'Игрок свободно проходит под кронами, не застревая в листве',
  },
  {
    groupA: 'Players',
    groupB: 'PlayerBuilt',
    collides: true,
    purpose: 'Стены, грядки, стёкла теплицы и алтари имеют полную коллизию',
  },
  {
    groupA: 'Players',
    groupB: 'LootPickups',
    collides: false,
    purpose: 'Физические сферы ресурсов не толкают игрока, но срабатывает Touched',
  },
  {
    groupA: 'LootPickups',
    groupB: 'Terrain / PlayerBuilt',
    collides: true,
    purpose: 'Выпавший лут падает на землю и пол базы после рубки дерева',
  },
];

const CROSSBREED_PAIRS = [
  {
    seedA: 'Семя: Сакуровые Террасы',
    seedB: 'Семя: Лощина Папоротника',
    result: 'Люмен-орхидея (Гибрид)',
    time: '35 с',
    effect: 'Светится ночью и даёт +25 XP при сборе',
  },
  {
    seedA: 'Семя: Грибной Каньон',
    seedB: 'Семя: Лагуна Лотосов',
    result: 'Алый лотос (Гибрид)',
    time: '40 с',
    effect: 'Основа для усиленных фильтров от спор',
  },
  {
    seedA: 'Семя: Бамбуковый Лабиринт',
    seedB: 'Семя: Кристальная Теплица',
    result: 'Кристальный бамбук (Гибрид)',
    time: '45 с',
    effect: 'Сверхпрочный материал для купола базы',
  },
];

const ARCHETYPE_LABELS: Record<string, string> = {
  oak: 'Воксельное дерево',
  sakura: 'Сакура',
  mushroom: 'Гигантский гриб',
  bamboo: 'Тройной бамбук',
  crystal: 'Кристальный шпиль',
  cactus: 'Кактус с цветком',
  willow: 'Плакучая крона',
  fern: 'Гигантский папоротник',
};

const SERVICE_GROUPS = [
  'ReplicatedStorage',
  'ServerScriptService',
  'StarterPlayerScripts',
  'StarterGui',
] as const;

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('scripts');
  const [selectedScriptId, setSelectedScriptId] = useState<string>(ALL_ROBLOX_SCRIPTS[0].id);
  const [scriptSearch, setScriptSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [seedInput, setSeedInput] = useState<number>(40482);
  const [biomeSearch, setBiomeSearch] = useState('');
  const [toxicityFilter, setToxicityFilter] = useState<'all' | 'safe' | 'mid' | 'high'>('all');
  const [teleportDir, setTeleportDir] = useState<TeleportDirection>('ToWorld');
  const [tipCycleIdx, setTipCycleIdx] = useState<number>(0);

  const selectedScript = useMemo(
    () => ALL_ROBLOX_SCRIPTS.find((s) => s.id === selectedScriptId) ?? ALL_ROBLOX_SCRIPTS[0],
    [selectedScriptId]
  );

  const filteredScripts = useMemo(() => {
    const q = scriptSearch.trim().toLowerCase();
    if (!q) return ALL_ROBLOX_SCRIPTS;
    return ALL_ROBLOX_SCRIPTS.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.robloxPath.toLowerCase().includes(q) ||
        s.summary.toLowerCase().includes(q)
    );
  }, [scriptSearch]);

  const spawned8Biomes = useMemo(() => selectServerBiomes(seedInput, 8), [seedInput]);

  const teleportTips = useMemo(
    () =>
      selectSurvivalTipsForTeleport(
        teleportDir,
        spawned8Biomes.map((b) => b.id)
      ),
    [teleportDir, spawned8Biomes]
  );
  const activeTeleportTip = teleportTips[tipCycleIdx % teleportTips.length] ?? teleportTips[0];

  const filteredBiomes = useMemo(() => {
    const q = biomeSearch.trim().toLowerCase();
    return BOTANIA_BIOMES.filter((b) => {
      const tox = getBiomeToxicity(b);
      if (toxicityFilter === 'safe' && tox !== 0) return false;
      if (toxicityFilter === 'mid' && (tox < 1 || tox > 2)) return false;
      if (toxicityFilter === 'high' && tox < 3) return false;
      if (!q) return true;
      return (
        b.name.toLowerCase().includes(q) ||
        b.uniqueResourceName.toLowerCase().includes(q) ||
        b.faunaName.toLowerCase().includes(q)
      );
    });
  }, [biomeSearch, toxicityFilter]);

  const handleDownloadRbxlx = () => {
    const xml = generateRbxlxXml();
    const blob = new Blob([xml], { type: 'application/xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Botania.rbxlx';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleDownloadLuau = (name: string, code: string) => {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name}.luau`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleCopyCode = (id: string, code: string) => {
    navigator.clipboard?.writeText(code).catch(() => {});
    setCopiedId(id);
    window.setTimeout(() => setCopiedId(null), 1600);
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#0f1417] text-[#eef2f5]">
      {/* Strict 3-Zone Top Bar */}
      <header className="border-b border-[#222c33] bg-[#12181c]">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-4 px-6 py-3.5 md:gap-8">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('scripts');
            }}
            className="whitespace-nowrap shrink-0 font-display text-lg font-bold tracking-tight text-white"
          >
            Botania Studio
          </a>

          <nav className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm font-medium text-[#9fb0ba]">
            {(
              [
                { id: 'scripts', label: 'Скрипты Luau' },
                { id: 'assets', label: 'Модели и ассеты' },
                { id: 'mechanics', label: 'Коллизии и механики' },
                { id: 'biomes', label: '30 Биомов' },
                { id: 'guide', label: 'Интеграция' },
              ] as const
            ).map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`whitespace-nowrap shrink-0 border-b-2 py-1 transition-colors ${
                    active
                      ? 'border-[#22c55e] text-white'
                      : 'border-transparent hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={handleDownloadRbxlx}
              className="flex items-center gap-2 whitespace-nowrap shrink-0 rounded-lg bg-[#22c55e] px-4 py-2 text-xs font-bold text-[#07160c] transition-colors hover:bg-[#34d369]"
            >
              <Download className="h-4 w-4" />
              <span>Скачать Botania.rbxlx</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto w-full max-w-[1440px] flex-1 px-6 py-6">
        {activeTab === 'scripts' && (
          <div className="grid gap-6 lg:grid-cols-12">
            {/* Explorer Sidebar */}
            <aside className="flex flex-col rounded-xl border border-[#222c33] bg-[#141b1f] lg:col-span-4 xl:col-span-3">
              <div className="border-b border-[#222c33] p-4">
                <h1 className="font-display text-base font-bold text-white">
                  Explorer Roblox Studio
                </h1>
                <p className="mt-1 text-xs text-[#91a3ad]">
                  {ALL_ROBLOX_SCRIPTS.length} готовых Luau-модулей без заглушек для прямого импорта в плейс
                </p>
                <div className="relative mt-3">
                  <Search className="pointer-events-none absolute top-2.5 left-3 h-4 w-4 text-[#738793]" />
                  <input
                    type="text"
                    value={scriptSearch}
                    onChange={(e) => setScriptSearch(e.target.value)}
                    placeholder="Поиск скрипта или API..."
                    aria-label="Поиск Luau скрипта"
                    className="w-full rounded-lg border border-[#26323a] bg-[#0f1417] py-2 pr-3 pl-9 text-xs text-white placeholder-[#6b7e89] focus:border-[#22c55e] focus:outline-none"
                  />
                </div>
              </div>

              <div className="studio-scroll max-h-[620px] flex-1 overflow-y-auto p-3">
                {SERVICE_GROUPS.map((serviceName) => {
                  const groupScripts = filteredScripts.filter((s) => s.service === serviceName);
                  if (groupScripts.length === 0) return null;
                  return (
                    <div key={serviceName} className="mb-4 last:mb-0">
                      <div className="mb-1.5 flex items-center gap-2 px-2 text-xs font-semibold text-[#8a9ca6]">
                        <FolderOpen className="h-3.5 w-3.5 text-[#eab308]" />
                        <span>{serviceName}</span>
                      </div>
                      <div className="space-y-1">
                        {groupScripts.map((script) => {
                          const active = script.id === selectedScript.id;
                          return (
                            <button
                              key={script.id}
                              type="button"
                              onClick={() => setSelectedScriptId(script.id)}
                              className={`flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-left text-xs transition-colors ${
                                active
                                  ? 'bg-[#1c2b23] text-white'
                                  : 'text-[#b7c5cd] hover:bg-[#192227] hover:text-white'
                              }`}
                            >
                              <span className="flex min-w-0 items-center gap-2">
                                <FileCode2 className="h-3.5 w-3.5 shrink-0 text-[#38bdf8]" />
                                <span className="truncate font-mono font-medium">
                                  {script.name}.luau
                                </span>
                              </span>
                              <span className="shrink-0 text-[11px] text-[#7c909b]">
                                {script.className === 'ModuleScript'
                                  ? 'Module'
                                  : script.className === 'LocalScript'
                                    ? 'Local'
                                    : 'Server'}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
                {filteredScripts.length === 0 && (
                  <div className="p-4 text-center text-xs text-[#7c909b]">
                    Скрипты не найдены. Очистите фильтр поиска.
                  </div>
                )}
              </div>
            </aside>

            {/* Code Viewer */}
            <section className="flex flex-col overflow-hidden rounded-xl border border-[#222c33] bg-[#141b1f] lg:col-span-8 xl:col-span-9">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#222c33] px-5 py-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#8a9ca6]">
                    <span className="font-mono text-[#38bdf8]">{selectedScript.robloxPath}</span>
                    <span aria-hidden="true">·</span>
                    <span>{selectedScript.className}</span>
                    <span aria-hidden="true">·</span>
                    <span>{selectedScript.apis.join(' · ')}</span>
                  </div>
                  <h2 className="mt-1 font-display text-xl font-bold text-white">
                    {selectedScript.name}.luau
                  </h2>
                  <p className="mt-1 text-sm text-[#adc0ca]">{selectedScript.summary}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleDownloadLuau(selectedScript.name, selectedScript.code)}
                    className="flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#2c3a43] bg-[#1a2429] px-3 py-2 text-xs font-semibold text-[#d9e3e8] hover:bg-[#223037]"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Скачать .luau</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCopyCode(selectedScript.id, selectedScript.code)}
                    className="flex items-center gap-1.5 whitespace-nowrap rounded-lg bg-[#22c55e] px-3.5 py-2 text-xs font-bold text-[#07160c] hover:bg-[#34d369]"
                  >
                    {copiedId === selectedScript.id ? (
                      <Check className="h-3.5 w-3.5" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                    <span>
                      {copiedId === selectedScript.id ? 'Скопировано' : 'Копировать код'}
                    </span>
                  </button>
                </div>
              </div>

              <pre className="studio-scroll max-h-[620px] flex-1 overflow-auto bg-[#0c1114] p-5 font-mono text-xs leading-relaxed text-[#d7e5dd]">
                <code>{selectedScript.code}</code>
              </pre>
            </section>
          </div>
        )}

        {activeTab === 'assets' && (
          <div className="space-y-8">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold text-white text-balance">
                  Кастомные 3D-модели и проверенные пакеты ассетов
                </h1>
                <p className="mt-1.5 max-w-3xl text-sm text-[#a6b8c2]">
                  Два уровня визуализации: встроенная студийная фабрика{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">StudioModelFactory.luau</code>{' '}
                  (работает сразу внутри <code className="font-mono text-xs text-[#38bdf8]">Botania.rbxlx</code> без
                  загрузки мешей) и подборка бесплатных CC0 / DevForum наборов для замены на MeshPart.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedScriptId('studio_model_factory');
                  setActiveTab('scripts');
                }}
                className="flex items-center gap-2 whitespace-nowrap shrink-0 rounded-lg border border-[#2c3a43] bg-[#1a2429] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#223037]"
              >
                <Code2 className="h-4 w-4 text-[#22c55e]" />
                <span>Открыть StudioModelFactory.luau</span>
              </button>
            </div>

            {/* Built-in Procedural Studio Models */}
            <section className="overflow-hidden rounded-xl border border-[#222c33] bg-[#141b1f]">
              <div className="border-b border-[#222c33] px-5 py-3.5">
                <h2 className="font-display text-base font-bold text-white">
                  01. Встроенные студийные 3D-модели (генерируются в Botania.rbxlx автоматически)
                </h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[#222c33] bg-[#11171a] text-xs font-semibold text-[#8fa3ae]">
                    <tr>
                      <th className="px-5 py-3">Категория</th>
                      <th className="px-5 py-3">Состав моделей</th>
                      <th className="px-5 py-3">Детализация</th>
                      <th className="px-5 py-3">Геометрия и эффекты</th>
                      <th className="px-5 py-3">CollisionGroup</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1f282e]">
                    {STUDIO_MODEL_CATALOG.map((item) => (
                      <tr key={item.category} className="hover:bg-[#182126]">
                        <td className="px-5 py-3 whitespace-nowrap text-xs font-bold text-[#22c55e]">
                          {item.category}
                        </td>
                        <td className="px-5 py-3 text-xs font-medium text-white">{item.name}</td>
                        <td className="px-5 py-3 whitespace-nowrap font-mono text-xs tabular-nums text-[#38bdf8]">
                          {item.partsCount}
                        </td>
                        <td className="px-5 py-3 text-xs text-[#b5c4cc]">
                          {item.jointsAndEffects}
                        </td>
                        <td className="px-5 py-3 font-mono text-xs text-[#9fb0ba]">
                          {item.collisionGroup}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Verified External Asset Packs from Web Search */}
            <section className="space-y-4">
              <div>
                <h2 className="font-display text-lg font-bold text-white">
                  02. Бесплатные внешние наборы моделей из интернета (CC0 и Roblox DevForum)
                </h2>
                <p className="mt-1 text-xs text-[#9fb0ba]">
                  Реальные проверенные библиотеки с низкополигональными деревьями, травой, цветами, камнями и анимированными животными для импорта через Mesh Importer или .rbxl.
                </p>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                {EXTERNAL_ASSET_PACKS.map((pack) => (
                  <article
                    key={pack.id}
                    className="flex flex-col justify-between rounded-xl border border-[#222c33] bg-[#141b1f] p-5"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-[#38bdf8]">
                            {pack.source} · {pack.author}
                          </div>
                          <h3 className="mt-1 font-display text-base font-bold text-white">
                            {pack.title}
                          </h3>
                        </div>
                        <a
                          href={pack.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg border border-[#2c3a43] bg-[#1a2429] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:border-[#22c55e] hover:text-[#22c55e]"
                        >
                          <span>Открыть источник</span>
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      </div>

                      <p className="mt-2.5 text-sm leading-relaxed text-[#b5c4cc]">
                        {pack.description}
                      </p>

                      <div className="mt-3 text-xs text-[#8fa3ae]">
                        <span className="font-semibold text-[#d7e5dd]">Категории:</span>{' '}
                        {pack.categories.join(' · ')}
                      </div>
                      <div className="mt-1 text-xs text-[#8fa3ae]">
                        <span className="font-semibold text-[#d7e5dd]">Форматы:</span>{' '}
                        <span className="font-mono">{pack.formats}</span>
                        <span aria-hidden="true"> · </span>
                        <span>{pack.license}</span>
                      </div>
                    </div>

                    <div className="mt-4 border-t border-[#222c33] pt-3 text-xs leading-relaxed text-[#9fb0ba]">
                      <span className="font-semibold text-[#22c55e]">Импорт в Studio:</span>{' '}
                      {pack.importTip}
                    </div>
                  </article>
                ))}
              </div>
            </section>
          </div>
        )}

        {activeTab === 'mechanics' && (
          <div className="space-y-8">
            <div>
              <h1 className="font-display text-2xl font-bold text-white text-balance">
                Физика коллизий и ключевые механики Botania
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm text-[#a6b8c2]">
                Все системы работают на стороне сервера Roblox Studio через PhysicsService,
                OverlapParams и CollectionService без фейковых заглушек и без клиентского доверия.
              </p>
            </div>

            {/* Collision Matrix Table */}
            <section className="overflow-hidden rounded-xl border border-[#222c33] bg-[#141b1f]">
              <div className="border-b border-[#222c33] px-5 py-3.5">
                <h2 className="font-display text-base font-bold text-white">
                  Матрица коллизий (PhysicsService / PhysicsAndCollisionSetup.luau)
                </h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[#222c33] bg-[#11171a] text-xs font-semibold text-[#8fa3ae]">
                    <tr>
                      <th className="px-5 py-3">Группа A</th>
                      <th className="px-5 py-3">Группа B</th>
                      <th className="px-5 py-3">Состояние</th>
                      <th className="px-5 py-3">Игровое назначение</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1f282e]">
                    {COLLISION_MATRIX.map((row, idx) => (
                      <tr key={idx} className="hover:bg-[#182126]">
                        <td className="px-5 py-3 font-mono text-xs font-semibold text-white">
                          {row.groupA}
                        </td>
                        <td className="px-5 py-3 font-mono text-xs font-semibold text-[#38bdf8]">
                          {row.groupB}
                        </td>
                        <td className="px-5 py-3 text-xs font-semibold">
                          <span className={row.collides ? 'text-[#22c55e]' : 'text-[#f59e0b]'}>
                            {row.collides ? 'Столкновение (true)' : 'Проходит сквозь (false)'}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-xs text-[#b5c4cc]">{row.purpose}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Core Mechanics Grid (Flat 1px border, no nested card sandwiches) */}
            <section className="grid gap-5 md:grid-cols-2">
              <div className="min-w-0 rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
                <h3 className="font-display text-base font-bold text-white">
                  01. Физическая рубка деревьев и подбор сфер (Touched)
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-[#a8bac4]">
                  При достижении 0 HP сервер снимает <code className="font-mono text-xs text-[#38bdf8]">Anchored = false</code> у
                  модели дерева и применяет направленный импульс <code className="font-mono text-xs text-[#38bdf8]">ApplyImpulse</code>.
                  Ствол физически падает на рельеф или постройки с реальной коллизией, после чего распадается на физические сферы лута (<code className="font-mono text-xs text-[#38bdf8]">LootPickups</code>).
                </p>
              </div>

              <div className="min-w-0 rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
                <h3 className="font-display text-base font-bold text-white">
                  02. Строительство по сетке 4×4×4 с OverlapParams
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-[#a8bac4]">
                  Перед установкой стены, грядки или Алтаря семян сервер вызывает{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">workspace:GetPartBoundsInBox</code>.
                  Постройка отклоняется, если пересекает коллизию игрока, ствола дерева или существующего блока базы.
                </p>
              </div>

              <div className="min-w-0 rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
                <h3 className="font-display text-base font-bold text-white">
                  03. Токсичность редких биомов и купол теплицы
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-[#a8bac4]">
                  Туманные и кристальные биомы (уровень токсичности 2–3) наносят урон спорами каждые 2 секунды.
                  Для выживания игроки строят <strong>Алтарь семян</strong> (защитный купол радиусом 22 studs) или используют хлорофилловые фильтры.
                </p>
              </div>

              <div className="min-w-0 rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-display text-base font-bold text-white">
                    04. Полнотельная анимация (15 суставов) и частицы
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedScriptId('procedural_animator');
                      setActiveTab('scripts');
                    }}
                    className="whitespace-nowrap rounded-md border border-[#2c3a43] bg-[#1a2429] px-2.5 py-1 text-[11px] font-semibold text-[#38bdf8] hover:bg-[#223037]"
                  >
                    ProceduralAnimator.luau
                  </button>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-[#a8bac4]">
                  Движение каждого элемента тела R15/R6 (<code className="font-mono text-xs text-[#38bdf8]">Root</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">Waist</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">Neck</code>, плечи, локти, кисти, бёдра, колени, стопы)
                  плюс <code className="font-mono text-xs text-[#38bdf8]">ParticleEmitter</code> пыли шагов, шлейфа спринта, ударов по флоре и урона.
                </p>
              </div>

              <div className="min-w-0 rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-display text-base font-bold text-white">
                    05. Серверный анти-чит: Teleport/Fly/Speed, Magnitude и DataStore-аудит
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedScriptId('anti_cheat_engine');
                      setActiveTab('scripts');
                    }}
                    className="whitespace-nowrap rounded-md border border-[#2c3a43] bg-[#1a2429] px-2.5 py-1 text-[11px] font-semibold text-[#22c55e] hover:bg-[#223037]"
                  >
                    AntiCheatEngine.luau
                  </button>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-[#a8bac4]">
                  <code className="break-all font-mono text-xs text-[#38bdf8]">ServerScriptService/BotaniaServer/AntiCheatEngine.luau</code>{' '}
                  отслеживает скорость перемещения, телепорты (<code className="font-mono text-xs text-[#38bdf8]">SafeCFrame</code> откат),
                  полёт через нисходящий <code className="font-mono text-xs text-[#38bdf8]">workspace:Raycast</code> и удаляет несанкционированные{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">BodyVelocity, LinearVelocity, AlignPosition</code>. Все действия сбора (≤18 studs),
                  стройки (≤22 studs), подбора лута (≤14 studs) и крафта (≤24 studs у Алтаря) проверяются по{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">Magnitude</code>, а перед каждой записью в{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">DataStoreService</code> профиль проходит санитизацию против дюпа и подмены валюты.
                </p>
              </div>

              <div className="min-w-0 rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-display text-base font-bold text-white">
                    06. Процедурные квесты биомов и награда Флоринами
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedScriptId('quest_system');
                      setActiveTab('scripts');
                    }}
                    className="whitespace-nowrap rounded-md border border-[#2c3a43] bg-[#1a2429] px-2.5 py-1 text-[11px] font-semibold text-[#eab308] hover:bg-[#223037]"
                  >
                    QuestSystem.luau
                  </button>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-[#a8bac4]">
                  <code className="break-all font-mono text-xs text-[#38bdf8]">ServerScriptService/BotaniaServer/QuestSystem.luau</code>{' '}
                  автоматически генерирует задания при входе игрока в биом (сбор уникальных кристаллов/ресурсов,
                  постройка форпоста в токсичных биомах 2–3 уровня, вырубка флоры или культивация семян),
                  отслеживает прогресс через серверные хуки и безопасно начисляет <strong>Флорины</strong> и XP через{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">AntiCheatEngine.AuthorizeFlorinGrant</code>.
                </p>
              </div>
            </section>

            {/* Cross-Pollination Table */}
            <section className="overflow-hidden rounded-xl border border-[#222c33] bg-[#141b1f]">
              <div className="border-b border-[#222c33] px-5 py-3.5">
                <h2 className="font-display text-base font-bold text-white">
                  Культивация и скрещивание семян на соседних грядках (радиус 6.5 studs)
                </h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[#222c33] bg-[#11171a] text-xs font-semibold text-[#8fa3ae]">
                    <tr>
                      <th className="px-5 py-3">Семя A</th>
                      <th className="px-5 py-3">Семя B</th>
                      <th className="px-5 py-3">Гибридный результат</th>
                      <th className="px-5 py-3">Рост</th>
                      <th className="px-5 py-3">Применение</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1f282e]">
                    {CROSSBREED_PAIRS.map((row) => (
                      <tr key={row.result} className="hover:bg-[#182126]">
                        <td className="px-5 py-3 text-xs text-[#d6e0e6]">{row.seedA}</td>
                        <td className="px-5 py-3 text-xs text-[#d6e0e6]">{row.seedB}</td>
                        <td className="px-5 py-3 text-xs font-bold text-[#22c55e]">{row.result}</td>
                        <td className="px-5 py-3 font-mono text-xs tabular-nums text-[#cbd5dc]">
                          {row.time}
                        </td>
                        <td className="px-5 py-3 text-xs text-[#9fb0ba]">{row.effect}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* 05. Teleport Loading Screen Component Structure */}
            <section className="rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#222c33] pb-4">
                <div>
                  <h2 className="font-display text-lg font-bold text-white">
                    05. Компонент динамического загрузочного экрана (Мир ↔ Лобби)
                  </h2>
                  <p className="mt-1 max-w-3xl text-xs text-[#9fb0ba]">
                    Модульная структура <code className="font-mono text-[#38bdf8]">TeleportLoadingScreen.luau</code>{' '}
                    передаёт советы по выживанию для активных 8 биомов через{' '}
                    <code className="font-mono text-[#38bdf8]">TeleportService:SetTeleportGui</code> и{' '}
                    <code className="font-mono text-[#38bdf8]">ContentProvider:PreloadAsync</code>.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedScriptId('teleport_loading_screen');
                    setActiveTab('scripts');
                  }}
                  className="flex items-center gap-2 whitespace-nowrap shrink-0 rounded-lg border border-[#2c3a43] bg-[#1a2429] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#223037]"
                >
                  <Code2 className="h-4 w-4 text-[#22c55e]" />
                  <span>Открыть TeleportLoadingScreen.luau</span>
                </button>
              </div>

              <div className="mt-5 grid gap-6 lg:grid-cols-12">
                {/* Roblox ScreenGui Hierarchy & Lifecycle */}
                <div className="min-w-0 space-y-4 lg:col-span-5">
                  <div className="rounded-lg border border-[#222c33] bg-[#0c1114] p-4">
                    <div className="text-xs font-semibold text-[#8fa3ae]">
                      Иерархия ScreenGui в Roblox Studio
                    </div>
                    <pre className="studio-scroll mt-2.5 overflow-x-auto font-mono text-xs leading-relaxed text-[#d7e5dd]">
{`BotaniaTeleportScreen (ScreenGui · DisplayOrder 120)
 └─ Backdrop (Frame + UIGradient под цвет биома)
     ├─ TopRouteHeader (RouteBadge + SquadMeta 1..4)
     ├─ SurvivalTipCard (UICorner + UIStroke + UISizeConstraint)
     │   ├─ BiomeAccentBar
     │   ├─ BiomeNameLabel + ToxicityMeter (0..3)
     │   ├─ SurvivalTipHeadline + SurvivalTipBody
     │   └─ RecommendedGearLabel + NextTipButton
     └─ BottomProgressSection
         ├─ SpinnerRing (RenderStepped rotation)
         ├─ StageStatusLabel (DataStore / Biomes / Physics)
         └─ ProgressBarTrack -> ProgressBarFill (TweenService)`}
                    </pre>
                  </div>

                  <div className="rounded-lg border border-[#222c33] bg-[#0c1114] p-4 text-xs leading-relaxed text-[#9fb0ba]">
                    <div className="font-semibold text-white">Жизненный цикл компонента</div>
                    <ul className="mt-2 space-y-1.5">
                      <li>
                        <code className="font-mono text-[#38bdf8]">SetDestination(dir, payload)</code> — красит градиент и фильтрует советы по активным биомам сервера.
                      </li>
                      <li>
                        <code className="font-mono text-[#38bdf8]">Show(payload)</code> — вызывает{' '}
                        <code className="font-mono text-[#38bdf8]">TeleportService:SetTeleportGui</code> и запускает ротацию советов каждые 3.5 с.
                      </li>
                      <li>
                        <code className="font-mono text-[#38bdf8]">PreloadAssets(instances)</code> — обновляет шкалу прогресса через{' '}
                        <code className="font-mono text-[#38bdf8]">ContentProvider:PreloadAsync</code> после прибытия.
                      </li>
                      <li>
                        <code className="font-mono text-[#38bdf8]">Hide() / Destroy()</code> — ждёт{' '}
                        <code className="font-mono text-[#38bdf8]">game:IsLoaded()</code> и отключает соединения без утечек памяти.
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Interactive World <-> Lobby Tip Preview */}
                <div className="flex min-w-0 flex-col justify-between rounded-xl border border-[#222c33] bg-[#0c1114] p-5 lg:col-span-7">
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-1 rounded-lg bg-[#141b1f] p-1 text-xs">
                        <button
                          type="button"
                          onClick={() => {
                            setTeleportDir('ToWorld');
                            setTipCycleIdx(0);
                          }}
                          className={`whitespace-nowrap rounded-md px-3 py-1.5 font-semibold transition-colors ${
                            teleportDir === 'ToWorld'
                              ? 'bg-[#22c55e] text-[#07160c]'
                              : 'text-[#9fb0ba] hover:text-white'
                          }`}
                        >
                          Лобби → Мир
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setTeleportDir('ToLobby');
                            setTipCycleIdx(0);
                          }}
                          className={`whitespace-nowrap rounded-md px-3 py-1.5 font-semibold transition-colors ${
                            teleportDir === 'ToLobby'
                              ? 'bg-[#38bdf8] text-[#07131a]'
                              : 'text-[#9fb0ba] hover:text-white'
                          }`}
                        >
                          Мир → Лобби
                        </button>
                      </div>

                      <div className="font-mono text-xs tabular-nums text-[#8fa3ae]">
                        {teleportDir === 'ToWorld'
                          ? `Отряд: 4/4 · Сид #${seedInput}`
                          : 'Отряд: 4/4 · Сохранение в DataStore'}
                      </div>
                    </div>

                    {activeTeleportTip && (
                      <div
                        className="mt-5 rounded-xl border bg-[#141b1f] p-5"
                        style={{ borderColor: activeTeleportTip.accentColor }}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span
                            className="text-xs font-bold"
                            style={{ color: activeTeleportTip.accentColor }}
                          >
                            {activeTeleportTip.biomeName}
                          </span>
                          <span
                            className={`font-mono text-xs font-semibold tabular-nums ${
                              activeTeleportTip.toxicity === 0
                                ? 'text-[#22c55e]'
                                : activeTeleportTip.toxicity <= 2
                                  ? 'text-[#f59e0b]'
                                  : 'text-[#ef4444]'
                            }`}
                          >
                            {activeTeleportTip.toxicity === 0
                              ? 'Токсичность: 0/3 · Безопасно'
                              : activeTeleportTip.toxicity <= 2
                                ? `Токсичность: ${activeTeleportTip.toxicity}/3 · Споры`
                                : 'Токсичность: 3/3 · Опасно!'}
                          </span>
                        </div>

                        <h3 className="mt-2 font-display text-lg font-bold text-white">
                          {activeTeleportTip.headline}
                        </h3>
                        <p className="mt-2 text-sm leading-relaxed text-[#b5c4cc]">
                          {activeTeleportTip.tip}
                        </p>

                        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#222c33] pt-3">
                          <span className="text-xs text-[#8fa3ae]">
                            <span className="font-semibold text-[#d7e5dd]">Рекомендация:</span>{' '}
                            {activeTeleportTip.recommendedGear}
                          </span>
                          <button
                            type="button"
                            onClick={() => setTipCycleIdx((n) => n + 1)}
                            className="whitespace-nowrap rounded-lg border border-[#2c3a43] bg-[#1a2429] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#223037]"
                          >
                            Следующий совет ({(tipCycleIdx % teleportTips.length) + 1}/
                            {teleportTips.length})
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-5">
                    <div className="flex items-center justify-between text-xs text-[#9fb0ba]">
                      <span>
                        {teleportDir === 'ToWorld'
                          ? 'Генерация воксельного рельефа, флоры и фауны...'
                          : 'Сохранение инвентаря и подключение к комнате отряда...'}
                      </span>
                      <span className="font-mono tabular-nums text-[#22c55e]">78%</span>
                    </div>
                    <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-[#1a2429]">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: '78%',
                          backgroundColor:
                            teleportDir === 'ToWorld' ? '#22c55e' : '#38bdf8',
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}

        {activeTab === 'biomes' && (
          <div className="space-y-6">
            {/* Deterministic 8-of-30 Server Seed Simulator */}
            <section className="rounded-xl border border-[#222c33] bg-[#141b1f] p-5">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h1 className="font-display text-xl font-bold text-white">
                    Симулятор выбора 8 биомов сервера (из 30)
                  </h1>
                  <p className="mt-1 text-xs text-[#9fb0ba]">
                    Повторяет логику <code className="font-mono text-[#38bdf8]">BiomeRegistry.SelectServerBiomes(seed, 8)</code> для заданного сида сервера
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <label htmlFor="seed-input" className="text-xs font-semibold text-[#9fb0ba]">
                    Сид:
                  </label>
                  <input
                    id="seed-input"
                    type="number"
                    value={seedInput}
                    onChange={(e) => setSeedInput(Number(e.target.value) || 1)}
                    className="w-28 rounded-lg border border-[#28353d] bg-[#0f1417] px-3 py-1.5 font-mono text-xs tabular-nums text-white focus:border-[#22c55e] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setSeedInput(Math.floor(10000 + Math.random() * 89999))}
                    className="flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#2c3a43] bg-[#1a2429] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#223037]"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    <span>Случайный сид</span>
                  </button>
                </div>
              </div>

              <div className="mt-4 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-4">
                {spawned8Biomes.map((b, idx) => (
                  <div
                    key={b.id}
                    className="flex items-center justify-between rounded-lg border border-[#222c33] bg-[#0f1417] px-3.5 py-2.5"
                  >
                    <div className="flex min-w-0 items-center gap-2.5">
                      <span
                        className="h-3.5 w-3.5 shrink-0 rounded-sm"
                        style={{ backgroundColor: b.groundColor }}
                      />
                      <div className="min-w-0">
                        <div className="truncate text-xs font-bold text-white">
                          {idx === 0 ? `${b.name} (Спавн)` : b.name}
                        </div>
                        <div className="truncate text-[11px] text-[#8fa3ae]">
                          {b.uniqueResourceName}
                        </div>
                      </div>
                    </div>
                    <span className="shrink-0 font-mono text-[11px] tabular-nums text-[#7c909b]">
                      Т:{getBiomeToxicity(b)}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* Complete 30 Biomes Registry Table */}
            <section className="overflow-hidden rounded-xl border border-[#222c33] bg-[#141b1f]">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#222c33] px-5 py-4">
                <h2 className="font-display text-base font-bold text-white">
                  Полный каталог 30 биомов ({filteredBiomes.length})
                </h2>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-1 rounded-lg bg-[#0f1417] p-1 text-xs">
                    {(
                      [
                        { id: 'all', label: 'Все' },
                        { id: 'safe', label: 'Безопасные (0)' },
                        { id: 'mid', label: 'Споры (1–2)' },
                        { id: 'high', label: 'Опасные (3)' },
                      ] as const
                    ).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setToxicityFilter(f.id)}
                        className={`whitespace-nowrap rounded-md px-2.5 py-1 font-medium transition-colors ${
                          toxicityFilter === f.id
                            ? 'bg-[#223037] text-white'
                            : 'text-[#8a9ca6] hover:text-white'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>

                  <div className="relative">
                    <Search className="pointer-events-none absolute top-2 left-2.5 h-3.5 w-3.5 text-[#738793]" />
                    <input
                      type="text"
                      value={biomeSearch}
                      onChange={(e) => setBiomeSearch(e.target.value)}
                      placeholder="Фильтр биомов..."
                      aria-label="Фильтр биомов"
                      className="w-44 rounded-lg border border-[#28353d] bg-[#0f1417] py-1.5 pr-3 pl-8 text-xs text-white placeholder-[#6b7e89] focus:border-[#22c55e] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[#222c33] bg-[#11171a] text-xs font-semibold text-[#8fa3ae]">
                    <tr>
                      <th className="px-4 py-3">#</th>
                      <th className="px-4 py-3">Биом</th>
                      <th className="px-4 py-3">Флора</th>
                      <th className="px-4 py-3">Уникальный ресурс</th>
                      <th className="px-4 py-3">Фауна</th>
                      <th className="px-4 py-3 text-right">Токсичность</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1f282e]">
                    {filteredBiomes.map((b) => {
                      const tox = getBiomeToxicity(b);
                      return (
                        <tr key={b.id} className="hover:bg-[#182126]">
                          <td className="px-4 py-2.5 font-mono text-xs tabular-nums text-[#7c909b]">
                            {String(b.index).padStart(2, '0')}
                          </td>
                          <td className="px-4 py-2.5">
                            <div className="flex items-center gap-2.5">
                              <span
                                className="h-3.5 w-3.5 shrink-0 rounded-sm"
                                style={{ backgroundColor: b.groundColor }}
                              />
                              <span className="text-xs font-bold text-white">{b.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-2.5 text-xs text-[#b5c4cc]">
                            {ARCHETYPE_LABELS[b.floraType] ?? b.floraType}
                          </td>
                          <td className="px-4 py-2.5 text-xs font-medium text-[#d7e5dd]">
                            {b.uniqueResourceName}
                          </td>
                          <td className="px-4 py-2.5 text-xs text-[#9fb0ba]">{b.faunaName}</td>
                          <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums">
                            <span
                              className={
                                tox === 0
                                  ? 'text-[#22c55e]'
                                  : tox <= 2
                                    ? 'text-[#f59e0b]'
                                    : 'text-[#ef4444]'
                              }
                            >
                              {tox === 0 ? '0 · Безопасно' : `${tox} · Споры`}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        )}

        {activeTab === 'guide' && (
          <div className="max-w-4xl space-y-6">
            <div>
              <h1 className="font-display text-2xl font-bold text-white">
                Интеграция проекта Botania в Roblox Studio
              </h1>
              <p className="mt-1.5 text-sm text-[#a6b8c2]">
                Проект подготовлен в формате XML-плейса <code className="font-mono text-[#38bdf8]">Botania.rbxlx</code> со всеми настроенными сервисами, папками, RemoteEvent и скриптами.
              </p>
            </div>

            <div className="divide-y divide-[#222c33] rounded-xl border border-[#222c33] bg-[#141b1f]">
              <div className="p-5">
                <h2 className="font-display text-base font-bold text-white">
                  01. Импорт готового плейса Botania.rbxlx
                </h2>
                <p className="mt-1.5 text-sm leading-relaxed text-[#a8bac4]">
                  Нажмите кнопку <strong>Скачать Botania.rbxlx</strong> в верхней панели, затем откройте файл в Roblox Studio через{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">File → Open from File...</code>.
                  Иерархия <code className="font-mono text-xs text-[#38bdf8]">Workspace</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">Lighting</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">ReplicatedStorage/BotaniaShared</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">ReplicatedStorage/Remotes</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">ServerScriptService/BotaniaServer</code>,{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">StarterPlayerScripts</code> и{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">StarterGui/BotaniaHUD</code> создастся автоматически.
                </p>
              </div>

              <div className="p-5">
                <h2 className="font-display text-base font-bold text-white">
                  02. Включение DataStoreService и StreamingEnabled
                </h2>
                <p className="mt-1.5 text-sm leading-relaxed text-[#a8bac4]">
                  Для облачного сохранения профилей откройте{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">Home → Game Settings → Security</code> и включите{' '}
                  <strong>Enable Studio Access to API Services</strong>. В файле <code className="font-mono text-xs text-[#38bdf8]">Workspace</code> уже активирован{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">StreamingEnabled = true</code> для плавной работы на слабых телефонах.
                </p>
              </div>

              <div className="p-5">
                <h2 className="font-display text-base font-bold text-white">
                  03. Настройка доната Флоринов (Developer Products)
                </h2>
                <p className="mt-1.5 text-sm leading-relaxed text-[#a8bac4]">
                  Создайте 3 Developer Products в Creator Dashboard и впишите их числовые ID в таблицу{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">Config.DeveloperProducts</code> внутри{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">SkillAndQuestConfig.luau</code>. Серверный обработчик{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">MarketplaceService.ProcessReceipt</code> уже подключён и сохраняет покупки в DataStore.
                </p>
              </div>

              <div className="p-5">
                <h2 className="font-display text-base font-bold text-white">
                  04. Тест мобильного управления и картофельной графики
                </h2>
                <p className="mt-1.5 text-sm leading-relaxed text-[#a8bac4]">
                  Переключитесь в режим <strong>Test → Device Emulator</strong> (например, iPhone / Android) — кнопки «Рубить» и «Бег» появятся автоматически через{' '}
                  <code className="font-mono text-xs text-[#38bdf8]">ContextActionService</code>. Нажмите клавишу <strong>F8</strong> на ПК для мгновенного переключения картофельной графики.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
