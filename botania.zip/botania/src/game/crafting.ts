import { BOTANIA_BIOMES } from './biomes';

export type ItemCategory = 'tool' | 'resource' | 'consumable' | 'buildable' | 'biotech';

export interface ItemDef {
  id: string;
  name: string;
  category: ItemCategory;
  color: string;
  accentColor: string;
  description: string;
  maxStack: number;
  placeableType?: 'moss_wall' | 'glass_wall' | 'flower_lamp' | 'seed_altar';
}

export interface InventorySlot {
  itemId: string;
  count: number;
}

export type SlotArray = (InventorySlot | null)[];

export interface CraftingRecipe {
  id: string;
  outputItemId: string;
  outputCount: number;
  tier: 'Базовый' | 'Сложный' | 'Био-Тех';
  ingredients: { itemId: string; count: number }[];
  unlockedByDefault: boolean;
  requiredSkillId?: string;
}

export const ITEMS: Record<string, ItemDef> = {
  tool_botanic_axe: {
    id: 'tool_botanic_axe',
    name: 'Ботанический топор',
    category: 'tool',
    color: '#2ecc71',
    accentColor: '#d4af37',
    description: 'Рубит воксельные деревья и собирает сок биомов',
    maxStack: 1,
  },
  tool_jade_axe: {
    id: 'tool_jade_axe',
    name: 'Нефритовый секатор',
    category: 'tool',
    color: '#00d2d3',
    accentColor: '#ffeaa7',
    description: 'Ускоряет добычу редкой флоры на 50%',
    maxStack: 1,
  },
  res_wood: {
    id: 'res_wood',
    name: 'Живая древесина',
    category: 'resource',
    color: '#8d5b32',
    accentColor: '#c48f5a',
    description: 'Базовый строительный ресурс из стволов деревьев',
    maxStack: 64,
  },
  res_fiber: {
    id: 'res_fiber',
    name: 'Ростовое волокно',
    category: 'resource',
    color: '#58b947',
    accentColor: '#a3cb38',
    description: 'Эластичные стебли для крафта инструментов и верёвок',
    maxStack: 64,
  },
  res_stone: {
    id: 'res_stone',
    name: 'Мшистый камень',
    category: 'resource',
    color: '#7f8fa6',
    accentColor: '#4cd137',
    description: 'Прочный воксельный камень с вкраплениями мха',
    maxStack: 64,
  },
  bld_moss_wall: {
    id: 'bld_moss_wall',
    name: 'Блок мшистого дуба',
    category: 'buildable',
    color: '#6ab04c',
    accentColor: '#7a5230',
    description: 'Устанавливается в мире как воксельная стена базы',
    maxStack: 32,
    placeableType: 'moss_wall',
  },
  bld_glass_wall: {
    id: 'bld_glass_wall',
    name: 'Стекло теплицы',
    category: 'buildable',
    color: '#70e8ff',
    accentColor: '#ffffff',
    description: 'Прозрачный блок для купола ботанической базы',
    maxStack: 32,
    placeableType: 'glass_wall',
  },
  bld_flower_lamp: {
    id: 'bld_flower_lamp',
    name: 'Цветочный фонарь',
    category: 'buildable',
    color: '#ffd32a',
    accentColor: '#ff9f43',
    description: 'Освещает базу и отпугивает ночную мглу',
    maxStack: 16,
    placeableType: 'flower_lamp',
  },
  bld_seed_altar: {
    id: 'bld_seed_altar',
    name: 'Алтарь семян',
    category: 'buildable',
    color: '#c56cf0',
    accentColor: '#00f5d4',
    description: 'Сложная постройка: генерирует +15 XP и метку на миникарте',
    maxStack: 4,
    placeableType: 'seed_altar',
  },
  con_chlorophyll_potion: {
    id: 'con_chlorophyll_potion',
    name: 'Эликсир хлорофилла',
    category: 'consumable',
    color: '#1dd1a1',
    accentColor: '#ffffff',
    description: 'Восстанавливает 40 здоровья и 50 выносливости',
    maxStack: 16,
  },
  bio_spore_analyzer: {
    id: 'bio_spore_analyzer',
    name: 'Анализатор спор',
    category: 'biotech',
    color: '#0fbcf9',
    accentColor: '#ffd32a',
    description: 'Сложный прибор для изучения мутаций в 30 биомах',
    maxStack: 4,
  },
};

// Dynamically register all 30 unique biome resources into ITEMS
for (const biome of BOTANIA_BIOMES) {
  ITEMS[biome.uniqueResourceId] = {
    id: biome.uniqueResourceId,
    name: biome.uniqueResourceName,
    category: 'resource',
    color: biome.floraColor,
    accentColor: biome.accentColor,
    description: `Уникальный ресурс биома «${biome.name}»`,
    maxStack: 64,
  };
}

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  {
    id: 'craft_moss_wall',
    outputItemId: 'bld_moss_wall',
    outputCount: 2,
    tier: 'Базовый',
    ingredients: [
      { itemId: 'res_wood', count: 2 },
      { itemId: 'res_fiber', count: 1 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'craft_flower_lamp',
    outputItemId: 'bld_flower_lamp',
    outputCount: 1,
    tier: 'Базовый',
    ingredients: [
      { itemId: 'res_wood', count: 2 },
      { itemId: 'res_emerald_sap', count: 1 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'craft_chlorophyll',
    outputItemId: 'con_chlorophyll_potion',
    outputCount: 1,
    tier: 'Базовый',
    ingredients: [
      { itemId: 'res_fiber', count: 3 },
      { itemId: 'res_emerald_sap', count: 1 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'craft_glass_wall',
    outputItemId: 'bld_glass_wall',
    outputCount: 2,
    tier: 'Сложный',
    ingredients: [
      { itemId: 'res_stone', count: 2 },
      { itemId: 'res_emerald_sap', count: 2 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'craft_jade_axe',
    outputItemId: 'tool_jade_axe',
    outputCount: 1,
    tier: 'Сложный',
    ingredients: [
      { itemId: 'res_wood', count: 4 },
      { itemId: 'res_stone', count: 3 },
      { itemId: 'res_emerald_sap', count: 2 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'craft_seed_altar',
    outputItemId: 'bld_seed_altar',
    outputCount: 1,
    tier: 'Био-Тех',
    ingredients: [
      { itemId: 'res_stone', count: 4 },
      { itemId: 'res_wood', count: 4 },
      { itemId: 'res_emerald_sap', count: 3 },
    ],
    unlockedByDefault: false,
    requiredSkillId: 'arch_blueprint',
  },
  {
    id: 'craft_spore_analyzer',
    outputItemId: 'bio_spore_analyzer',
    outputCount: 1,
    tier: 'Био-Тех',
    ingredients: [
      { itemId: 'res_stone', count: 3 },
      { itemId: 'res_fiber', count: 4 },
      { itemId: 'res_emerald_sap', count: 3 },
    ],
    unlockedByDefault: false,
    requiredSkillId: 'bot_spores',
  },
];

export interface InventoryState {
  hotbar: SlotArray; // 6 slots
  backpack: SlotArray; // 18 slots
}

export function createInitialInventory(): InventoryState {
  const hotbar: SlotArray = [
    { itemId: 'tool_botanic_axe', count: 1 },
    { itemId: 'bld_moss_wall', count: 4 },
    { itemId: 'bld_glass_wall', count: 2 },
    { itemId: 'bld_flower_lamp', count: 2 },
    { itemId: 'con_chlorophyll_potion', count: 2 },
    null,
  ];
  const backpack: SlotArray = Array(18).fill(null);
  backpack[0] = { itemId: 'res_wood', count: 6 };
  backpack[1] = { itemId: 'res_fiber', count: 5 };
  backpack[2] = { itemId: 'res_stone', count: 4 };
  backpack[3] = { itemId: 'res_emerald_sap', count: 2 };
  return { hotbar, backpack };
}

export function countItem(inv: InventoryState, itemId: string): number {
  let total = 0;
  for (const slot of inv.hotbar) {
    if (slot && slot.itemId === itemId) total += slot.count;
  }
  for (const slot of inv.backpack) {
    if (slot && slot.itemId === itemId) total += slot.count;
  }
  return total;
}

export function addItemToInventory(
  inv: InventoryState,
  itemId: string,
  amount: number
): InventoryState {
  const item = ITEMS[itemId];
  if (!item || amount <= 0) return inv;

  const hotbar = inv.hotbar.map((s) => (s ? { ...s } : null));
  const backpack = inv.backpack.map((s) => (s ? { ...s } : null));
  let remaining = amount;

  const tryFillExisting = (arr: SlotArray) => {
    for (let i = 0; i < arr.length && remaining > 0; i++) {
      const slot = arr[i];
      if (slot && slot.itemId === itemId && slot.count < item.maxStack) {
        const add = Math.min(remaining, item.maxStack - slot.count);
        slot.count += add;
        remaining -= add;
      }
    }
  };

  const tryFillEmpty = (arr: SlotArray) => {
    for (let i = 0; i < arr.length && remaining > 0; i++) {
      if (!arr[i]) {
        const add = Math.min(remaining, item.maxStack);
        arr[i] = { itemId, count: add };
        remaining -= add;
      }
    }
  };

  tryFillExisting(hotbar);
  tryFillExisting(backpack);
  tryFillEmpty(hotbar);
  tryFillEmpty(backpack);

  return { hotbar, backpack };
}

export function consumeItemFromInventory(
  inv: InventoryState,
  itemId: string,
  amount: number
): InventoryState | null {
  if (countItem(inv, itemId) < amount) return null;
  const hotbar = inv.hotbar.map((s) => (s ? { ...s } : null));
  const backpack = inv.backpack.map((s) => (s ? { ...s } : null));
  let remaining = amount;

  const drain = (arr: SlotArray) => {
    for (let i = 0; i < arr.length && remaining > 0; i++) {
      const slot = arr[i];
      if (slot && slot.itemId === itemId) {
        const take = Math.min(remaining, slot.count);
        slot.count -= take;
        remaining -= take;
        if (slot.count <= 0) arr[i] = null;
      }
    }
  };

  drain(backpack);
  drain(hotbar);

  return { hotbar, backpack };
}

export interface SlotRef {
  section: 'hotbar' | 'backpack';
  index: number;
}

/**
 * Handles intuitive drag-and-drop between hotbar and backpack slots,
 * stacking matching items up to maxStack or swapping different items.
 */
export function moveOrSwapSlot(
  inv: InventoryState,
  from: SlotRef,
  to: SlotRef
): InventoryState {
  if (from.section === to.section && from.index === to.index) return inv;

  const hotbar = inv.hotbar.map((s) => (s ? { ...s } : null));
  const backpack = inv.backpack.map((s) => (s ? { ...s } : null));

  const getArr = (sec: 'hotbar' | 'backpack') => (sec === 'hotbar' ? hotbar : backpack);
  const fromArr = getArr(from.section);
  const toArr = getArr(to.section);

  if (
    from.index < 0 ||
    from.index >= fromArr.length ||
    to.index < 0 ||
    to.index >= toArr.length
  ) {
    return inv;
  }

  const source = fromArr[from.index];
  const target = toArr[to.index];
  if (!source) return inv;

  if (target && target.itemId === source.itemId) {
    const maxStack = ITEMS[source.itemId]?.maxStack ?? 64;
    if (target.count < maxStack) {
      const space = maxStack - target.count;
      const moveCount = Math.min(space, source.count);
      target.count += moveCount;
      source.count -= moveCount;
      if (source.count <= 0) {
        fromArr[from.index] = null;
      }
      return { hotbar, backpack };
    }
  }

  // Swap
  fromArr[from.index] = target;
  toArr[to.index] = source;
  return { hotbar, backpack };
}

export function canCraftRecipe(
  inv: InventoryState,
  recipe: CraftingRecipe,
  unlockedSkills: string[]
): boolean {
  if (!recipe.unlockedByDefault && recipe.requiredSkillId) {
    if (!unlockedSkills.includes(recipe.requiredSkillId)) {
      return false;
    }
  }
  return recipe.ingredients.every((ing) => countItem(inv, ing.itemId) >= ing.count);
}

export function craftRecipe(
  inv: InventoryState,
  recipeId: string,
  unlockedSkills: string[],
  costDiscountMultiplier = 1
): InventoryState | null {
  const recipe = CRAFTING_RECIPES.find((r) => r.id === recipeId);
  if (!recipe) return null;
  if (!recipe.unlockedByDefault && recipe.requiredSkillId) {
    if (!unlockedSkills.includes(recipe.requiredSkillId)) {
      return null;
    }
  }

  let next = inv;
  for (const ing of recipe.ingredients) {
    const requiredCount = Math.max(1, Math.floor(ing.count * costDiscountMultiplier));
    const consumed = consumeItemFromInventory(next, ing.itemId, requiredCount);
    if (!consumed) return null;
    next = consumed;
  }

  return addItemToInventory(next, recipe.outputItemId, recipe.outputCount);
}
