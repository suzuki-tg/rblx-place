import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BOTANIA_BIOMES,
  selectServerBiomes,
  getBiomeAt,
  getBiomeToxicity,
  groundHeightAt,
  getDynamicDayNightState,
} from './biomes';
import {
  createInitialInventory,
  moveOrSwapSlot,
  craftRecipe,
  countItem,
  addItemToInventory,
} from './crafting';
import {
  canUnlockSkill,
  validatePlayerAction,
  calculateLevelFromXp,
  selectSurvivalTipsForTeleport,
} from './progression';

test('biomes catalog defines exactly 30 unique botanical biomes', () => {
  assert.equal(BOTANIA_BIOMES.length, 30);
  const ids = new Set(BOTANIA_BIOMES.map((b) => b.id));
  const resources = new Set(BOTANIA_BIOMES.map((b) => b.uniqueResourceId));
  assert.equal(ids.size, 30);
  assert.equal(resources.size, 30);
  assert.equal(getBiomeToxicity(BOTANIA_BIOMES[0]), 0);
  assert.equal(getBiomeToxicity(BOTANIA_BIOMES[5]), 3);
});

test('selectServerBiomes picks 8 unique biomes deterministically per seed', () => {
  const a1 = selectServerBiomes(4242, 8);
  const a2 = selectServerBiomes(4242, 8);
  const b1 = selectServerBiomes(9876, 8);

  assert.equal(a1.length, 8);
  assert.deepEqual(
    a1.map((b) => b.id),
    a2.map((b) => b.id)
  );
  assert.equal(new Set(a1.map((b) => b.id)).size, 8);
  assert.equal(a1[0].id, 'emerald_grove');
  assert.notDeepEqual(
    a1.map((b) => b.id),
    b1.map((b) => b.id)
  );
});

test('spawn clearing around origin is flat and in starter biome', () => {
  const worldBiomes = selectServerBiomes(1001, 8);
  assert.equal(groundHeightAt(0, 0), 0);
  assert.equal(groundHeightAt(5, -5), 0);
  assert.equal(getBiomeAt(0, 0, worldBiomes).id, 'emerald_grove');
});

test('day/night cycle transitions smoothly between day and night phases', () => {
  const noon = getDynamicDayNightState(0.25, 'clear');
  const night = getDynamicDayNightState(0.75, 'mist');
  assert.equal(noon.isNight, false);
  assert.equal(night.isNight, true);
  assert.ok(noon.sunIntensity > night.sunIntensity);
});

test('inventory drag-and-drop swaps and stacks matching items', () => {
  let inv = createInitialInventory();
  inv = moveOrSwapSlot(inv, { section: 'backpack', index: 0 }, { section: 'hotbar', index: 5 });
  assert.equal(inv.hotbar[5]?.itemId, 'res_wood');
  assert.equal(inv.hotbar[5]?.count, 6);
  assert.equal(inv.backpack[0], null);

  inv = addItemToInventory(inv, 'res_wood', 4);
  assert.equal(inv.hotbar[5]?.count, 10);
});

test('crafting consumes ingredients and produces output respecting skill gates', () => {
  const inv = createInitialInventory();
  const blocked = craftRecipe(inv, 'craft_seed_altar', []);
  assert.equal(blocked, null);

  const beforeWalls = countItem(inv, 'bld_moss_wall');
  const crafted = craftRecipe(inv, 'craft_moss_wall', []);
  assert.ok(crafted !== null);
  assert.equal(countItem(crafted, 'bld_moss_wall'), beforeWalls + 2);
  assert.equal(countItem(crafted, 'res_wood'), 4);
});

test('skill tree prerequisites and anti-cheat validator enforce rules', () => {
  assert.equal(canUnlockSkill('bot_spores', [], 5), false);
  assert.equal(canUnlockSkill('bot_harvest', [], 1), true);
  assert.equal(canUnlockSkill('bot_spores', ['bot_harvest'], 2), true);

  assert.equal(validatePlayerAction({ distanceMoved: 8, deltaSeconds: 1, maxSpeed: 9 }).valid, true);
  assert.equal(validatePlayerAction({ distanceMoved: 35, deltaSeconds: 1, maxSpeed: 9 }).valid, false);
  assert.equal(
    validatePlayerAction({ distanceMoved: 2, deltaSeconds: 1, maxSpeed: 9, interactDistance: 12 }).valid,
    false
  );
});

test('level calculation returns expected progression tiers', () => {
  const lv1 = calculateLevelFromXp(0);
  const lv2 = calculateLevelFromXp(120);
  assert.equal(lv1.level, 1);
  assert.equal(lv2.level, 2);
});

test('selectSurvivalTipsForTeleport prioritizes active biomes and supports lobby transitions', () => {
  const worldTips = selectSurvivalTipsForTeleport('ToWorld', ['crystal_greenhouse']);
  assert.ok(worldTips.length >= 4);
  assert.equal(worldTips[0].biomeId, 'crystal_greenhouse');

  const lobbyTips = selectSurvivalTipsForTeleport('ToLobby');
  assert.ok(lobbyTips.length >= 2);
  assert.ok(lobbyTips.every((t) => t.direction === 'ToLobby' || t.direction === 'Both'));
});
