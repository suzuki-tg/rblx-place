export type FloraArchetype =
  | 'oak'
  | 'sakura'
  | 'mushroom'
  | 'bamboo'
  | 'crystal'
  | 'cactus'
  | 'willow'
  | 'fern';

export type WeatherType = 'clear' | 'sunshower' | 'pollen' | 'mist';

export interface BiomeDef {
  id: string;
  index: number;
  name: string;
  groundColor: string;
  accentColor: string;
  floraColor: string;
  trunkColor: string;
  skyTint: string;
  floraType: FloraArchetype;
  faunaName: string;
  faunaColor: string;
  uniqueResourceId: string;
  uniqueResourceName: string;
  weatherBias: WeatherType;
}

export function getBiomeToxicity(biome: BiomeDef): 0 | 1 | 2 | 3 {
  if (biome.index <= 4) return 0;
  if (biome.weatherBias === 'mist') return 2;
  if (biome.floraType === 'crystal' || biome.floraType === 'cactus') return 3;
  if (biome.index % 3 === 0) return 1;
  return 0;
}

export const BOTANIA_BIOMES: BiomeDef[] = [
  {
    id: 'emerald_grove',
    index: 1,
    name: 'Изумрудная Роща',
    groundColor: '#58b947',
    accentColor: '#3a9630',
    floraColor: '#2ecc71',
    trunkColor: '#7a5230',
    skyTint: '#87d8ff',
    floraType: 'oak',
    faunaName: 'Лиственный светляк',
    faunaColor: '#d4ff66',
    uniqueResourceId: 'res_emerald_sap',
    uniqueResourceName: 'Изумрудный сок',
    weatherBias: 'clear',
  },
  {
    id: 'sakura_terraces',
    index: 2,
    name: 'Сакуровые Террасы',
    groundColor: '#88c96b',
    accentColor: '#f78fb3',
    floraColor: '#ff9ff3',
    trunkColor: '#634133',
    skyTint: '#ffd6e7',
    floraType: 'sakura',
    faunaName: 'Лепестковая бабочка',
    faunaColor: '#ff6b9d',
    uniqueResourceId: 'res_sakura_petal',
    uniqueResourceName: 'Эссенция сакуры',
    weatherBias: 'pollen',
  },
  {
    id: 'mycelium_canyon',
    index: 3,
    name: 'Грибной Каньон',
    groundColor: '#786fa6',
    accentColor: '#f8a5c2',
    floraColor: '#ff5252',
    trunkColor: '#f5f6fa',
    skyTint: '#c7ecee',
    floraType: 'mushroom',
    faunaName: 'Споровый жук',
    faunaColor: '#ffda79',
    uniqueResourceId: 'res_crimson_spore',
    uniqueResourceName: 'Алая спора',
    weatherBias: 'mist',
  },
  {
    id: 'lavender_plateau',
    index: 4,
    name: 'Лавандовое Плато',
    groundColor: '#9b82d4',
    accentColor: '#7858b8',
    floraColor: '#c56cf0',
    trunkColor: '#6c5ce7',
    skyTint: '#dfe4ff',
    floraType: 'fern',
    faunaName: 'Аметистовая пчела',
    faunaColor: '#ffeaa7',
    uniqueResourceId: 'res_lavender_oil',
    uniqueResourceName: 'Пыльца лаванды',
    weatherBias: 'pollen',
  },
  {
    id: 'bamboo_labyrinth',
    index: 5,
    name: 'Бамбуковый Лабиринт',
    groundColor: '#6ab04c',
    accentColor: '#badc58',
    floraColor: '#7bed9f',
    trunkColor: '#9acd32',
    skyTint: '#b8f2e6',
    floraType: 'bamboo',
    faunaName: 'Нефритовый богомол',
    faunaColor: '#2ed573',
    uniqueResourceId: 'res_jade_cane',
    uniqueResourceName: 'Нефритовый бамбук',
    weatherBias: 'sunshower',
  },
  {
    id: 'crystal_greenhouse',
    index: 6,
    name: 'Кристальная Теплица',
    groundColor: '#4bcffa',
    accentColor: '#0fbcf9',
    floraColor: '#70e8ff',
    trunkColor: '#34e7e4',
    skyTint: '#c7f9ff',
    floraType: 'crystal',
    faunaName: 'Призматический мотылёк',
    faunaColor: '#ffffff',
    uniqueResourceId: 'res_prism_shard',
    uniqueResourceName: 'Ростовой кристалл',
    weatherBias: 'clear',
  },
  {
    id: 'golden_savanna',
    index: 7,
    name: 'Золотая Саванна',
    groundColor: '#e1b12c',
    accentColor: '#fbc531',
    floraColor: '#78e08f',
    trunkColor: '#8c6239',
    skyTint: '#ffeaa7',
    floraType: 'oak',
    faunaName: 'Солнечный тушкан',
    faunaColor: '#ff9f43',
    uniqueResourceId: 'res_sun_resin',
    uniqueResourceName: 'Янтарная смола',
    weatherBias: 'clear',
  },
  {
    id: 'neon_fern_hollow',
    index: 8,
    name: 'Лощина Папоротника',
    groundColor: '#1e8449',
    accentColor: '#00d2d3',
    floraColor: '#1dd1a1',
    trunkColor: '#2f5d42',
    skyTint: '#a3f7bf',
    floraType: 'fern',
    faunaName: 'Люминесцентный тритон',
    faunaColor: '#00f5d4',
    uniqueResourceId: 'res_glow_frond',
    uniqueResourceName: 'Светящийся вайя',
    weatherBias: 'mist',
  },
  {
    id: 'succulent_dunes',
    index: 9,
    name: 'Дюны Суккулентов',
    groundColor: '#f3a683',
    accentColor: '#f7d794',
    floraColor: '#38ada9',
    trunkColor: '#218c74',
    skyTint: '#ffecd2',
    floraType: 'cactus',
    faunaName: 'Колючий хамелеон',
    faunaColor: '#78e08f',
    uniqueResourceId: 'res_agave_nectar',
    uniqueResourceName: 'Нектар агавы',
    weatherBias: 'clear',
  },
  {
    id: 'weeping_marsh',
    index: 10,
    name: 'Плакучие Топи',
    groundColor: '#40739e',
    accentColor: '#487eb0',
    floraColor: '#4cd137',
    trunkColor: '#4b4b4b',
    skyTint: '#b2bec3',
    floraType: 'willow',
    faunaName: 'Болотная стрекоза',
    faunaColor: '#00a8ff',
    uniqueResourceId: 'res_willow_bark',
    uniqueResourceName: 'Влагостойкая кора',
    weatherBias: 'sunshower',
  },
  {
    id: 'coral_meadow',
    index: 11,
    name: 'Коралловый Луг',
    groundColor: '#ff7979',
    accentColor: '#ffbe76',
    floraColor: '#ff6b81',
    trunkColor: '#f8a5c2',
    skyTint: '#ffcccc',
    floraType: 'mushroom',
    faunaName: 'Рифовый крабик',
    faunaColor: '#ff4757',
    uniqueResourceId: 'res_coral_bud',
    uniqueResourceName: 'Сухопутный коралл',
    weatherBias: 'pollen',
  },
  {
    id: 'cobalt_taiga',
    index: 12,
    name: 'Кобальтовая Тайга',
    groundColor: '#227093',
    accentColor: '#34ace0',
    floraColor: '#20bf6b',
    trunkColor: '#594236',
    skyTint: '#a5d8ff',
    floraType: 'oak',
    faunaName: 'Синяя сойка',
    faunaColor: '#45aaf2',
    uniqueResourceId: 'res_frost_needle',
    uniqueResourceName: 'Хвоя кобальта',
    weatherBias: 'mist',
  },
  {
    id: 'sunflower_valley',
    index: 13,
    name: 'Долина Подсолнухов',
    groundColor: '#7bed9f',
    accentColor: '#ffa502',
    floraColor: '#ffd32a',
    trunkColor: '#3b8c3b',
    skyTint: '#fff3b0',
    floraType: 'fern',
    faunaName: 'Медовый шмель',
    faunaColor: '#ffb142',
    uniqueResourceId: 'res_solar_seed',
    uniqueResourceName: 'Солнечное семя',
    weatherBias: 'clear',
  },
  {
    id: 'obsidian_orchard',
    index: 14,
    name: 'Обсидиановый Сад',
    groundColor: '#3d3d3d',
    accentColor: '#ff5e57',
    floraColor: '#ff3f34',
    trunkColor: '#1e272e',
    skyTint: '#ffd3b6',
    floraType: 'crystal',
    faunaName: 'Угольный светляк',
    faunaColor: '#ff5e57',
    uniqueResourceId: 'res_magma_fig',
    uniqueResourceName: 'Вулканический инжир',
    weatherBias: 'clear',
  },
  {
    id: 'mint_glacier',
    index: 15,
    name: 'Мятный Ледник',
    groundColor: '#81ecec',
    accentColor: '#55efc4',
    floraColor: '#00cec9',
    trunkColor: '#dfe6e9',
    skyTint: '#e0fbfc',
    floraType: 'crystal',
    faunaName: 'Ледяной заяц',
    faunaColor: '#ffffff',
    uniqueResourceId: 'res_mint_crystal',
    uniqueResourceName: 'Кристалл мяты',
    weatherBias: 'mist',
  },
  {
    id: 'amber_maple_ridge',
    index: 16,
    name: 'Янтарный Клён',
    groundColor: '#e67e22',
    accentColor: '#d35400',
    floraColor: '#ff7f50',
    trunkColor: '#6d4c3d',
    skyTint: '#ffe5b4',
    floraType: 'oak',
    faunaName: 'Огненная лисичка',
    faunaColor: '#ff6348',
    uniqueResourceId: 'res_maple_syrup',
    uniqueResourceName: 'Кленовый сироп',
    weatherBias: 'pollen',
  },
  {
    id: 'lotus_lagoon',
    index: 17,
    name: 'Лагуна Лотосов',
    groundColor: '#2bcbba',
    accentColor: '#fc5c65',
    floraColor: '#f78fb3',
    trunkColor: '#26de81',
    skyTint: '#c7ecee',
    floraType: 'willow',
    faunaName: 'Водяной журавль',
    faunaColor: '#fff5f5',
    uniqueResourceId: 'res_lotus_core',
    uniqueResourceName: 'Сердце лотоса',
    weatherBias: 'sunshower',
  },
  {
    id: 'velvet_moss_steppe',
    index: 18,
    name: 'Бархатная Степь',
    groundColor: '#44bd32',
    accentColor: '#8c7ae6',
    floraColor: '#a3cb38',
    trunkColor: '#7f8fa6',
    skyTint: '#dff9fb',
    floraType: 'fern',
    faunaName: 'Моховая черепаха',
    faunaColor: '#4cd137',
    uniqueResourceId: 'res_velvet_moss',
    uniqueResourceName: 'Бархатный мох',
    weatherBias: 'sunshower',
  },
  {
    id: 'citrus_atoll',
    index: 19,
    name: 'Цитрусовый Атолл',
    groundColor: '#f6e58d',
    accentColor: '#ffbe76',
    floraColor: '#6ab04c',
    trunkColor: '#a0694b',
    skyTint: '#b8e994',
    floraType: 'oak',
    faunaName: 'Лаймовый попугай',
    faunaColor: '#badc58',
    uniqueResourceId: 'res_yuzu_zest',
    uniqueResourceName: 'Золотой цитрус',
    weatherBias: 'clear',
  },
  {
    id: 'orchid_canopy',
    index: 20,
    name: 'Полог Орхидей',
    groundColor: '#be2edd',
    accentColor: '#e056fd',
    floraColor: '#ff9ff3',
    trunkColor: '#574b90',
    skyTint: '#f8c2ff',
    floraType: 'sakura',
    faunaName: 'Райский колибри',
    faunaColor: '#f368e0',
    uniqueResourceId: 'res_orchid_dew',
    uniqueResourceName: 'Роса орхидеи',
    weatherBias: 'pollen',
  },
  {
    id: 'basalt_bonsai',
    index: 21,
    name: 'Базальтовый Бонсай',
    groundColor: '#636e72',
    accentColor: '#00b894',
    floraColor: '#55efc4',
    trunkColor: '#2d3436',
    skyTint: '#dfe6e9',
    floraType: 'sakura',
    faunaName: 'Каменный карп',
    faunaColor: '#fab1a0',
    uniqueResourceId: 'res_bonsai_root',
    uniqueResourceName: 'Корень бонсай',
    weatherBias: 'mist',
  },
  {
    id: 'honeycomb_heath',
    index: 22,
    name: 'Медовый Вереск',
    groundColor: '#f7b731',
    accentColor: '#fa8231',
    floraColor: '#a55eea',
    trunkColor: '#8854d0',
    skyTint: '#fff2cc',
    floraType: 'fern',
    faunaName: 'Королевская пчела',
    faunaColor: '#fed330',
    uniqueResourceId: 'res_royal_pollen',
    uniqueResourceName: 'Королевский мёд',
    weatherBias: 'pollen',
  },
  {
    id: 'starlight_bog',
    index: 23,
    name: 'Звёздная Топь',
    groundColor: '#303952',
    accentColor: '#778beb',
    floraColor: '#786fa6',
    trunkColor: '#596275',
    skyTint: '#9980fa',
    floraType: 'mushroom',
    faunaName: 'Ночная сова',
    faunaColor: '#f5cd79',
    uniqueResourceId: 'res_star_lichen',
    uniqueResourceName: 'Звёздный лишайник',
    weatherBias: 'mist',
  },
  {
    id: 'peach_blossom_isle',
    index: 24,
    name: 'Персиковый Остров',
    groundColor: '#f8a5c2',
    accentColor: '#f3a683',
    floraColor: '#ffcccc',
    trunkColor: '#785a46',
    skyTint: '#ffeaa7',
    floraType: 'sakura',
    faunaName: 'Розовый фламинго',
    faunaColor: '#ff6b81',
    uniqueResourceId: 'res_peach_gum',
    uniqueResourceName: 'Персиковая камедь',
    weatherBias: 'clear',
  },
  {
    id: 'jade_terrarium',
    index: 25,
    name: 'Нефритовый Террариум',
    groundColor: '#10ac84',
    accentColor: '#1dd1a1',
    floraColor: '#00d2d3',
    trunkColor: '#222f3e',
    skyTint: '#c8f7dc',
    floraType: 'bamboo',
    faunaName: 'Изумрудный жук',
    faunaColor: '#54a0ff',
    uniqueResourceId: 'res_jade_leaf',
    uniqueResourceName: 'Лист нефрита',
    weatherBias: 'sunshower',
  },
  {
    id: 'cactus_monolith',
    index: 26,
    name: 'Монолит Кактусов',
    groundColor: '#e58e26',
    accentColor: '#fa983a',
    floraColor: '#079992',
    trunkColor: '#0a3d62',
    skyTint: '#ffd8a8',
    floraType: 'cactus',
    faunaName: 'Пустынный фенек',
    faunaColor: '#fad390',
    uniqueResourceId: 'res_spine_fruit',
    uniqueResourceName: 'Плод опунции',
    weatherBias: 'clear',
  },
  {
    id: 'bioluminescent_grove',
    index: 27,
    name: 'Биолюминесцентный Лес',
    groundColor: '#1e3799',
    accentColor: '#38ada9',
    floraColor: '#00f5d4',
    trunkColor: '#4a69bd',
    skyTint: '#7efff5',
    floraType: 'willow',
    faunaName: 'Неоновый олень',
    faunaColor: '#18dcff',
    uniqueResourceId: 'res_lumen_sap',
    uniqueResourceName: 'Люмен-капля',
    weatherBias: 'mist',
  },
  {
    id: 'crimson_reed_delta',
    index: 28,
    name: 'Алая Дельта',
    groundColor: '#b33939',
    accentColor: '#cd6133',
    floraColor: '#ff793f',
    trunkColor: '#84817a',
    skyTint: '#ffda79',
    floraType: 'bamboo',
    faunaName: 'Красный ибис',
    faunaColor: '#ff5252',
    uniqueResourceId: 'res_crimson_reed',
    uniqueResourceName: 'Багровый тростник',
    weatherBias: 'sunshower',
  },
  {
    id: 'clover_highlands',
    index: 29,
    name: 'Клеверные Холмы',
    groundColor: '#26de81',
    accentColor: '#20bf6b',
    floraColor: '#a3cb38',
    trunkColor: '#6f4e37',
    skyTint: '#d1f2eb',
    floraType: 'oak',
    faunaName: 'Четырёхлистный шмель',
    faunaColor: '#fed330',
    uniqueResourceId: 'res_luck_clover',
    uniqueResourceName: 'Четырёхлистник',
    weatherBias: 'sunshower',
  },
  {
    id: 'celestial_baobab',
    index: 30,
    name: 'Небесные Баобабы',
    groundColor: '#78e08f',
    accentColor: '#60a3bc',
    floraColor: '#82ccdd',
    trunkColor: '#9c6f44',
    skyTint: '#c7ecee',
    floraType: 'willow',
    faunaName: 'Облачный стриж',
    faunaColor: '#ffffff',
    uniqueResourceId: 'res_baobab_fiber',
    uniqueResourceName: 'Волокно баобаба',
    weatherBias: 'pollen',
  },
];

// Deterministic Mulberry32 PRNG for world seed reproducibility
export function createSeededRng(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state |= 0;
    state = (state + 0x6d2b79f5) | 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Picks `count` (default 8) unique biomes out of the 30 Botania biomes for a server seed.
 * Always keeps a vibrant safe starter biome as index 0 so spawn is immediately welcoming.
 */
export function selectServerBiomes(seed: number, count = 8): BiomeDef[] {
  const clampedCount = Math.max(1, Math.min(count, BOTANIA_BIOMES.length));
  const rng = createSeededRng(seed);
  const starter = BOTANIA_BIOMES[0];
  const pool = BOTANIA_BIOMES.slice(1);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = pool[i];
    pool[i] = pool[j];
    pool[j] = tmp;
  }
  return [starter, ...pool.slice(0, clampedCount - 1)];
}

export interface BiomeCenter {
  biome: BiomeDef;
  x: number;
  z: number;
}

export function getWorldBiomeCenters(worldBiomes: BiomeDef[]): BiomeCenter[] {
  const centers: BiomeCenter[] = [];
  if (worldBiomes.length === 0) return centers;
  // Center biome at (0, 0)
  centers.push({ biome: worldBiomes[0], x: 0, z: 0 });
  const ringCount = worldBiomes.length - 1;
  const ringRadius = 46;
  for (let i = 0; i < ringCount; i++) {
    const angle = (i / ringCount) * Math.PI * 2 + 0.35;
    centers.push({
      biome: worldBiomes[i + 1],
      x: Math.cos(angle) * ringRadius,
      z: Math.sin(angle) * ringRadius,
    });
  }
  return centers;
}

export function getBiomeAt(x: number, z: number, worldBiomes: BiomeDef[]): BiomeDef {
  const centers = getWorldBiomeCenters(worldBiomes);
  if (centers.length === 0) return BOTANIA_BIOMES[0];
  let best = centers[0];
  let bestDist = Infinity;
  for (let i = 0; i < centers.length; i++) {
    const c = centers[i];
    const dx = x - c.x;
    const dz = z - c.z;
    // Slight weighting so central meadow covers spawn radius cleanly (~22m)
    const weight = i === 0 ? 0.85 : 1.0;
    const d = (dx * dx + dz * dz) * weight;
    if (d < bestDist) {
      bestDist = d;
      best = c;
    }
  }
  return best.biome;
}

/**
 * Voxel-stepped smooth terrain height with a guaranteed flat open spawn clearing around (0, 0).
 */
export function groundHeightAt(x: number, z: number): number {
  const distFromOrigin = Math.hypot(x, z);
  if (distFromOrigin < 12) {
    return 0;
  }
  const blend = Math.min(1, (distFromOrigin - 12) / 14);
  const raw =
    Math.sin(x * 0.065) * Math.cos(z * 0.065) * 2.2 +
    Math.sin((x + z) * 0.03) * 1.4;
  // Voxel quantization in 0.5m steps
  return Math.round(raw * blend * 2) / 2;
}

export interface DayNightState {
  phaseName: string;
  sunAngle: number;
  sunIntensity: number;
  ambientIntensity: number;
  skyColor: string;
  fogColor: string;
  isNight: boolean;
}

export function getDynamicDayNightState(timeOfDay: number, weather: WeatherType): DayNightState {
  const t = ((timeOfDay % 1) + 1) % 1;
  // 0.25 = noon, 0.5 = sunset, 0.75 = midnight, 0.0 = sunrise
  const sunAngle = t * Math.PI * 2;
  const sunHeight = Math.sin(sunAngle); // 1 at noon, -1 at midnight
  const isNight = sunHeight < -0.1;

  let phaseName = 'Полдень';
  let skyColor = '#74c7ff';
  let fogColor = '#9fd9ff';

  if (t < 0.14 || t >= 0.92) {
    phaseName = 'Рассвет';
    skyColor = '#f7b28b';
    fogColor = '#fbd1b7';
  } else if (t >= 0.14 && t < 0.42) {
    phaseName = 'Ясный день';
    skyColor = '#66c3ff';
    fogColor = '#9ee0ff';
  } else if (t >= 0.42 && t < 0.58) {
    phaseName = 'Золотой закат';
    skyColor = '#ff8c69';
    fogColor = '#ffb899';
  } else {
    phaseName = 'Звёздная ночь';
    skyColor = '#14213d';
    fogColor = '#1c2e4a';
  }

  if (weather === 'mist') {
    fogColor = isNight ? '#243b55' : '#bce0d8';
  } else if (weather === 'pollen') {
    fogColor = isNight ? '#2d2a4a' : '#ffeaa7';
  } else if (weather === 'sunshower') {
    skyColor = isNight ? '#1b2b44' : '#5aa9d6';
  }

  const sunIntensity = Math.max(0.25, 0.45 + Math.max(0, sunHeight) * 1.45);
  const ambientIntensity = isNight ? 0.55 : 0.85;

  return {
    phaseName,
    sunAngle,
    sunIntensity,
    ambientIntensity,
    skyColor,
    fogColor,
    isNight,
  };
}
