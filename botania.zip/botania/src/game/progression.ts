export type SkillBranch = 'botanist' | 'architect' | 'pathfinder';

export interface SkillNode {
  id: string;
  branch: SkillBranch;
  branchLabel: string;
  name: string;
  description: string;
  cost: number;
  prerequisiteId?: string;
}

export const SKILL_NODES: SkillNode[] = [
  {
    id: 'bot_harvest',
    branch: 'botanist',
    branchLabel: 'Ботаник',
    name: 'Чуткий сборщик',
    description: '+1 бонусный ресурс с каждого второго срубленного растения',
    cost: 1,
  },
  {
    id: 'bot_spores',
    branch: 'botanist',
    branchLabel: 'Ботаник',
    name: 'Анализ спор',
    description: 'Открывает сложный крафт «Анализатор спор» и +30% XP за биомы',
    cost: 2,
    prerequisiteId: 'bot_harvest',
  },
  {
    id: 'arch_saver',
    branch: 'architect',
    branchLabel: 'Био-Инженер',
    name: 'Экономный чертёж',
    description: 'Снижает затраты ресурсов при сложном крафте на 20%',
    cost: 1,
  },
  {
    id: 'arch_blueprint',
    branch: 'architect',
    branchLabel: 'Био-Инженер',
    name: 'Архитектор алтарей',
    description: 'Открывает постройку «Алтарь семян» и +25% прочности базы',
    cost: 2,
    prerequisiteId: 'arch_saver',
  },
  {
    id: 'path_sprint',
    branch: 'pathfinder',
    branchLabel: 'Следопыт',
    name: 'Лёгкий шаг',
    description: '+20% скорость передвижения и бега по пересечённой местности',
    cost: 1,
  },
  {
    id: 'path_radar',
    branch: 'pathfinder',
    branchLabel: 'Следопыт',
    name: 'Био-компас отряда',
    description: 'Увеличивает радиус миникарты и снижает расход стамины на 30%',
    cost: 2,
    prerequisiteId: 'path_sprint',
  },
];

export function canUnlockSkill(
  nodeId: string,
  unlockedIds: string[],
  availablePoints: number
): boolean {
  if (unlockedIds.includes(nodeId)) return false;
  const node = SKILL_NODES.find((n) => n.id === nodeId);
  if (!node) return false;
  if (availablePoints < node.cost) return false;
  if (node.prerequisiteId && !unlockedIds.includes(node.prerequisiteId)) return false;
  return true;
}

export interface QuestProgress {
  harvestCount: number;
  biomesDiscoveredCount: number;
  craftedCount: number;
  builtCount: number;
}

export interface QuestDef {
  id: string;
  title: string;
  description: string;
  target: number;
  metric: keyof QuestProgress;
  rewardXp: number;
  rewardFlorins: number;
}

export const QUESTS: QuestDef[] = [
  {
    id: 'q_harvest',
    title: 'Первый урожай',
    description: 'Добудьте 4 ботанических ресурса топором в открытом мире',
    target: 4,
    metric: 'harvestCount',
    rewardXp: 60,
    rewardFlorins: 25,
  },
  {
    id: 'q_biomes',
    title: 'Картограф Флоры',
    description: 'Исследуйте 3 разных биома на текущем сервере',
    target: 3,
    metric: 'biomesDiscoveredCount',
    rewardXp: 100,
    rewardFlorins: 50,
  },
  {
    id: 'q_craft',
    title: 'Мастерская ростка',
    description: 'Скрафтите 2 предмета в инвентаре',
    target: 2,
    metric: 'craftedCount',
    rewardXp: 80,
    rewardFlorins: 35,
  },
  {
    id: 'q_build',
    title: 'Основание теплицы',
    description: 'Постройте 2 воксельных блока базы в мире',
    target: 2,
    metric: 'builtCount',
    rewardXp: 90,
    rewardFlorins: 40,
  },
];

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  check: (p: QuestProgress, level: number) => boolean;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'ach_first_chop',
    title: 'Зелёный лесоруб',
    description: 'Срубить первое воксельное дерево в Botania',
    check: (p) => p.harvestCount >= 1,
  },
  {
    id: 'ach_explorer_5',
    title: 'Первооткрыватель',
    description: 'Посетить 5 из 8 биомов текущего сервера',
    check: (p) => p.biomesDiscoveredCount >= 5,
  },
  {
    id: 'ach_architect',
    title: 'Зодчий оранжереи',
    description: 'Установить 3 строительных блока на базе',
    check: (p) => p.builtCount >= 3,
  },
  {
    id: 'ach_level_3',
    title: 'Хранитель Семян',
    description: 'Достичь 3-го уровня ботаника',
    check: (_p, level) => level >= 3,
  },
];

export type RoomPrivacy = 'public' | 'friends' | 'private';

export interface SquadMember {
  id: string;
  name: string;
  role: string;
  avatarColor: string;
  isHost: boolean;
  ready: boolean;
}

export interface LobbyShopItem {
  id: string;
  name: string;
  description: string;
  costFlorins: number;
  badge: string;
}

export const LOBBY_SHOP_ITEMS: LobbyShopItem[] = [
  {
    id: 'upg_gold_aura',
    name: 'Золотая корона хлорофилла',
    description: 'Эксклюзивный визуальный эффект и +10% к стартовой выносливости',
    costFlorins: 120,
    badge: 'Кастомизация',
  },
  {
    id: 'upg_fast_axe',
    name: 'Гравировка солнечного топора',
    description: '+15% к скорости взмаха инструмента в начале забега',
    costFlorins: 180,
    badge: 'Улучшение',
  },
  {
    id: 'upg_backpack_charm',
    name: 'Амулет семян-хранителей',
    description: '+15% к получению опыта при открытии новых биомов',
    costFlorins: 240,
    badge: 'Реликвия',
  },
];

export interface DonatePack {
  id: string;
  florins: number;
  priceLabel: string;
  bonusLabel: string;
}

export const DONATE_PACKS: DonatePack[] = [
  { id: 'pack_100', florins: 100, priceLabel: '75 Robux', bonusLabel: 'Стартовый набор' },
  { id: 'pack_350', florins: 350, priceLabel: '220 Robux', bonusLabel: '+15% выгоды' },
  { id: 'pack_900', florins: 900, priceLabel: '499 Robux', bonusLabel: 'Набор отряда' },
];

export const LOADING_TIPS: string[] = [
  'Совет: Каждый сервер Botania генерирует 8 уникальных биомов из 30 возможных — исследуйте границы для редких ресурсов!',
  'Совет: Перетаскивайте предметы между рюкзаком и хотбаром (1–6), чтобы быстро переключаться между топором и строительными блоками.',
  'Совет: В настройках доступна «Картофельная графика» — она отключает тени и снижает нагрузку на слабых телефонах.',
  'Совет: Объединяйтесь в лобби до 4 игроков: маркеры друзей видны на миникарте в реальном времени.',
  'Совет: Прокачайте ветку «Био-Инженер», чтобы открыть сложный крафт Алтаря семян и снизить стоимость построек.',
  'Совет: Вся добыча, постройки и позиции проверяются серверным анти-читом и сохраняются в облачном DataStore.',
];

export type TeleportDirection = 'ToWorld' | 'ToLobby';

export interface BiomeSurvivalTip {
  id: string;
  direction: TeleportDirection | 'Both';
  biomeId: string;
  biomeName: string;
  toxicity: 0 | 1 | 2 | 3;
  accentColor: string;
  headline: string;
  tip: string;
  recommendedGear: string;
}

export const BIOME_SURVIVAL_TIPS: BiomeSurvivalTip[] = [
  {
    id: 'tip_emerald_grove',
    direction: 'ToWorld',
    biomeId: 'emerald_grove',
    biomeName: 'Изумрудная Роща',
    toxicity: 0,
    accentColor: '#22c55e',
    headline: 'Стартовый сбор древесины и волокна',
    tip: 'Безопасный биом у Шпиля Семян. Срубите 3–4 дерева на старте, чтобы скрафтить грядки и мшистые стены до выхода к окраинам острова.',
    recommendedGear: 'Ботанический топор',
  },
  {
    id: 'tip_mycelium_canyon',
    direction: 'ToWorld',
    biomeId: 'mycelium_canyon',
    biomeName: 'Грибной Каньон',
    toxicity: 2,
    accentColor: '#c084fc',
    headline: 'Защита от мицелиевых спор',
    tip: 'Туманные каньоны наносят урон спорами каждые 2 секунды. Поставьте Алтарь семян (купол 22 studs) или держите в слоте хлорофилловый фильтр.',
    recommendedGear: 'Хлорофилловый фильтр · Алтарь семян',
  },
  {
    id: 'tip_crystal_greenhouse',
    direction: 'ToWorld',
    biomeId: 'crystal_greenhouse',
    biomeName: 'Кристальная Теплица',
    toxicity: 3,
    accentColor: '#38bdf8',
    headline: 'Высокая токсичность и хрустальный нектар',
    tip: 'Редчайшие кристаллы растут в зоне 3-го уровня опасности. Перед вылазкой установите передовой купол на границе биома и запасите лейки росы.',
    recommendedGear: 'Алтарь семян · Нефритовый секатор',
  },
  {
    id: 'tip_sakura_terraces',
    direction: 'ToWorld',
    biomeId: 'sakura_terraces',
    biomeName: 'Сакуровые Террасы',
    toxicity: 1,
    accentColor: '#f472b6',
    headline: 'Кросс-опыление гибридных семян',
    tip: 'Посадите семя Сакуры рядом с семенем Лощины Папоротника (в радиусе 6.5 studs), чтобы вырастить светящуюся Люмен-орхидею.',
    recommendedGear: 'Грядка культивации · Лейка био-росы',
  },
  {
    id: 'tip_cactus_monolith',
    direction: 'ToWorld',
    biomeId: 'cactus_monolith',
    biomeName: 'Монолит Кактусов',
    toxicity: 3,
    accentColor: '#f59e0b',
    headline: 'Осторожнее с перепадами высоты',
    tip: 'Каменные плато обрываются резкими уступами: падение с высоты более 26 studs наносит физический урон при приземлении.',
    recommendedGear: 'Навык «Лёгкий шаг» · Фильтр спор',
  },
  {
    id: 'tip_bamboo_labyrinth',
    direction: 'ToWorld',
    biomeId: 'bamboo_labyrinth',
    biomeName: 'Бамбуковый Лабиринт',
    toxicity: 0,
    accentColor: '#10b981',
    headline: 'Быстрая ориентировка по миникарте',
    tip: 'Высокие заросли скрывают обзор, но маркеры союзников и Шпиля Семян на миникарте в реальном времени помогут не потерять отряд.',
    recommendedGear: 'Миникарта отряда · Био-компас',
  },
  {
    id: 'tip_lobby_squad',
    direction: 'ToLobby',
    biomeId: 'lobby',
    biomeName: 'Лобби Экспедиции',
    toxicity: 0,
    accentColor: '#34d399',
    headline: 'Подготовка отряда до 4 игроков',
    tip: 'Перед возвращением в мир потратьте накопленные Флорины на Корону хлорофилла и Адаптивный иммунитет — улучшения сохраняются в DataStore.',
    recommendedGear: 'Магазин лобби · Древо навыков',
  },
  {
    id: 'tip_lobby_mobile',
    direction: 'ToLobby',
    biomeId: 'lobby',
    biomeName: 'Лобби · Оптимизация',
    toxicity: 0,
    accentColor: '#60a5fa',
    headline: 'Режим «Картофельной графики»',
    tip: 'На слабых телефонах включите картофельную графику (F8 на ПК или кнопка в настройках): тени и частицы отключатся, а FPS останется стабильным.',
    recommendedGear: 'Настройки · StreamingEnabled',
  },
];

export function selectSurvivalTipsForTeleport(
  direction: TeleportDirection,
  activeBiomeIds: string[] = []
): BiomeSurvivalTip[] {
  const directional = BIOME_SURVIVAL_TIPS.filter(
    (t) => t.direction === direction || t.direction === 'Both'
  );
  if (direction === 'ToWorld' && activeBiomeIds.length > 0) {
    const activeSet = new Set(activeBiomeIds);
    const prioritized = directional.filter((t) => activeSet.has(t.biomeId));
    const fallback = directional.filter((t) => !activeSet.has(t.biomeId));
    return [...prioritized, ...fallback];
  }
  return directional;
}

export interface AntiCheatCheckInput {
  distanceMoved: number;
  deltaSeconds: number;
  maxSpeed: number;
  interactDistance?: number;
}

export interface AntiCheatVerdict {
  valid: boolean;
  reason?: string;
}

/**
 * Mirrors the server-side Luau AntiCheatValidator bounds checks.
 */
export function validatePlayerAction(input: AntiCheatCheckInput): AntiCheatVerdict {
  if (input.deltaSeconds <= 0) {
    return { valid: true };
  }
  const speed = input.distanceMoved / input.deltaSeconds;
  // Allow 1.35x network/jitter tolerance just like Roblox server sanity check
  if (speed > input.maxSpeed * 1.35) {
    return {
      valid: false,
      reason: `Превышение скорости (${speed.toFixed(1)} > ${(input.maxSpeed * 1.35).toFixed(1)} м/с)`,
    };
  }
  if (input.interactDistance !== undefined && input.interactDistance > 7.5) {
    return {
      valid: false,
      reason: `Слишком большая дистанция взаимодействия (${input.interactDistance.toFixed(1)} м)`,
    };
  }
  return { valid: true };
}

export function calculateLevelFromXp(xp: number): {
  level: number;
  xpIntoLevel: number;
  xpForNext: number;
} {
  let level = 1;
  let remaining = Math.max(0, Math.floor(xp));
  let threshold = 100;
  while (remaining >= threshold) {
    remaining -= threshold;
    level += 1;
    threshold = 100 + (level - 1) * 50;
  }
  return { level, xpIntoLevel: remaining, xpForNext: threshold };
}
